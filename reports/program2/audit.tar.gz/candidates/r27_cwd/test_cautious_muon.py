"""Check decay sign boundaries, native directions, serialization and AdamW isolation."""

import copy
import unittest
from unittest.mock import patch

import torch

from nano_protein.cautious_muon import CautiousMuon
from nano_protein.model import ESMCConfig, ESMCForMaskedLM
from nano_protein.train import build_optimizer


class CautiousMuonTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1)
        torch.manual_seed(27)

    def test_zero_decay_matches_native_for_shapes_momentum_and_nesterov(self):
        for shape in ((8, 8), (12, 4), (4, 12)):
            for nesterov in (False, True):
                with self.subTest(shape=shape, nesterov=nesterov):
                    a = torch.nn.Parameter(torch.randn(shape))
                    b = torch.nn.Parameter(a.detach().clone())
                    options = dict(
                        lr=0.003,
                        weight_decay=0.0,
                        momentum=0.95,
                        nesterov=nesterov,
                        adjust_lr_fn="match_rms_adamw",
                    )
                    native = torch.optim.Muon([a], **options)
                    cautious = CautiousMuon([b], **options)
                    for step in range(4):
                        gradient = torch.randn_like(a) if step != 2 else torch.zeros_like(a)
                        a.grad, b.grad = gradient.clone(), gradient.clone()
                        native.step()
                        cautious.step()
                        torch.testing.assert_close(a, b, rtol=0, atol=0)
                        torch.testing.assert_close(
                            native.state[a]["momentum_buffer"],
                            cautious.state[b]["momentum_buffer"],
                            rtol=0,
                            atol=0,
                        )

    def test_decay_sign_zero_boundary_and_pre_update_weight(self):
        # Update signs agree only at (0,0), (0,2), (1,0), and (1,2).
        weight = torch.nn.Parameter(
            torch.tensor([[2.0, 3.0, 4.0], [0.0, -5.0, -6.0]], dtype=torch.float64)
        )
        direction = torch.tensor([[1.0, -2.0, 0.0], [0.0, 4.0, -6.0]], dtype=torch.float64)
        optimizer = CautiousMuon(
            [weight], lr=0.1, weight_decay=0.2, adjust_lr_fn="match_rms_adamw"
        )
        weight.grad = torch.ones_like(weight)
        decayed = torch.tensor([[1.96, 3.0, 3.92], [0.0, -5.0, -5.88]], dtype=torch.float64)
        expected = decayed - (0.1 * 0.2 * 3**0.5) * direction
        with patch(
            "nano_protein.cautious_muon._zeropower_via_newtonschulz", return_value=direction
        ):
            optimizer.step()
        torch.testing.assert_close(weight, expected, rtol=1e-14, atol=1e-14)
        # A positive weight that crosses zero still uses its positive pre-update sign.
        crossing = torch.nn.Parameter(torch.full((2, 2), 0.001))
        optimizer = CautiousMuon(
            [crossing], lr=1.0, weight_decay=0.5, adjust_lr_fn="match_rms_adamw"
        )
        crossing.grad = torch.ones_like(crossing)
        with patch(
            "nano_protein.cautious_muon._zeropower_via_newtonschulz",
            return_value=torch.ones_like(crossing),
        ):
            optimizer.step()
        torch.testing.assert_close(crossing, torch.full_like(crossing, 0.0005 - 0.2 * 2**0.5))

    def test_state_resume_missing_gradient_and_closure(self):
        a = torch.nn.Parameter(torch.randn(8, 8))
        unused = torch.nn.Parameter(torch.ones(8, 8))
        optimizer = CautiousMuon(
            [a, unused], lr=0.003, weight_decay=0.1, adjust_lr_fn="match_rms_adamw"
        )
        for _ in range(3):
            a.grad = torch.randn_like(a)
            optimizer.step()
        self.assertNotIn(unused, optimizer.state)
        torch.testing.assert_close(unused, torch.ones_like(unused), rtol=0, atol=0)
        b = torch.nn.Parameter(a.detach().clone())
        extra = torch.nn.Parameter(unused.detach().clone())
        resumed = CautiousMuon([b, extra], lr=0.003)
        resumed.load_state_dict(copy.deepcopy(optimizer.state_dict()))
        self.assertTrue(resumed.param_groups[0]["cautious_weight_decay"])
        gradient = torch.randn_like(a)
        a.grad, b.grad = gradient.clone(), gradient.clone()
        optimizer.step()
        resumed.step()
        torch.testing.assert_close(a, b, rtol=0, atol=0)
        torch.testing.assert_close(
            optimizer.state[a]["momentum_buffer"],
            resumed.state[b]["momentum_buffer"],
            rtol=0,
            atol=0,
        )

        def closure():
            resumed.zero_grad()
            loss = b.square().sum()
            loss.backward()
            return loss

        self.assertTrue(torch.isfinite(resumed.step(closure)))

    def test_config_selects_only_muon_variant_and_preserves_adamw(self):
        config = dict(
            optimizer="muon",
            learning_rate=0.000326599,
            weight_decay=0.0183712,
            betas=[0.9, 0.95],
        )
        a = ESMCForMaskedLM(ESMCConfig.tiny(ffn_hidden_dim=192))
        b = copy.deepcopy(a)
        native = build_optimizer(a, config)
        cautious = build_optimizer(b, dict(config, muon_cautious_weight_decay=True))
        self.assertIs(type(native.named_optimizers[0][1]), torch.optim.Muon)
        self.assertIs(type(cautious.named_optimizers[0][1]), CautiousMuon)
        self.assertIs(type(cautious.named_optimizers[1][1]), torch.optim.AdamW)
        for x, y in zip(a.parameters(), b.parameters(), strict=True):
            x.grad = torch.randn_like(x)
            y.grad = x.grad.clone()
        native.step()
        cautious.step()
        before = native.named_optimizers[1][1]
        after = cautious.named_optimizers[1][1]
        for g, h in zip(before.param_groups, after.param_groups, strict=True):
            for x, y in zip(g["params"], h["params"], strict=True):
                torch.testing.assert_close(x, y, rtol=0, atol=0)
                for key in before.state[x]:
                    torch.testing.assert_close(
                        before.state[x][key], after.state[y][key], rtol=0, atol=0
                    )
        self.assertTrue(
            all(
                set(s) == {"momentum_buffer"}
                for s in cautious.named_optimizers[0][1].state.values()
            )
        )


if __name__ == "__main__":
    unittest.main()
