"""Qualify Muon cautious decay: native directions, gradients and full L40S cost."""
import copy, json, statistics, time
from pathlib import Path
import torch,yaml
from nano_protein.model import ESMCConfig, ESMCForMaskedLM, count_parameters, expected_parameter_count
from nano_protein.tokenizer import ProteinTokenizer,mask_tokens
from nano_protein.train import build_optimizer,training_losses
from nano_protein.schedule import warmup_constant_multiplier

torch.set_num_threads(1);torch.set_float32_matmul_precision('high')
assert torch.cuda.get_device_name(0)=='NVIDIA L40S'
root=Path('.dev/program2/candidates/r27_cwd')
base_config=yaml.safe_load(Path('configs/program2/r22_ffn1536_seed42.yaml').read_text())
new_config=yaml.safe_load(Path('configs/program2/r27_cwd_seed42.yaml').read_text())
expected=copy.deepcopy(base_config);expected.update(muon_cautious_weight_decay=True)
assert new_config==expected
from nano_protein.cautious_muon import CautiousMuon
from torch.optim._muon import _zeropower_via_newtonschulz,_adjust_lr
supplied_checks=[]
for shape in ((2304,768),(768,768),(3072,768),(768,1536)):
    torch.manual_seed(27)
    p=torch.nn.Parameter(torch.randn(shape,device='cuda')*.02)
    q=torch.nn.Parameter(p.detach().clone())
    opt=CautiousMuon([p],lr=base_config['learning_rate'],weight_decay=base_config['weight_decay'],adjust_lr_fn='match_rms_adamw')
    native=torch.optim.Muon([q],lr=base_config['learning_rate'],weight_decay=0.,adjust_lr_fn='match_rms_adamw')
    errors=[];fractions=[]
    for _ in range(3):
        with torch.no_grad():q.copy_(p)
        before=p.detach().clone();g=torch.randn_like(p);p.grad=g;q.grad=g.clone()
        opt.step();native.step()
        torch.testing.assert_close(opt.state[p]['momentum_buffer'],native.state[q]['momentum_buffer'],rtol=0,atol=0)
        group=opt.param_groups[0]
        direction=_zeropower_via_newtonschulz(g.lerp(native.state[q]['momentum_buffer'],group['momentum']),group['ns_coefficients'],group['ns_steps'],group['eps'])
        active=before.double()*direction.double()>=0
        expected=before.double()-group['lr']*group['weight_decay']*active*before.double()-_adjust_lr(group['lr'],group['adjust_lr_fn'],p.shape)*direction.double()
        error=(p.double()-expected).abs().max().item();assert error<1e-7,error
        errors.append(error);fractions.append(active.double().mean().item())
    # No-decay execution must exactly match native at every actual matrix shape.
    opt.param_groups[0]['weight_decay']=0.
    with torch.no_grad():q.copy_(p)
    p.grad=torch.randn_like(p);q.grad=p.grad.clone();opt.step();native.step()
    torch.testing.assert_close(p,q,rtol=0,atol=0)
    supplied_checks.append({'shape':list(shape),'fp64_reference_max_errors':errors,'synthetic_active_decay_fractions':fractions,'zero_decay_native_bitwise_equal':True})
    del p,q,opt,native,before,g,direction,active,expected
models=[]
for index in (0,1):
    torch.manual_seed(24)
    models.append(ESMCForMaskedLM(ESMCConfig.esmc_171m(ffn_hidden_dim=1536)).cuda())
assert [count_parameters(m) for m in models]==[142359616,142359616]
assert expected_parameter_count(models[1].config)==142359616
assert all(block.ffn.gate_up.weight.shape==(3072,768) and block.ffn.down.weight.shape==(768,1536) for block in models[1].blocks)
optimizers=[build_optimizer(m,c) for m,c in zip(models,(base_config,new_config),strict=True)]
assert all(len(o.named_optimizers[0][1].param_groups[0]['params'])==96 for o in optimizers)
for step in (1,553,554,555,20000):
    multiplier=warmup_constant_multiplier(optimizer_step=step,warmup_steps=554)
    for opt in optimizers:
        for group in opt.param_groups:group['lr']=base_config['learning_rate']*multiplier*group.get('lr_scale',1.)
    for first,second in zip(optimizers[0].param_groups,optimizers[1].param_groups,strict=True):
        for key in ('lr','weight_decay','lr_scale'):assert first.get(key)==second.get(key)
tokenizer=ProteinTokenizer.esmc()
sequences=[('LAGVESIDPKQNFYMHWCART'*26)[:18+(i*83)%490] for i in range(64)]
tokens,attention=tokenizer.encode_batch(sequences,max_length=512)
tokens,attention=tokens.cuda(),attention.cuda();torch.cuda.manual_seed(24)
corrupted,labels=mask_tokens(tokens,attention,tokenizer)

def step(index):
    model,opt=models[index],optimizers[index];opt.zero_grad(set_to_none=True)
    with torch.autocast('cuda',dtype=torch.bfloat16):
        output=model(corrupted,attention)
        loss,_,_=training_losses(output['logits'],labels,reduction='sqrt_mask_count')
    loss.backward();norm=torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step()
    return loss.detach(),norm.detach()

timings={'hidden1536_ms':[],'cwd_ms':[]}
for round_index in range(2):
    for index in ([0,1] if round_index==0 else [1,0]):
        for _ in range(3):loss,norm=step(index)
        torch.cuda.synchronize();start=time.perf_counter()
        for _ in range(6):loss,norm=step(index)
        torch.cuda.synchronize()
        timings[('hidden1536_ms','cwd_ms')[index]].append((time.perf_counter()-start)*1000/6)
        assert torch.isfinite(loss) and torch.isfinite(norm)
assert all(torch.isfinite(p).all() and p.grad is not None and torch.isfinite(p.grad).all() for p in models[1].parameters())
assert all(block.ffn.gate_up.weight.grad.count_nonzero()>0 and block.ffn.down.weight.grad.count_nonzero()>0 for block in models[1].blocks)
small_tokens,small_mask=tokenizer.encode_batch(['ACDEFGHIK','LAGVESIDPKQNFYMHWCA'],max_length=24)
with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16):
    features=models[1](small_tokens.cuda(),small_mask.cuda(),output_attentions=True)
assert len(features['attentions'])==24
assert all(x.shape==(2,12,24,24) and torch.isfinite(x).all() for x in features['attentions'])
peak_memory=torch.cuda.max_memory_allocated()/1024**2
del models,optimizers,features,loss,norm
# Compare variable-length packed training and dense math paths on identical weights.
torch.manual_seed(24)
reference=ESMCForMaskedLM(ESMCConfig.tiny(ffn_hidden_dim=192,attention_backend='math')).cuda()
packed=ESMCForMaskedLM(ESMCConfig.tiny(ffn_hidden_dim=192,attention_backend='flash')).cuda()
packed.load_state_dict(reference.state_dict())
import tempfile
from nano_protein.evaluate import load_checkpoint
with tempfile.TemporaryDirectory() as directory:
    checkpoint=Path(directory)/'tiny.pt'
    torch.save({'model_config':reference.config.to_dict(),'model':reference.state_dict()},checkpoint)
    loaded,_=load_checkpoint(checkpoint,torch.device('cpu'))
    assert loaded.config.ffn_hidden_dim==192
    for key,value in loaded.state_dict().items():
        torch.testing.assert_close(value,reference.state_dict()[key].cpu(),rtol=0,atol=0)
    del loaded
tokens,attention=tokenizer.encode_batch(['ACDEFGHIK','LAGVESIDPKQNFYMHWCA'*3,'GGGGG','ACDEFGHIKLMNPQRSTVWY'*4],max_length=64)
tokens,attention=tokens.cuda(),attention.cuda();corrupted,labels=mask_tokens(tokens,attention,tokenizer)
outputs=[]
for model in (reference,packed):
    with torch.autocast('cuda',dtype=torch.bfloat16):
        output=model(corrupted,attention)
        loss,_,_=training_losses(output['logits'],labels,reduction='sqrt_mask_count')
    loss.backward();outputs.append(output['logits'][attention].detach().float())
max_logit_error=(outputs[0]-outputs[1]).abs().max().item();assert max_logit_error<.03,max_logit_error
se=sr=0.
for a,b in zip(reference.parameters(),packed.parameters(),strict=True):
    assert a.grad is not None and b.grad is not None
    se+=(a.grad-b.grad).float().square().sum().item();sr+=a.grad.float().square().sum().item()
relative_gradient_error=(se/sr)**.5;assert relative_gradient_error<.05,relative_gradient_error
a=statistics.median(timings['hidden1536_ms']);b=statistics.median(timings['cwd_ms'])
receipt={'status':'passed','gpu':torch.cuda.get_device_name(0),'parameters':142359616,'removed_parameters':0,'muon_cautious_weight_decay':True,
 'candidate':'Muon-only decay gated by pre-update weight * native orthogonalized update >= 0; all model shapes and AdamW unchanged',
 'initialization_caveat':'All model source, tensor shapes and RNG remain accepted R22. Campaign models train from scratch.',
 'source':'Only CWD class, its license/test, optimizer selector in train.py and paired configs change',
 'all_fullsize_parameters_and_gradients_finite':True,'ffn_pairs_with_nonzero_gradients':24,'muon_matrices':96,
 'fullsize_contact_feature_layout':[24,12],'supplied_gradient_native_checks':supplied_checks,'dense_vs_packed_max_logit_error':max_logit_error,'dense_vs_packed_relative_gradient_error':relative_gradient_error,
 'timing_samples':timings,'baseline_median_step_ms':a,'candidate_median_step_ms':b,'tokens_per_second_ratio':a/b,
 'timing_protocol':'Two alternating rounds, each3 warm+6 measured full forward/backward/clip/Muon+AdamW updates on the same64 synthetic masked sequences <=512; no distributed overhead, actual pair establishes throughput',
 'schedule':'Actual groups agree at steps1,553,554,555,20000; exact554-step warmup then fixed configured peaks',
 'data':'Synthetic protein sequences only; no held-out or training data','peak_memory_mb_two_models':peak_memory}
(root/'MODEL_PREFLIGHT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
