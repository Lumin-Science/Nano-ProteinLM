"""Muon with sign-selective decay; momentum and NS use the frozen PyTorch rules.

Adapted from torch.optim.Muon/_single_tensor_muon in PyTorch 2.13.0.
See cautious_muon.LICENSE for the retained PyTorch copyright and BSD notice.
CWD rule: https://arxiv.org/abs/2510.12402 (Algorithm 1 and Appendix B.4).
"""

import torch
from torch.optim._muon import _adjust_lr, _zeropower_via_newtonschulz


class CautiousMuon(torch.optim.Muon):
    """Gate only weight decay by pre-update weight times orthogonal update >= 0."""

    def __init__(self, params, **kwargs):
        super().__init__(params, **kwargs)
        self.defaults["cautious_weight_decay"] = True
        for group in self.param_groups:
            group["cautious_weight_decay"] = True

    @torch.no_grad()
    def step(self, closure=None):
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()
        for group in self.param_groups:
            params, grads, buffers = [], [], []
            self._init_group(group, params, grads, buffers)
            lr = float(group["lr"])
            weight_decay = group["weight_decay"]
            momentum = group["momentum"]
            for param, grad, buf in zip(params, grads, buffers, strict=True):
                if grad.ndim != 2:
                    raise ValueError("Param gradient must be a 2D matrix")
                buf.lerp_(grad, 1 - momentum)
                update = grad.lerp(buf, momentum) if group["nesterov"] else buf
                update = _zeropower_via_newtonschulz(
                    update, group["ns_coefficients"], group["ns_steps"], group["eps"]
                )
                if weight_decay:
                    # Use the direction before the descent minus sign and the old weight.
                    mask = (param * update >= 0).to(param.dtype)
                    param.addcmul_(param, mask, value=-lr * weight_decay)
                param.add_(update, alpha=-_adjust_lr(lr, group["adjust_lr_fn"], param.shape))
        return loss
