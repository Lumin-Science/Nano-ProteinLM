"""Check intermediate FFN normalization, optimizer grouping, and frozen loading."""

import tempfile
import unittest
from pathlib import Path

import torch
import torch.nn.functional as F

from nano_protein.evaluate import load_checkpoint
from nano_protein.model import (
    ESMCConfig,
    ESMCForMaskedLM,
    count_parameters,
    expected_parameter_count,
)
from nano_protein.train import build_optimizer


class FFNActivationNormTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1)
        torch.manual_seed(20)

    def test_independent_affine_mean_variance_reference_and_gradients(self):
        model = ESMCForMaskedLM(ESMCConfig.tiny(ffn_activation_norm=True)).double()
        layer = model.blocks[0].ffn
        norm = layer.activation_norm
        with torch.no_grad():
            norm.weight.copy_(torch.linspace(0.7, 1.3, norm.weight.numel()))
            norm.bias.copy_(torch.linspace(-0.1, 0.1, norm.bias.numel()))
        for shape in ((2, 7, 128), (14, 128)):
            x = torch.randn(shape, dtype=torch.float64, requires_grad=True)
            actual = layer(x)
            gate_weights, up_weights = layer.gate_up.weight.chunk(2, dim=0)
            inputs = layer.norm(x)
            gate = F.linear(inputs, gate_weights)
            activated = gate.sigmoid() * gate * F.linear(inputs, up_weights)
            centered = activated - activated.mean(-1, keepdim=True)
            variance = centered.square().mean(-1, keepdim=True)
            normalized = centered / (variance + norm.eps).sqrt()
            expected = F.linear(normalized * norm.weight + norm.bias, layer.down.weight)
            torch.testing.assert_close(actual, expected, rtol=1e-10, atol=1e-12)
            parameters = (x, *tuple(layer.parameters()))
            a = torch.autograd.grad(actual.square().sum(), parameters, retain_graph=True)
            b = torch.autograd.grad(expected.square().sum(), parameters)
            for first, second in zip(a, b, strict=True):
                torch.testing.assert_close(first, second, rtol=1e-9, atol=1e-11)

    def test_initialization_budget_default_and_adamw_groups(self):
        base = ESMCForMaskedLM(ESMCConfig.tiny())
        rng = torch.get_rng_state()
        torch.manual_seed(20)
        candidate = ESMCForMaskedLM(ESMCConfig.tiny(ffn_activation_norm=True))
        self.assertTrue(torch.equal(rng, torch.get_rng_state()))
        for name, value in base.state_dict().items():
            torch.testing.assert_close(value, candidate.state_dict()[name], rtol=0, atol=0)
        self.assertEqual(
            expected_parameter_count(ESMCConfig.esmc_171m(ffn_activation_norm=True)),
            170_769_472,
        )
        self.assertEqual(
            count_parameters(candidate), expected_parameter_count(candidate.config)
        )
        x = torch.randn(2, 5, 128)
        layer = base.blocks[0].ffn
        gate, value = layer.gate_up(layer.norm(x)).chunk(2, -1)
        torch.testing.assert_close(layer(x), layer.down(F.silu(gate) * value), rtol=0, atol=0)
        norms = [p for name, p in candidate.named_parameters() if ".activation_norm." in name]
        self.assertEqual(len(norms), 4)
        for block in candidate.blocks:
            self.assertTrue(block.ffn.activation_norm.weight.eq(1).all())
            self.assertTrue(block.ffn.activation_norm.bias.eq(0).all())
        optimizer = build_optimizer(
            candidate,
            {"optimizer": "muon", "learning_rate": 0.000326599, "weight_decay": 0.0183712},
        )
        norm_ids = {id(p) for p in norms}
        for name, component in optimizer.named_optimizers:
            for group in component.param_groups:
                for parameter in group["params"]:
                    if id(parameter) in norm_ids:
                        self.assertEqual(name, "adamw")
                        self.assertEqual(group["weight_decay"], 0)

    def test_frozen_loader_preserves_normalization_and_attention_features(self):
        model = ESMCForMaskedLM(
            ESMCConfig.tiny(ffn_activation_norm=True, attention_backend="math")
        )
        tokens = torch.tensor([[0, 32, 4, 5, 2], [0, 6, 32, 2, 1]])
        mask = tokens.ne(1)
        expected = model(tokens, mask, output_attentions=True)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "checkpoint.pt"
            torch.save(
                {"model_config": model.config.to_dict(), "model": model.state_dict()}, path
            )
            loaded, _ = load_checkpoint(path, torch.device("cpu"))
        self.assertTrue(loaded.config.ffn_activation_norm)
        actual = loaded(tokens, mask, output_attentions=True)
        torch.testing.assert_close(actual["logits"], expected["logits"], rtol=0, atol=0)
        for a, b in zip(actual["attentions"], expected["attentions"], strict=True):
            torch.testing.assert_close(a, b, rtol=0, atol=0)


if __name__ == "__main__":
    unittest.main()
