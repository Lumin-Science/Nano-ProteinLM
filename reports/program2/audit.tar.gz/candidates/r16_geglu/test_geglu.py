"""Check GEGLU with an independent Gaussian-CDF reference and frozen loading."""

import tempfile
import unittest
from pathlib import Path

import torch
import torch.nn.functional as F

from nano_protein.evaluate import load_checkpoint
from nano_protein.model import (
    ESMCConfig,
    ESMCForMaskedLM,
    count_parameters,
    expected_parameter_count,
)


class GEGLUTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1)
        torch.manual_seed(16)

    def test_gaussian_cdf_gate_forward_and_gradients_in_dense_and_packed_layouts(self):
        model = ESMCForMaskedLM(ESMCConfig.tiny(ffn_gate_activation="gelu")).double()
        layer = model.blocks[0].ffn
        for shape in ((2, 7, 128), (14, 128)):
            hidden = torch.randn(shape, dtype=torch.float64, requires_grad=True)
            actual = layer(hidden)
            gate_weights, value_weights = layer.gate_up.weight.chunk(2, dim=0)
            normalized = layer.norm(hidden)
            gate = F.linear(normalized, gate_weights)
            value = F.linear(normalized, value_weights)
            cdf = (1 + torch.erf(gate / (2**0.5))) / 2
            expected = (gate * cdf * value) @ layer.down.weight.T
            torch.testing.assert_close(actual, expected, rtol=1e-12, atol=1e-12)
            parameters = (hidden, *tuple(layer.parameters()))
            grad_actual = torch.autograd.grad(
                actual.square().sum(), parameters, retain_graph=True
            )
            grad_expected = torch.autograd.grad(expected.square().sum(), parameters)
            for a, b in zip(grad_actual, grad_expected, strict=True):
                torch.testing.assert_close(a, b, rtol=1e-10, atol=1e-12)

    def test_default_initialization_budget_and_frozen_checkpoint_loader(self):
        base = ESMCForMaskedLM(ESMCConfig.tiny(attention_backend="math"))
        rng = torch.get_rng_state()
        torch.manual_seed(16)
        candidate = ESMCForMaskedLM(
            ESMCConfig.tiny(ffn_gate_activation="gelu", attention_backend="math")
        )
        self.assertTrue(torch.equal(rng, torch.get_rng_state()))
        self.assertEqual(count_parameters(base), count_parameters(candidate))
        self.assertEqual(
            expected_parameter_count(ESMCConfig.esmc_171m(ffn_gate_activation="gelu")),
            170_671_168,
        )
        for name, value in base.state_dict().items():
            torch.testing.assert_close(value, candidate.state_dict()[name], rtol=0, atol=0)
        x = torch.randn(2, 5, 128)
        layer = base.blocks[0].ffn
        a, b = layer.gate_up(layer.norm(x)).chunk(2, -1)
        torch.testing.assert_close(layer(x), layer.down(F.silu(a) * b), rtol=0, atol=0)
        self.assertTrue(all(block.ffn.gate_activation == "gelu" for block in candidate.blocks))
        tokens = torch.tensor([[0, 4, 5, 6, 2], [0, 7, 8, 2, 1]])
        mask = tokens != 1
        expected = candidate(tokens, mask, output_attentions=True)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "checkpoint.pt"
            torch.save(
                {"model_config": candidate.config.to_dict(), "model": candidate.state_dict()},
                path,
            )
            loaded, _ = load_checkpoint(path, torch.device("cpu"))
        actual = loaded(tokens, mask, output_attentions=True)
        self.assertEqual(loaded.config.ffn_gate_activation, "gelu")
        torch.testing.assert_close(actual["logits"], expected["logits"], rtol=0, atol=0)
        for a, b in zip(actual["attentions"], expected["attentions"], strict=True):
            torch.testing.assert_close(a, b, rtol=0, atol=0)
        with self.assertRaises(ValueError):
            ESMCConfig.tiny(ffn_gate_activation="relu")


if __name__ == "__main__":
    unittest.main()
