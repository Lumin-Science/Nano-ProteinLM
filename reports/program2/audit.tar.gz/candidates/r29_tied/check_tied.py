"""Qualify tied input/output weights, frozen defaults/features and actual L40S cost."""
import copy, json, statistics, time
from pathlib import Path
import torch,yaml
from nano_protein.model import ESMCConfig, ESMCForMaskedLM, count_parameters, expected_parameter_count
from nano_protein.tokenizer import ProteinTokenizer,mask_tokens
from nano_protein.train import build_optimizer,training_losses
from nano_protein.schedule import warmup_constant_multiplier

torch.set_num_threads(1);torch.set_float32_matmul_precision('high')
assert torch.cuda.get_device_name(0)=='NVIDIA L40S'
root=Path('.dev/program2/candidates/r29_tied')
base_config=yaml.safe_load(Path('configs/program2/r22_ffn1536_seed42.yaml').read_text())
new_config=yaml.safe_load(Path('configs/program2/r29_tied_seed42.yaml').read_text())
expected=copy.deepcopy(base_config);expected.update(tie_word_embeddings=True,expected_parameter_count=142310464)
assert new_config==expected
models=[]
for tied in (False,True):
    torch.manual_seed(24)
    models.append(ESMCForMaskedLM(ESMCConfig.esmc_171m(ffn_hidden_dim=1536,tie_word_embeddings=tied)).cuda())
assert [count_parameters(m) for m in models]==[142359616,142310464]
assert expected_parameter_count(models[1].config)==142310464
assert all(block.ffn.gate_up.weight.shape==(3072,768) and block.ffn.down.weight.shape==(768,1536) for block in models[1].blocks)
assert models[1].embedding.weight is models[1].head_out.weight
assert models[0].embedding.weight is not models[0].head_out.weight
for key,value in models[0].state_dict().items():
    if key!='head_out.weight':torch.testing.assert_close(value,models[1].state_dict()[key],rtol=0,atol=0)
optimizers=[build_optimizer(m,c) for m,c in zip(models,(base_config,new_config),strict=True)]
parameters=[p for group in optimizers[1].param_groups for p in group['params']]
assert len(parameters)==len({id(p) for p in parameters})
assert sum(p is models[1].embedding.weight for p in parameters)==1
assert all(p is not models[1].embedding.weight for group in optimizers[1].named_optimizers[0][1].param_groups for p in group['params'])

assert all(len(o.named_optimizers[0][1].param_groups[0]['params'])==96 for o in optimizers)
for step in (1,553,554,555,20000):
    multiplier=warmup_constant_multiplier(optimizer_step=step,warmup_steps=554)
    for opt in optimizers:
        for group in opt.param_groups:group['lr']=base_config['learning_rate']*multiplier*group.get('lr_scale',1.)
    for first,second in zip(optimizers[0].param_groups,optimizers[1].param_groups,strict=True):
        for key in ('lr','weight_decay','lr_scale'):assert first.get(key)==second.get(key)
tokenizer=ProteinTokenizer.esmc()
sequences=[('LAGVESIDPKQNFYMHWCART'*26)[:18+(i*83)%490] for i in range(64)]
tokens,attention=tokenizer.encode_batch(sequences,max_length=512)
tokens,attention=tokens.cuda(),attention.cuda();torch.cuda.manual_seed(24)
corrupted,labels=mask_tokens(tokens,attention,tokenizer)

def step(index):
    model,opt=models[index],optimizers[index];opt.zero_grad(set_to_none=True)
    with torch.autocast('cuda',dtype=torch.bfloat16):
        output=model(corrupted,attention)
        loss,_,_=training_losses(output['logits'],labels,reduction='sqrt_mask_count')
    loss.backward();norm=torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step()
    return loss.detach(),norm.detach()

timings={'hidden1536_ms':[],'tied_ms':[]}
for round_index in range(2):
    for index in ([0,1] if round_index==0 else [1,0]):
        for _ in range(3):loss,norm=step(index)
        torch.cuda.synchronize();start=time.perf_counter()
        for _ in range(6):loss,norm=step(index)
        torch.cuda.synchronize()
        timings[('hidden1536_ms','tied_ms')[index]].append((time.perf_counter()-start)*1000/6)
        assert torch.isfinite(loss) and torch.isfinite(norm)
assert all(torch.isfinite(p).all() and p.grad is not None and torch.isfinite(p.grad).all() for p in models[1].parameters())
assert all(block.ffn.gate_up.weight.grad.count_nonzero()>0 and block.ffn.down.weight.grad.count_nonzero()>0 for block in models[1].blocks)
adam_state=optimizers[1].named_optimizers[1][1].state
shared=models[1].embedding.weight
assert shared in adam_state
assert sum(tuple(state['exp_avg'].shape)==(64,768) for state in adam_state.values())==1
assert all(torch.isfinite(v).all() for state in adam_state.values() for v in state.values() if torch.is_tensor(v))
assert models[1].head_out.weight is shared
small_tokens,small_mask=tokenizer.encode_batch(['ACDEFGHIK','LAGVESIDPKQNFYMHWCA'],max_length=24)
with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16):
    features=models[1](small_tokens.cuda(),small_mask.cuda(),output_attentions=True)
assert len(features['attentions'])==24
assert all(x.shape==(2,12,24,24) and torch.isfinite(x).all() for x in features['attentions'])
peak_memory=torch.cuda.max_memory_allocated()/1024**2
del models,optimizers,features,loss,norm
# Compare variable-length packed training and dense math paths on identical weights.
torch.manual_seed(24)
reference=ESMCForMaskedLM(ESMCConfig.tiny(ffn_hidden_dim=192,tie_word_embeddings=True,attention_backend='math')).cuda()
packed=ESMCForMaskedLM(ESMCConfig.tiny(ffn_hidden_dim=192,tie_word_embeddings=True,attention_backend='flash')).cuda()
packed.load_state_dict(reference.state_dict())
import tempfile
from nano_protein.evaluate import load_checkpoint
with tempfile.TemporaryDirectory() as directory:
    checkpoint=Path(directory)/'tiny.pt'
    torch.save({'model_config':reference.config.to_dict(),'model':reference.state_dict()},checkpoint)
    loaded,_=load_checkpoint(checkpoint,torch.device('cpu'))
    assert loaded.config.ffn_hidden_dim==192 and loaded.config.tie_word_embeddings
    assert loaded.embedding.weight is loaded.head_out.weight
    for key,value in loaded.state_dict().items():
        torch.testing.assert_close(value,reference.state_dict()[key].cpu(),rtol=0,atol=0)
    del loaded
tokens,attention=tokenizer.encode_batch(['ACDEFGHIK','LAGVESIDPKQNFYMHWCA'*3,'GGGGG','ACDEFGHIKLMNPQRSTVWY'*4],max_length=64)
tokens,attention=tokens.cuda(),attention.cuda();corrupted,labels=mask_tokens(tokens,attention,tokenizer)
outputs=[]
for model in (reference,packed):
    with torch.autocast('cuda',dtype=torch.bfloat16):
        output=model(corrupted,attention)
        loss,_,_=training_losses(output['logits'],labels,reduction='sqrt_mask_count')
    loss.backward();outputs.append(output['logits'][attention].detach().float())
max_logit_error=(outputs[0]-outputs[1]).abs().max().item();assert max_logit_error<.03,max_logit_error
se=sr=0.
for a,b in zip(reference.parameters(),packed.parameters(),strict=True):
    assert a.grad is not None and b.grad is not None
    se+=(a.grad-b.grad).float().square().sum().item();sr+=a.grad.float().square().sum().item()
relative_gradient_error=(se/sr)**.5;assert relative_gradient_error<.05,relative_gradient_error
a=statistics.median(timings['hidden1536_ms']);b=statistics.median(timings['tied_ms'])
receipt={'status':'passed','gpu':torch.cuda.get_device_name(0),'parameters':142310464,'removed_parameters':49152,
 'candidate':'Tie head_out.weight to embedding.weight after initialization; same24layer/12head/768residual width and FFN1536, AdamW owns one shared parameter receiving both gradients',
 'initialization_caveat':'All common tensors and initialization RNG preserved; output matrix deliberately uses the input embedding draw; all campaign weights trained from scratch.',
 'source':'Only model.py optional tying/count, train.py config forwarding, new test and paired configs differ from R22',
 'all_fullsize_parameters_and_gradients_finite':True,'ffn_pairs_with_nonzero_gradients':24,'muon_matrices':96,
 'fullsize_contact_feature_layout':[24,12],'shared_parameter_unique_in_optimizer':True,'one_adamw_state_for_64x768_shared_weight':True,'common_initialization_tensors_bitwise_equal':True,'dense_vs_packed_max_logit_error':max_logit_error,'dense_vs_packed_relative_gradient_error':relative_gradient_error,
 'timing_samples':timings,'baseline_median_step_ms':a,'candidate_median_step_ms':b,'tokens_per_second_ratio':a/b,
 'timing_protocol':'Two alternating rounds, each3 warm+6 measured full forward/backward/clip/Muon+AdamW updates on the same64 synthetic masked sequences <=512; no distributed overhead, actual pair establishes throughput',
 'schedule':'Actual groups agree at steps1,553,554,555,20000; exact554-step warmup then fixed configured peaks',
 'data':'Synthetic protein sequences only; no held-out or training data','peak_memory_mb_two_models':peak_memory}
(root/'MODEL_PREFLIGHT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
