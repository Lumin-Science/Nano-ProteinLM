"""Verify selective final tokenwise work preserves MLM values and all gradients."""

import copy
import tempfile
import unittest
from pathlib import Path

import torch
import torch.distributed as dist
import torch.multiprocessing as mp
from torch.nn.parallel import DistributedDataParallel as DDP

from nano_protein.evaluate import load_checkpoint
from nano_protein.model import ESMCConfig, ESMCForMaskedLM
from nano_protein.train import training_losses


def inputs():
    tokens = torch.tensor([[0, 32, 5, 6, 2, 1], [0, 7, 32, 8, 9, 2]])
    labels = torch.full_like(tokens, -100)
    labels[0, 1] = 4
    labels[1, 2] = 10
    return tokens, tokens.ne(1), labels


def distributed_worker(rank, rendezvous):
    torch.set_num_threads(1)
    torch.manual_seed(20)
    dist.init_process_group("gloo", init_method=rendezvous, rank=rank, world_size=2)
    try:
        base = ESMCForMaskedLM(ESMCConfig.tiny(attention_backend="math")).double()
        subset = DDP(copy.deepcopy(base))
        base = DDP(base)
        tokens, attention, labels = inputs()
        labels[0] = -100
        tokens, attention, labels = (x[rank : rank + 1] for x in (tokens, attention, labels))
        for model, options in ((base, {}), (subset, {"prediction_mask": labels.ne(-100)})):
            loss, _, _ = training_losses(
                model(tokens, attention, **options)["logits"],
                labels,
                reduction="sqrt_mask_count",
            )
            loss.backward()
        for a, b in zip(base.parameters(), subset.parameters(), strict=True):
            torch.testing.assert_close(a.grad, b.grad, rtol=1e-8, atol=1e-10)
    finally:
        dist.destroy_process_group()


class LastLayerSubsetTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1)
        torch.manual_seed(20)

    def test_logits_hidden_and_all_gradients_for_sparse_all_and_empty_targets(self):
        tokens, attention, sparse = inputs()
        for labels in (
            sparse,
            tokens.masked_fill(~attention, -100),
            torch.full_like(tokens, -100),
        ):
            for routing in (False, True):
                base = ESMCForMaskedLM(
                    ESMCConfig.tiny(attention_backend="math", learned_residual_routing=routing)
                ).double()
                subset = copy.deepcopy(base)
                selected = labels.ne(-100)
                rng = torch.get_rng_state()
                a = base(tokens, attention)
                b = subset(tokens, attention, prediction_mask=selected)
                self.assertTrue(torch.equal(rng, torch.get_rng_state()))
                torch.testing.assert_close(
                    a["logits"][selected], b["logits"][selected], rtol=1e-9, atol=1e-11
                )
                torch.testing.assert_close(
                    a["last_hidden_state"][selected],
                    b["last_hidden_state"][selected],
                    rtol=1e-9,
                    atol=1e-11,
                )
                self.assertEqual(b["logits"][~selected].count_nonzero(), 0)
                la, da, oa = training_losses(a["logits"], labels, reduction="sqrt_mask_count")
                lb, db, ob = training_losses(b["logits"], labels, reduction="sqrt_mask_count")
                for first, second in ((la, lb), (da, db), (oa, ob)):
                    torch.testing.assert_close(first, second, rtol=1e-9, atol=1e-11)
                la.backward()
                lb.backward()
                for first, second in zip(base.parameters(), subset.parameters(), strict=True):
                    self.assertIsNotNone(first.grad)
                    self.assertIsNotNone(second.grad)
                    torch.testing.assert_close(first.grad, second.grad, rtol=1e-8, atol=1e-10)

    def test_frozen_loading_and_feature_contract(self):
        model = ESMCForMaskedLM(ESMCConfig.tiny(attention_backend="math"))
        tokens, attention, labels = inputs()
        selected = labels.ne(-100)
        for options in ({"output_attentions": True}, {"output_hidden_states": True}):
            with self.assertRaises(ValueError):
                model(tokens, attention, prediction_mask=selected, **options)
        with self.assertRaises(ValueError):
            model(tokens, attention, prediction_mask=selected.long())
        with self.assertRaises(ValueError):
            model(tokens, attention, prediction_mask=selected[:1])
        expected = model(tokens, attention, output_attentions=True)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "checkpoint.pt"
            torch.save(
                {"model_config": model.config.to_dict(), "model": model.state_dict()}, path
            )
            loaded, _ = load_checkpoint(path, torch.device("cpu"))
        actual = loaded(tokens, attention, output_attentions=True)
        torch.testing.assert_close(expected["logits"], actual["logits"], rtol=0, atol=0)
        for a, b in zip(expected["attentions"], actual["attentions"], strict=True):
            torch.testing.assert_close(a, b, rtol=0, atol=0)

    def test_actual_two_rank_ddp_with_empty_target_rank(self):
        with tempfile.TemporaryDirectory() as directory:
            mp.spawn(
                distributed_worker,
                args=(f"file://{directory}/rendezvous",),
                nprocs=2,
                join=True,
            )


if __name__ == "__main__":
    unittest.main()
