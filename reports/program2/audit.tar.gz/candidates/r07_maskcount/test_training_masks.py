import math
import unittest
from unittest.mock import patch

import torch

from nano_protein.tokenizer import ProteinTokenizer, mask_tokens
from nano_protein.training_masks import (
    expected_target_count,
    mask_count_statistics,
    mask_tokens_rounded_count,
)


class RoundedMaskTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1)
        self.tokenizer = ProteinTokenizer.esmc()

    def test_expected_count_matches_exact_forced_bernoulli_distribution(self):
        for n in range(12):
            exact = sum(
                (max(1, k) if n else 0) * math.comb(n, k) * 0.15**k * 0.85 ** (n - k)
                for k in range(n + 1)
            )
            observed = expected_target_count(torch.tensor([n]), 0.15).item()
            self.assertAlmostEqual(observed, exact, places=6)
        for probability in (0, 1, -0.1, float("nan")):
            with self.assertRaises(ValueError):
                expected_target_count(torch.tensor([3]), probability)

    def test_masks_only_eligible_tokens_and_preserves_labels_and_inputs(self):
        counts = [0, 1, 2, 3, 7, 32, 100, 510]
        sequences = ["L" * n + "X.-" for n in counts]
        tokens, attention = self.tokenizer.encode_batch(sequences, max_length=520)
        # Canonical-looking padding must never become a target.
        tokens[~attention] = self.tokenizer.token_to_id["A"]
        original, original_attention = tokens.clone(), attention.clone()
        masked, labels = mask_tokens_rounded_count(
            tokens, attention, self.tokenizer, generator=torch.Generator().manual_seed(42)
        )
        selected = labels != -100
        eligible = attention & (tokens == self.tokenizer.token_to_id["L"])
        self.assertFalse((selected & ~eligible).any())
        torch.testing.assert_close(labels[selected], tokens[selected])
        torch.testing.assert_close(masked[~selected], tokens[~selected])
        self.assertTrue((masked[selected] == self.tokenizer.mask_id).all())
        torch.testing.assert_close(tokens, original)
        torch.testing.assert_close(attention, original_attention)
        mean = expected_target_count(torch.tensor(counts), 0.15)
        actual = selected.sum(dim=1)
        self.assertTrue(((actual == mean.floor()) | (actual == mean.ceil())).all())
        self.assertEqual(actual[0].item(), 0)
        self.assertTrue((actual[1:] > 0).all())

    def test_seed_reproducibility_and_external_rng_isolation(self):
        tokens, attention = self.tokenizer.encode_batch(["ACDEFGHIKL" * 8] * 3, max_length=96)
        before = torch.get_rng_state().clone()
        a = mask_tokens_rounded_count(
            tokens, attention, self.tokenizer, generator=torch.Generator().manual_seed(11)
        )
        b = mask_tokens_rounded_count(
            tokens, attention, self.tokenizer, generator=torch.Generator().manual_seed(11)
        )
        torch.testing.assert_close(torch.get_rng_state(), before)
        for x, y in zip(a, b, strict=True):
            torch.testing.assert_close(x, y)
        c = mask_tokens_rounded_count(
            tokens, attention, self.tokenizer, generator=torch.Generator().manual_seed(12)
        )
        self.assertFalse(torch.equal(a[1], c[1]))

    def test_count_variance_and_uniform_marginals(self):
        n, trials = 32, 32768
        tokens = torch.full((trials, n), self.tokenizer.token_to_id["L"])
        attention = torch.ones_like(tokens, dtype=torch.bool)
        _, labels = mask_tokens_rounded_count(
            tokens, attention, self.tokenizer, generator=torch.Generator().manual_seed(123)
        )
        _, baseline = mask_tokens(
            tokens, attention, self.tokenizer, generator=torch.Generator().manual_seed(456)
        )
        selected = labels != -100
        counts = selected.sum(dim=1).float()
        expected = n * 0.15 + 0.85**n
        self.assertLess(abs(counts.mean().item() - expected), 0.015)
        self.assertLess((selected.float().mean(dim=0) - expected / n).abs().max().item(), 0.01)
        self.assertLess(counts.var().item(), 0.25)
        self.assertGreater((baseline != -100).sum(dim=1).float().var().item(), 3.0)
        self.assertTrue(
            ((counts == math.floor(expected)) | (counts == math.ceil(expected))).all()
        )

    def test_integer_expectation_cannot_round_up_from_fp32_addition(self):
        tokens = torch.full((1, 100), self.tokenizer.token_to_id["L"])
        attention = torch.ones_like(tokens, dtype=torch.bool)
        near_one = torch.tensor([1.0 - 2**-24])
        priorities = torch.arange(100, dtype=torch.float32).view(1, 100) / 100
        with patch("torch.rand", side_effect=[near_one, priorities]):
            _, labels = mask_tokens_rounded_count(
                tokens, attention, self.tokenizer, probability=0.5
            )
        self.assertEqual((labels != -100).sum().item(), 50)

    def test_diagnostics_survive_example_redistribution(self):
        tokens, attention = self.tokenizer.encode_batch(
            ["A" * 32, "GX.-" * 12, "X" * 5, "LP" * 100], max_length=256
        )
        masked, labels = mask_tokens_rounded_count(
            tokens, attention, self.tokenizer, generator=torch.Generator().manual_seed(7)
        )
        order = torch.tensor([3, 0, 2, 1])
        stats = mask_count_statistics(
            masked[order], labels[order], attention[order], self.tokenizer
        )
        self.assertEqual(stats["eligible"], [200, 32, 0, 12])
        self.assertEqual(stats["selected"], (labels[order] != -100).sum(dim=1).tolist())


if __name__ == "__main__":
    unittest.main()
