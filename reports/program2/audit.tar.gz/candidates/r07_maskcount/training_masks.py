"""Training-only alternatives to the frozen evaluator's Bernoulli corruption."""

import torch

from .tokenizer import ProteinTokenizer


def expected_target_count(eligible_counts: torch.Tensor, probability: float) -> torch.Tensor:
    """Mean of max(1, Binomial(n, p)), with zero targets when n is zero."""
    if not 0.0 < probability < 1.0:
        raise ValueError("mask probability must lie in (0, 1)")
    counts = eligible_counts.to(torch.float32)
    expected = probability * counts + (1 - probability) ** counts
    return torch.where(eligible_counts > 0, expected, 0.0)


def mask_tokens_rounded_count(
    input_ids: torch.Tensor,
    attention_mask: torch.Tensor,
    tokenizer: ProteinTokenizer,
    *,
    probability: float = 0.15,
    generator: torch.Generator | None = None,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Uniform subset with stochastically rounded expected target count.

    Preserve the incumbent's expected count and uniform per-position marginals,
    including its forced-one-target correction. The joint mask distribution
    changes: counts take only the adjacent integers around their expectation.
    """
    canonical = torch.tensor(tokenizer.canonical_ids, device=input_ids.device)
    eligible = attention_mask & torch.isin(input_ids, canonical)
    eligible_counts = eligible.sum(dim=1)
    expected = expected_target_count(eligible_counts, probability)
    count_noise = torch.rand(expected.shape, device=input_ids.device, generator=generator)
    lower = expected.floor()
    # Compare the fractional part directly: adding near-one FP32 noise can
    # round an integer expectation up to an impossible extra target.
    targets = (lower.long() + (count_noise < expected - lower).long()).minimum(eligible_counts)
    targets = torch.where(eligible_counts > 0, targets.clamp_min(1), 0)
    priorities = torch.rand(input_ids.shape, device=input_ids.device, generator=generator)
    order = priorities.masked_fill(~eligible, float("inf")).argsort(dim=1)
    take = torch.arange(input_ids.shape[1], device=input_ids.device)[None, :] < targets[:, None]
    selected = torch.zeros_like(eligible).scatter_(1, order, take)
    labels = input_ids.masked_fill(~selected, -100)
    return input_ids.masked_fill(selected, tokenizer.mask_id), labels


def mask_count_statistics(corrupted, labels, attention_mask, tokenizer):
    """Rank-local last-microbatch diagnostics, reconstructed after redistribution."""
    selected = labels != -100
    canonical = torch.tensor(tokenizer.canonical_ids, device=corrupted.device)
    eligible = attention_mask & (selected | torch.isin(corrupted, canonical))
    return {
        "selected": selected.sum(dim=1).tolist(),
        "eligible": eligible.sum(dim=1).tolist(),
    }
