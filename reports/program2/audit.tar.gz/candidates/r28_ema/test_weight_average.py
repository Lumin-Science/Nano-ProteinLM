"""Check EMA recurrence, training isolation and the exact frozen checkpoint path."""

import copy
import tempfile
import unittest
from pathlib import Path

import torch

from nano_protein.evaluate import load_checkpoint
from nano_protein.model import ESMCConfig, ESMCForMaskedLM, count_parameters
from nano_protein.train import save_checkpoint
from nano_protein.weight_average import ExponentialWeightAverage


class WeightAverageTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1)
        torch.manual_seed(28)

    def test_closed_form_start_boundary_and_nonfloating_buffers(self):
        model = torch.nn.Linear(2, 1, bias=False).double()
        model.register_buffer("counter", torch.tensor(0))
        average = ExponentialWeightAverage(decay=0.5, start_step=3)
        rng = torch.get_rng_state()
        with torch.no_grad():
            model.weight.fill_(99)
        for step in (1, 2):
            average.update(model, optimizer_step=step)
        self.assertEqual(average.num_updates, 0)
        with self.assertRaises(RuntimeError):
            average.averaged_state_dict()
        for step, values in enumerate(([2.0, 4.0], [6.0, 8.0], [10.0, 12.0]), start=3):
            with torch.no_grad():
                model.weight.copy_(torch.tensor([values]))
                model.counter.fill_(step)
            average.update(model, optimizer_step=step)
        expected = torch.tensor([[7.0, 9.0]], dtype=torch.float64)
        torch.testing.assert_close(
            average.averaged_state_dict()["weight"], expected, rtol=0, atol=0
        )
        self.assertEqual(average.averaged_state_dict()["counter"].item(), 5)
        self.assertEqual((average.num_updates, average.last_step), (3, 5))
        self.assertTrue(torch.equal(rng, torch.get_rng_state()))
        self.assertFalse(average.averaged_state_dict()["weight"].requires_grad)
        self.assertNotEqual(
            average.averaged_state_dict()["weight"].data_ptr(), model.weight.data_ptr()
        )

    def test_online_training_and_optimizer_state_remain_bitwise_identical(self):
        a = ESMCForMaskedLM(ESMCConfig.tiny(ffn_hidden_dim=192, attention_backend="math"))
        b = copy.deepcopy(a)
        x = torch.optim.SGD(a.parameters(), lr=0.01, momentum=0.9)
        y = torch.optim.SGD(b.parameters(), lr=0.01, momentum=0.9)
        average = ExponentialWeightAverage(decay=0.999, start_step=2)
        tokens = torch.tensor([[0, 4, 5, 6, 2], [0, 7, 8, 2, 1]])
        for step in range(1, 6):
            for model, optimizer in ((a, x), (b, y)):
                optimizer.zero_grad()
                model(tokens, tokens != 1)["logits"].square().mean().backward()
                optimizer.step()
            average.update(b, optimizer_step=step)
            for p, q in zip(a.parameters(), b.parameters(), strict=True):
                torch.testing.assert_close(p, q, rtol=0, atol=0)
                torch.testing.assert_close(
                    x.state[p]["momentum_buffer"], y.state[q]["momentum_buffer"], rtol=0, atol=0
                )
        self.assertEqual(count_parameters(a), count_parameters(b))
        self.assertEqual(average.num_updates, 4)
        self.assertTrue(
            any(
                not torch.equal(v, b.state_dict()[k])
                for k, v in average.averaged_state_dict().items()
            )
        )

    def test_frozen_loader_gets_ema_and_optimizer_retains_online_weights(self):
        model = ESMCForMaskedLM(ESMCConfig.tiny(ffn_hidden_dim=192, attention_backend="math"))
        optimizer = torch.optim.SGD(model.parameters(), lr=0.01, momentum=0.9)
        average = ExponentialWeightAverage(decay=0.75, start_step=1)
        tokens = torch.tensor([[0, 4, 5, 2], [0, 7, 2, 1]])
        for step in (1, 2, 3):
            optimizer.zero_grad()
            model(tokens, tokens != 1)["logits"].square().mean().backward()
            optimizer.step()
            average.update(model, optimizer_step=step)
        kwargs = dict(
            model=model,
            optimizer=optimizer,
            config={"ema_decay": 0.75},
            optimizer_step=3,
            training_seconds=3600.0,
            model_tokens=42,
            filled_residues=30,
            sequences_seen=6,
            stage="stage1",
            parameter_count=count_parameters(model),
        )
        expected = copy.deepcopy(model)
        expected.load_state_dict(average.averaged_state_dict())
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "ema.pt"
            save_checkpoint(path, **kwargs, weight_average=average)
            loaded, saved = load_checkpoint(path, torch.device("cpu"))
            for key, value in model.state_dict().items():
                torch.testing.assert_close(saved["online_model"][key], value, rtol=0, atol=0)
                torch.testing.assert_close(
                    saved["model"][key], average.averaged_state_dict()[key], rtol=0, atol=0
                )
            self.assertEqual(saved["weight_averaging"], average.metadata())
            self.assertEqual(saved["weight_averaging"]["optimizer_weights"], "online_model")
            a = loaded(tokens, tokens != 1, output_attentions=True)
            b = expected(tokens, tokens != 1, output_attentions=True)
            torch.testing.assert_close(a["logits"], b["logits"], rtol=0, atol=0)
            for x, y in zip(a["attentions"], b["attentions"], strict=True):
                torch.testing.assert_close(x, y, rtol=0, atol=0)
            legacy = Path(directory) / "legacy.pt"
            save_checkpoint(legacy, **kwargs)
            packet = torch.load(legacy, weights_only=False)
            self.assertNotIn("weight_averaging", packet)
            self.assertNotIn("online_model", packet)
            for key, value in model.state_dict().items():
                torch.testing.assert_close(packet["model"][key], value, rtol=0, atol=0)
            with self.assertRaises(ValueError):
                save_checkpoint(path, **dict(kwargs, optimizer_step=4), weight_average=average)

    def test_invalid_decay_missing_steps_and_changed_model_state(self):
        for decay in (-0.1, 1.0, float("nan"), float("inf")):
            with self.assertRaises(ValueError):
                ExponentialWeightAverage(decay=decay, start_step=554)
        for start in (0, -1, True, 1.5):
            with self.assertRaises(ValueError):
                ExponentialWeightAverage(decay=0.999, start_step=start)
        model = torch.nn.Linear(2, 1)
        average = ExponentialWeightAverage(decay=0.999, start_step=3)
        with self.assertRaises(ValueError):
            average.update(model, optimizer_step=4)
        average.update(model, optimizer_step=3)
        with self.assertRaises(ValueError):
            average.update(model, optimizer_step=3)
        with self.assertRaises(ValueError):
            average.update(model, optimizer_step=5)
        with self.assertRaises(ValueError):
            average.update(torch.nn.Linear(3, 1), optimizer_step=4)


if __name__ == "__main__":
    unittest.main()
