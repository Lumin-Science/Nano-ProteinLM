"""Online EMA shadows for final checkpoint weights, independent of the trained model."""

import math

import torch


class ExponentialWeightAverage:
    """Start with a post-update copy, then average every subsequent optimizer iterate."""

    def __init__(self, *, decay: float, start_step: int):
        if not math.isfinite(decay) or not 0 <= decay < 1:
            raise ValueError("EMA decay must be finite and in [0, 1)")
        if not isinstance(start_step, int) or isinstance(start_step, bool) or start_step < 1:
            raise ValueError("EMA start_step must be a positive integer")
        self.decay = decay
        self.start_step = start_step
        self.last_step = 0
        self.num_updates = 0
        self._shadow: dict[str, torch.Tensor] = {}

    @torch.no_grad()
    def update(self, model: torch.nn.Module, *, optimizer_step: int) -> None:
        if optimizer_step < self.start_step:
            return
        expected_step = self.start_step if not self.num_updates else self.last_step + 1
        if optimizer_step != expected_step:
            raise ValueError("EMA must receive every optimizer step from start_step onward")
        state = model.state_dict()
        if not self.num_updates:
            self._shadow = {name: value.detach().clone() for name, value in state.items()}
        else:
            if state.keys() != self._shadow.keys():
                raise ValueError("model state changed during EMA")
            floating = []
            for name, value in state.items():
                shadow = self._shadow[name]
                if (value.shape, value.dtype, value.device) != (
                    shadow.shape,
                    shadow.dtype,
                    shadow.device,
                ):
                    raise ValueError(f"model state changed during EMA: {name}")
                if value.is_floating_point():
                    floating.append(name)
                else:
                    shadow.copy_(value)
            if floating:
                torch._foreach_lerp_(
                    [self._shadow[name] for name in floating],
                    [state[name] for name in floating],
                    1 - self.decay,
                )
        self.last_step = optimizer_step
        self.num_updates += 1

    def averaged_state_dict(self) -> dict[str, torch.Tensor]:
        if not self.num_updates:
            raise RuntimeError("EMA has not reached its first update")
        return self._shadow

    def metadata(self) -> dict[str, object]:
        return {
            "method": "ema",
            "decay": self.decay,
            "start_step": self.start_step,
            "last_step": self.last_step,
            "num_updates": self.num_updates,
            "evaluation_weights": "model",
            "optimizer_weights": "online_model",
        }
