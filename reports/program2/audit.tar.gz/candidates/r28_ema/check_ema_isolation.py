"""Qualify EMA cost and unchanged online training on an actual L40S."""
import copy, json, statistics, time
from pathlib import Path
import torch,yaml
from nano_protein.model import ESMCConfig, ESMCForMaskedLM, count_parameters, expected_parameter_count
from nano_protein.tokenizer import ProteinTokenizer,mask_tokens
from nano_protein.train import build_optimizer,training_losses
from nano_protein.schedule import warmup_constant_multiplier

torch.set_num_threads(1);torch.set_float32_matmul_precision('high')
assert torch.cuda.get_device_name(0)=='NVIDIA L40S'
root=Path('.dev/program2/candidates/r28_ema')
base_config=yaml.safe_load(Path('configs/program2/r22_ffn1536_seed42.yaml').read_text())
new_config=yaml.safe_load(Path('configs/program2/r28_ema_seed42.yaml').read_text())
expected=copy.deepcopy(base_config);expected.update(ema_decay=.999)
assert new_config==expected
models=[]
for index in (0,1):
    torch.manual_seed(24)
    models.append(ESMCForMaskedLM(ESMCConfig.esmc_171m(ffn_hidden_dim=1536)).cuda())
assert [count_parameters(m) for m in models]==[142359616,142359616]
assert expected_parameter_count(models[1].config)==142359616
assert all(block.ffn.gate_up.weight.shape==(3072,768) and block.ffn.down.weight.shape==(768,1536) for block in models[1].blocks)
optimizers=[build_optimizer(m,c) for m,c in zip(models,(base_config,new_config),strict=True)]
assert all(len(o.named_optimizers[0][1].param_groups[0]['params'])==96 for o in optimizers)
for step in (1,553,554,555,20000):
    multiplier=warmup_constant_multiplier(optimizer_step=step,warmup_steps=554)
    for opt in optimizers:
        for group in opt.param_groups:group['lr']=base_config['learning_rate']*multiplier*group.get('lr_scale',1.)
    for first,second in zip(optimizers[0].param_groups,optimizers[1].param_groups,strict=True):
        for key in ('lr','weight_decay','lr_scale'):assert first.get(key)==second.get(key)
tokenizer=ProteinTokenizer.esmc()
sequences=[('LAGVESIDPKQNFYMHWCART'*26)[:18+(i*83)%490] for i in range(64)]
tokens,attention=tokenizer.encode_batch(sequences,max_length=512)
tokens,attention=tokens.cuda(),attention.cuda();torch.cuda.manual_seed(24)
corrupted,labels=mask_tokens(tokens,attention,tokenizer)


from nano_protein.weight_average import ExponentialWeightAverage

def update(index):
    model,opt=models[index],optimizers[index]
    opt.zero_grad(set_to_none=True)
    with torch.autocast('cuda',dtype=torch.bfloat16):
        output=model(corrupted,attention)
        loss,_,_=training_losses(output['logits'],labels,reduction='sqrt_mask_count')
    loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step()
    assert torch.isfinite(loss)
    return float(loss)

def delta():
    maximum=0.;squared=0.;different=0
    for a,b in zip(models[0].parameters(),models[1].parameters(),strict=True):
        d=(a-b).float()
        maximum=max(maximum,d.abs().max().item());squared+=d.square().sum().item()
        different+=torch.count_nonzero(d).item()
    return {'maximum_absolute_parameter_difference':maximum,'parameter_l2_difference':squared**.5,'different_parameter_elements':different}

checks=[{'after_steps':0,**delta()}]
assert checks[0]['different_parameter_elements']==0
for round_index in range(2):
    for index in ([0,1] if round_index==0 else [1,0]):
        for _ in range(9):update(index)
    checks.append({'after_steps':9*(round_index+1),**delta()})
    print(json.dumps(checks[-1]),flush=True)

def clone_tree(value):
    if torch.is_tensor(value):return value.detach().clone()
    if isinstance(value,dict):return {k:clone_tree(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return type(value)(clone_tree(v) for v in value)
    return copy.deepcopy(value)

def assert_equal(a,b):
    if torch.is_tensor(a):assert torch.equal(a,b)
    elif isinstance(a,dict):
        assert a.keys()==b.keys()
        for k in a:assert_equal(a[k],b[k])
    elif isinstance(a,(list,tuple)):
        assert len(a)==len(b)
        for x,y in zip(a,b,strict=True):assert_equal(x,y)
    else:assert a==b

average=ExponentialWeightAverage(decay=.999,start_step=1)
for ema_step in (1,2):
    if ema_step==2:update(1)
    model=models[1];opt=optimizers[1]
    snapshot=clone_tree({'model':model.state_dict(),'gradients':[p.grad for p in model.parameters()],'optimizer':opt.state_dict()})
    cpu_rng=torch.get_rng_state().clone();cuda_rng=torch.cuda.get_rng_state().clone()
    average.update(model,optimizer_step=ema_step)
    torch.cuda.synchronize()
    assert_equal(snapshot,{'model':model.state_dict(),'gradients':[p.grad for p in model.parameters()],'optimizer':opt.state_dict()})
    assert torch.equal(cpu_rng,torch.get_rng_state()) and torch.equal(cuda_rng,torch.cuda.get_rng_state())
    assert all(v.data_ptr()!=model.state_dict()[k].data_ptr() for k,v in average.averaged_state_dict().items())
    del snapshot
    print('EMA direct isolation passed at update',ema_step,flush=True)
receipt={'status':'passed','gpu':torch.cuda.get_device_name(0),'parameters':142359616,
 'ema_disabled_in_both_trajectory_control':checks,
 'direct_ema_initialization_and_lerp_preserve_all_online_parameters_gradients_optimizer_states_and_cpu_cuda_rng_bitwise':True,
 'all_ema_shadow_storage_distinct_from_online':True,
 'interpretation':'EMA-disabled full-size GPU trajectories diverge despite identical initialization and fixed input. No unique kernel cause established; direct EMA isolation and CPU trajectory tests establish no online mutation. Bitwise equality between independently executed GPU trajectories is not asserted.'}
(root/'EMA_ISOLATION_PREFLIGHT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
