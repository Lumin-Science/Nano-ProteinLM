import copy
import tempfile
import unittest
from pathlib import Path

import torch
import torch.distributed as dist
import torch.multiprocessing as mp
from torch.nn.parallel import DistributedDataParallel as DDP

from nano_protein.model import ESMCConfig, ESMCForMaskedLM
from nano_protein.split_muon import SplitQKVMuon
from nano_protein.train import build_optimizer

OPTIONS = dict(lr=0.003, momentum=0.95, weight_decay=0.1, adjust_lr_fn="match_rms_adamw")


def ddp_worker(rank, rendezvous):
    torch.set_num_threads(1)
    dist.init_process_group("gloo", init_method=f"file://{rendezvous}", rank=rank, world_size=2)
    try:
        torch.manual_seed(69)
        layer = torch.nn.Linear(4, 12, bias=False)
        original = layer.weight.detach().clone()
        wrapped = DDP(layer, gradient_as_bucket_view=True)
        optimizer = SplitQKVMuon(layer.parameters(), qkv_parameters=[layer.weight], **OPTIONS)
        inputs = torch.arange(32, dtype=torch.float32).reshape(8, 4) / 32
        targets = torch.cos(torch.arange(96, dtype=torch.float32).reshape(8, 12))
        # Unequal rank-local values; equal sample counts match the campaign.
        optimizer.zero_grad()
        local = slice(rank * 4, (rank + 1) * 4)
        (wrapped(inputs[local]) - targets[local]).square().mean().backward()
        reference = torch.nn.Parameter(original.clone())
        (inputs @ reference.T - targets).square().mean().backward()
        torch.testing.assert_close(layer.weight.grad, reference.grad)
        torch.nn.utils.clip_grad_norm_(layer.parameters(), 0.25)
        blocks = [torch.nn.Parameter(part.clone()) for part in original.chunk(3)]
        native = torch.optim.Muon(blocks, **OPTIONS)
        for block, gradient in zip(blocks, layer.weight.grad.chunk(3), strict=True):
            block.grad = gradient.clone()
        optimizer.step()
        native.step()
        torch.testing.assert_close(layer.weight, torch.cat(blocks), rtol=0, atol=0)
        copies = [torch.empty_like(layer.weight) for _ in range(2)]
        dist.all_gather(copies, layer.weight.detach())
        torch.testing.assert_close(copies[0], copies[1], rtol=0, atol=0)
        optimizer.zero_grad(set_to_none=True)
        assert layer.weight.grad is None
    finally:
        dist.destroy_process_group()


class SplitMuonTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1)
        torch.manual_seed(17)

    def test_updates_and_momentum_match_independent_native_qkv(self):
        fused = torch.nn.Parameter(torch.randn(12, 4))
        other = torch.nn.Parameter(torch.randn(8, 4))
        blocks = [torch.nn.Parameter(part.detach().clone()) for part in fused.chunk(3)]
        other_reference = torch.nn.Parameter(other.detach().clone())
        optimizer = SplitQKVMuon([fused, other], qkv_parameters=[fused], **OPTIONS)
        native = torch.optim.Muon([*blocks, other_reference], **OPTIONS)
        for step in range(5):
            gradient = torch.randn_like(fused)
            gradient[:4] *= 0.01
            gradient[8:] *= 10
            fused.grad = gradient.clone()
            other.grad = torch.randn_like(other)
            for block, chunk in zip(blocks, gradient.chunk(3), strict=True):
                block.grad = chunk.clone()
            other_reference.grad = other.grad.clone()
            # Exercise scheduling through the original parameter groups.
            optimizer.param_groups[0]["lr"] = native.param_groups[0]["lr"] = 0.001 * (step + 1)
            optimizer.step()
            native.step()
            torch.testing.assert_close(fused, torch.cat(blocks), rtol=0, atol=0)
            torch.testing.assert_close(other, other_reference, rtol=0, atol=0)
            expected = torch.cat([native.state[p]["momentum_buffer"] for p in blocks])
            torch.testing.assert_close(optimizer.state[fused]["momentum_buffer"], expected)
        self.assertEqual(len(optimizer.state), 2)
        self.assertIs(optimizer.param_groups[0]["params"][0], fused)

    def test_checkpoint_roundtrip_and_missing_gradient(self):
        parameter = torch.nn.Parameter(torch.randn(12, 4))
        optimizer = SplitQKVMuon([parameter], qkv_parameters=[parameter], **OPTIONS)
        parameter.grad = torch.randn_like(parameter)
        optimizer.step()
        restored = torch.nn.Parameter(parameter.detach().clone())
        resumed = SplitQKVMuon([restored], qkv_parameters=[restored], **OPTIONS)
        resumed.load_state_dict(copy.deepcopy(optimizer.state_dict()))
        gradient = torch.randn_like(parameter)
        parameter.grad, restored.grad = gradient.clone(), gradient.clone()
        optimizer.step()
        resumed.step()
        torch.testing.assert_close(parameter, restored, rtol=0, atol=0)
        resumed.zero_grad(set_to_none=True)
        before = restored.detach().clone()
        momentum = resumed.state[restored]["momentum_buffer"].clone()
        resumed.step()
        torch.testing.assert_close(restored, before, rtol=0, atol=0)
        torch.testing.assert_close(resumed.state[restored]["momentum_buffer"], momentum)
        restored.grad = torch.ones_like(restored)
        resumed.zero_grad(set_to_none=False)
        self.assertEqual(restored.grad.count_nonzero().item(), 0)

    def test_build_optimizer_selects_only_qkv_and_retains_default(self):
        model = ESMCForMaskedLM(ESMCConfig.tiny(attention_backend="math"))
        config = dict(optimizer="muon", learning_rate=0.001, weight_decay=0.1)
        baseline = build_optimizer(model, config)
        self.assertIs(type(baseline.named_optimizers[0][1]), torch.optim.Muon)
        optimizer = build_optimizer(model, {**config, "muon_split_qkv": True})
        muon = optimizer.named_optimizers[0][1]
        self.assertIsInstance(muon, SplitQKVMuon)
        expected = {id(block.attention.qkv.weight) for block in model.blocks}
        self.assertEqual(muon.qkv_parameter_ids, expected)
        ids = [id(p) for group in optimizer.param_groups for p in group["params"]]
        self.assertEqual(len(ids), len(set(ids)))
        self.assertEqual(set(ids), {id(p) for p in model.parameters()})

    def test_rejects_invalid_selection(self):
        valid = torch.nn.Parameter(torch.randn(12, 4))
        invalid = torch.nn.Parameter(torch.randn(8, 4))
        for selection in ([], [invalid], [valid, valid]):
            with self.assertRaises(ValueError):
                SplitQKVMuon([valid], qkv_parameters=selection, **OPTIONS)
        with self.assertRaises(ValueError):
            SplitQKVMuon([invalid], qkv_parameters=[valid], **OPTIONS)

    def test_real_ddp_matches_pooled_gradient_and_independent_updates(self):
        with tempfile.TemporaryDirectory() as directory:
            mp.spawn(
                ddp_worker, args=(str(Path(directory) / "rendezvous"),), nprocs=2, join=True
            )


if __name__ == "__main__":
    unittest.main()
