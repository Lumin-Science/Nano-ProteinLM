"""Q/K/V-wise Muon updates while retaining fused model and optimizer storage."""

from collections.abc import Iterable

import torch


class SplitQKVMuon(torch.optim.Muon):
    """Use native Muon on three row blocks of each selected fused QKV weight.

    Parameters, gradients and momentum stay owned by the original fused weight.
    Only the temporary update lists contain views, so DDP, gradient clearing,
    checkpoint keys and the model's single QKV GEMM retain their usual behavior.
    The private preparation hook is covered against the frozen Torch version.
    """

    def __init__(self, params, *, qkv_parameters: Iterable[torch.nn.Parameter], **kwargs):
        selected = tuple(qkv_parameters)
        if not selected:
            raise ValueError("split-QKV Muon requires at least one QKV parameter")
        if len({id(p) for p in selected}) != len(selected):
            raise ValueError("duplicate split-QKV parameter")
        for parameter in selected:
            if parameter.ndim != 2 or parameter.shape[0] != 3 * parameter.shape[1]:
                raise ValueError("split-QKV requires a fused [3 * width, width] weight")
        super().__init__(params, **kwargs)
        owned = {id(p) for group in self.param_groups for p in group["params"]}
        self.qkv_parameter_ids = {id(p) for p in selected}
        if not self.qkv_parameter_ids <= owned:
            raise ValueError("split-QKV parameter is absent from optimizer groups")

    def _init_group(self, group, params_with_grad, grads, muon_momentum_bufs):
        has_complex = super()._init_group(group, params_with_grad, grads, muon_momentum_bufs)
        parameters, gradients, momentum_buffers = [], [], []
        for parameter, gradient, momentum in zip(
            params_with_grad, grads, muon_momentum_bufs, strict=True
        ):
            if id(parameter) in self.qkv_parameter_ids:
                parameters.extend(parameter.chunk(3, dim=0))
                gradients.extend(gradient.chunk(3, dim=0))
                momentum_buffers.extend(momentum.chunk(3, dim=0))
            else:
                parameters.append(parameter)
                gradients.append(gradient)
                momentum_buffers.append(momentum)
        params_with_grad[:] = parameters
        grads[:] = gradients
        muon_momentum_bufs[:] = momentum_buffers
        return has_complex
