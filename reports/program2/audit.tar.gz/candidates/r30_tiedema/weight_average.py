"""EMA shadows for final evaluation, preserving shared parameters without feedback."""

import math

import torch


class ExponentialWeightAverage:
    """Average each unique post-update tensor once and preserve its state-dict aliases."""

    def __init__(self, *, decay: float, start_step: int):
        if not math.isfinite(decay) or not 0 <= decay < 1:
            raise ValueError("EMA decay must be finite and in [0, 1)")
        if not isinstance(start_step, int) or isinstance(start_step, bool) or start_step < 1:
            raise ValueError("EMA start_step must be a positive integer")
        self.decay = decay
        self.start_step = start_step
        self.last_step = 0
        self.num_updates = 0
        self._shadow: dict[str, torch.Tensor] = {}
        self._owners: dict[str, str] = {}
        self._unique_names: list[str] = []

    @torch.no_grad()
    def update(self, model: torch.nn.Module, *, optimizer_step: int) -> None:
        if optimizer_step < self.start_step:
            return
        expected_step = self.start_step if not self.num_updates else self.last_step + 1
        if optimizer_step != expected_step:
            raise ValueError("EMA must receive every optimizer step from start_step onward")
        # keep_vars retains object identity for state keys naming the same parameter.
        state = model.state_dict(keep_vars=True)
        if not self.num_updates:
            first_name: dict[int, str] = {}
            for name, value in state.items():
                owner = first_name.get(id(value))
                if owner is None:
                    owner = name
                    first_name[id(value)] = name
                    self._unique_names.append(name)
                    self._shadow[name] = value.detach().clone()
                else:
                    self._shadow[name] = self._shadow[owner]
                self._owners[name] = owner
        else:
            if state.keys() != self._shadow.keys():
                raise ValueError("model state changed during EMA")
            if len({id(state[name]) for name in self._unique_names}) != len(self._unique_names):
                raise ValueError("model aliases changed during EMA")
            for name, value in state.items():
                if value is not state[self._owners[name]]:
                    raise ValueError("model aliases changed during EMA")
                shadow = self._shadow[name]
                if (value.shape, value.dtype, value.device) != (
                    shadow.shape,
                    shadow.dtype,
                    shadow.device,
                ):
                    raise ValueError(f"model state changed during EMA: {name}")
            floating = []
            for name in self._unique_names:
                if state[name].is_floating_point():
                    floating.append(name)
                else:
                    self._shadow[name].copy_(state[name])
            if floating:
                torch._foreach_lerp_(
                    [self._shadow[name] for name in floating],
                    [state[name] for name in floating],
                    1 - self.decay,
                )
        self.last_step = optimizer_step
        self.num_updates += 1

    def averaged_state_dict(self) -> dict[str, torch.Tensor]:
        if not self.num_updates:
            raise RuntimeError("EMA has not reached its first update")
        return self._shadow

    def metadata(self) -> dict[str, object]:
        return {
            "method": "ema",
            "decay": self.decay,
            "start_step": self.start_step,
            "last_step": self.last_step,
            "num_updates": self.num_updates,
            "evaluation_weights": "model",
            "optimizer_weights": "online_model",
        }
