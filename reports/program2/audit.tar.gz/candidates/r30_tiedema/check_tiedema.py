"""Qualify EMA cost and unchanged online training on an actual L40S."""
import copy, json, statistics, time
from pathlib import Path
import torch,yaml
from nano_protein.model import ESMCConfig, ESMCForMaskedLM, count_parameters, expected_parameter_count
from nano_protein.tokenizer import ProteinTokenizer,mask_tokens
from nano_protein.train import build_optimizer,training_losses
from nano_protein.schedule import warmup_constant_multiplier

torch.set_num_threads(1);torch.set_float32_matmul_precision('high')
assert torch.cuda.get_device_name(0)=='NVIDIA L40S'
root=Path('.dev/program2/candidates/r30_tiedema')
base_config=yaml.safe_load(Path('configs/program2/r29_tied_seed42.yaml').read_text())
new_config=yaml.safe_load(Path('configs/program2/r30_tiedema_seed42.yaml').read_text())
expected=copy.deepcopy(base_config);expected.update(ema_decay=.999)
assert new_config==expected
models=[]
for index in (0,1):
    torch.manual_seed(24)
    models.append(ESMCForMaskedLM(ESMCConfig.esmc_171m(ffn_hidden_dim=1536,tie_word_embeddings=True)).cuda())
assert [count_parameters(m) for m in models]==[142310464,142310464]
assert expected_parameter_count(models[1].config)==142310464
assert all(block.ffn.gate_up.weight.shape==(3072,768) and block.ffn.down.weight.shape==(768,1536) for block in models[1].blocks)
optimizers=[build_optimizer(m,c) for m,c in zip(models,(base_config,new_config),strict=True)]
assert all(len(o.named_optimizers[0][1].param_groups[0]['params'])==96 for o in optimizers)
for step in (1,553,554,555,20000):
    multiplier=warmup_constant_multiplier(optimizer_step=step,warmup_steps=554)
    for opt in optimizers:
        for group in opt.param_groups:group['lr']=base_config['learning_rate']*multiplier*group.get('lr_scale',1.)
    for first,second in zip(optimizers[0].param_groups,optimizers[1].param_groups,strict=True):
        for key in ('lr','weight_decay','lr_scale'):assert first.get(key)==second.get(key)
tokenizer=ProteinTokenizer.esmc()
sequences=[('LAGVESIDPKQNFYMHWCART'*26)[:18+(i*83)%490] for i in range(64)]
tokens,attention=tokenizer.encode_batch(sequences,max_length=512)
tokens,attention=tokens.cuda(),attention.cuda();torch.cuda.manual_seed(24)
corrupted,labels=mask_tokens(tokens,attention,tokenizer)

from nano_protein.weight_average import ExponentialWeightAverage
average=ExponentialWeightAverage(decay=.999,start_step=1)
ema_step=0

def clone_tree(value):
    if torch.is_tensor(value):return value.detach().clone()
    if isinstance(value,dict):return {k:clone_tree(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return type(value)(clone_tree(v) for v in value)
    return copy.deepcopy(value)

def assert_equal(a,b):
    if torch.is_tensor(a):assert torch.equal(a,b)
    elif isinstance(a,dict):
        assert a.keys()==b.keys()
        for k in a:assert_equal(a[k],b[k])
    elif isinstance(a,(list,tuple)):
        assert len(a)==len(b)
        for x,y in zip(a,b,strict=True):assert_equal(x,y)
    else:assert a==b

def step(index):
    global ema_step
    model,opt=models[index],optimizers[index];opt.zero_grad(set_to_none=True)
    with torch.autocast('cuda',dtype=torch.bfloat16):
        output=model(corrupted,attention)
        loss,_,_=training_losses(output['logits'],labels,reduction='sqrt_mask_count')
    loss.backward();norm=torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step()
    if index==1:
        ema_step+=1
        if ema_step<=2:
            snapshot=clone_tree({'model':model.state_dict(),'gradients':[p.grad for p in model.parameters()],'optimizer':opt.state_dict()})
            cpu_rng=torch.get_rng_state().clone();cuda_rng=torch.cuda.get_rng_state().clone()
        average.update(model,optimizer_step=ema_step)
        if ema_step<=2:
            torch.cuda.synchronize()
            assert_equal(snapshot,{'model':model.state_dict(),'gradients':[p.grad for p in model.parameters()],'optimizer':opt.state_dict()})
            assert torch.equal(cpu_rng,torch.get_rng_state()) and torch.equal(cuda_rng,torch.cuda.get_rng_state())
            assert model.embedding.weight is model.head_out.weight
            shadow=average.averaged_state_dict()
            assert shadow['embedding.weight'] is shadow['head_out.weight']
            assert all(v.data_ptr()!=model.state_dict()[k].data_ptr() for k,v in shadow.items())
            del snapshot
            print('Full-size tied EMA direct isolation passed at update',ema_step,flush=True)
    return loss.detach(),norm.detach()

timings={'hidden1536_ms':[],'ema_ms':[]}
for round_index in range(2):
    for index in ([0,1] if round_index==0 else [1,0]):
        for _ in range(3):loss,norm=step(index)
        torch.cuda.synchronize();start=time.perf_counter()
        for _ in range(6):loss,norm=step(index)
        torch.cuda.synchronize()
        timings[('hidden1536_ms','ema_ms')[index]].append((time.perf_counter()-start)*1000/6)
        assert torch.isfinite(loss) and torch.isfinite(norm)
assert all(torch.isfinite(p).all() and p.grad is not None and torch.isfinite(p.grad).all() for p in models[1].parameters())
assert all(block.ffn.gate_up.weight.grad.count_nonzero()>0 and block.ffn.down.weight.grad.count_nonzero()>0 for block in models[1].blocks)
assert average.num_updates==18 and average.last_step==18
assert all(torch.isfinite(v).all() and not v.requires_grad for v in average.averaged_state_dict().values())
assert any(not torch.equal(v,models[1].state_dict()[k]) for k,v in average.averaged_state_dict().items())
shadow_state=average.averaged_state_dict()
assert shadow_state['embedding.weight'] is shadow_state['head_out.weight']
shadow_bytes=sum(v.numel()*v.element_size() for v in {id(v):v for v in shadow_state.values()}.values())
assert shadow_bytes==142310464*4
# Use the averaged full-size weights for the fixed attention-feature check.
models[1].load_state_dict(average.averaged_state_dict())
small_tokens,small_mask=tokenizer.encode_batch(['ACDEFGHIK','LAGVESIDPKQNFYMHWCA'],max_length=24)
with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16):
    features=models[1](small_tokens.cuda(),small_mask.cuda(),output_attentions=True)
assert len(features['attentions'])==24
assert all(x.shape==(2,12,24,24) and torch.isfinite(x).all() for x in features['attentions'])
peak_memory=torch.cuda.max_memory_allocated()/1024**2
del models,optimizers,features,loss,norm
# Compare variable-length packed training and dense math paths on identical weights.
torch.manual_seed(24)
reference=ESMCForMaskedLM(ESMCConfig.tiny(ffn_hidden_dim=192,tie_word_embeddings=True,attention_backend='math')).cuda()
packed=ESMCForMaskedLM(ESMCConfig.tiny(ffn_hidden_dim=192,tie_word_embeddings=True,attention_backend='flash')).cuda()
packed.load_state_dict(reference.state_dict())
import tempfile
from nano_protein.evaluate import load_checkpoint
with tempfile.TemporaryDirectory() as directory:
    checkpoint=Path(directory)/'tiny.pt'
    torch.save({'model_config':reference.config.to_dict(),'model':reference.state_dict()},checkpoint)
    loaded,_=load_checkpoint(checkpoint,torch.device('cpu'))
    assert loaded.config.ffn_hidden_dim==192 and loaded.config.tie_word_embeddings
    assert loaded.embedding.weight is loaded.head_out.weight
    for key,value in loaded.state_dict().items():
        torch.testing.assert_close(value,reference.state_dict()[key].cpu(),rtol=0,atol=0)
    del loaded
tokens,attention=tokenizer.encode_batch(['ACDEFGHIK','LAGVESIDPKQNFYMHWCA'*3,'GGGGG','ACDEFGHIKLMNPQRSTVWY'*4],max_length=64)
tokens,attention=tokens.cuda(),attention.cuda();corrupted,labels=mask_tokens(tokens,attention,tokenizer)
outputs=[]
for model in (reference,packed):
    with torch.autocast('cuda',dtype=torch.bfloat16):
        output=model(corrupted,attention)
        loss,_,_=training_losses(output['logits'],labels,reduction='sqrt_mask_count')
    loss.backward();outputs.append(output['logits'][attention].detach().float())
max_logit_error=(outputs[0]-outputs[1]).abs().max().item();assert max_logit_error<.03,max_logit_error
se=sr=0.
for a,b in zip(reference.parameters(),packed.parameters(),strict=True):
    assert a.grad is not None and b.grad is not None
    se+=(a.grad-b.grad).float().square().sum().item();sr+=a.grad.float().square().sum().item()
relative_gradient_error=(se/sr)**.5;assert relative_gradient_error<.05,relative_gradient_error
a=statistics.median(timings['hidden1536_ms']);b=statistics.median(timings['ema_ms'])
receipt={'status':'passed','gpu':torch.cuda.get_device_name(0),'parameters':142310464,'removed_parameters':0,'ema_decay':.999,
 'candidate':'EMA of post-update weights at decay0.999; no change to online model, optimizer or gradients',
 'initialization_caveat':'All model source, shapes and RNG remain accepted R29; paired campaign trains from scratch and evaluates the predeclared EMA only.',
 'source':'Only training EMA timing/checkpoint selection, the averager/test and paired configs change',
 'all_fullsize_parameters_and_gradients_finite':True,'ffn_pairs_with_nonzero_gradients':24,'muon_matrices':96,
 'fullsize_contact_feature_layout':[24,12],'direct_ema_online_state_isolation_bitwise':True,'trajectory_caveat':'No bitwise independent GPU trajectory claim; R28 EMA-disabled controls also diverged. This run snapshots actual tied online state directly around initialization and lerp.','ema_shadow_bytes':shadow_bytes,'ema_shadow_preserves_input_output_alias':True,'fullsize_initialization_and_lerp_direct_online_state_isolation':True,'ema_shadow_finite_and_nontrainable':True,'dense_vs_packed_max_logit_error':max_logit_error,'dense_vs_packed_relative_gradient_error':relative_gradient_error,
 'timing_samples':timings,'baseline_median_step_ms':a,'candidate_median_step_ms':b,'tokens_per_second_ratio':a/b,
 'timing_protocol':'EMA active from first preflight step (campaign starts554); two alternating rounds, each3 warm+6 measured full forward/backward/clip/Muon+AdamW updates on the same64 synthetic masked sequences <=512; no distributed overhead, actual pair establishes throughput',
 'schedule':'Actual groups agree at steps1,553,554,555,20000; exact554-step warmup then fixed configured peaks',
 'data':'Synthetic protein sequences only; no held-out or training data','peak_memory_mb_two_models':peak_memory}
(root/'MODEL_PREFLIGHT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
