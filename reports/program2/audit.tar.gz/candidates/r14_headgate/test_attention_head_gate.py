"""Check head-gated attention against independent algebra and frozen loading."""

import tempfile
import unittest
from pathlib import Path

import torch
import torch.nn.functional as F

from nano_protein.evaluate import load_checkpoint
from nano_protein.model import (
    ESMCConfig,
    ESMCForMaskedLM,
    count_parameters,
    expected_parameter_count,
)
from nano_protein.train import build_optimizer


class AttentionHeadGateTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1)

    def test_initial_identity_preserves_weights_rng_outputs_and_existing_gradients(self):
        torch.manual_seed(14)
        base = ESMCForMaskedLM(ESMCConfig.tiny(attention_backend="math")).double()
        state = torch.get_rng_state()
        torch.manual_seed(14)
        gated = ESMCForMaskedLM(
            ESMCConfig.tiny(attention_backend="math", attention_head_gating=True)
        ).double()
        self.assertTrue(torch.equal(state, torch.get_rng_state()))
        for name, tensor in base.state_dict().items():
            torch.testing.assert_close(tensor, gated.state_dict()[name], rtol=0, atol=0)
        tokens = torch.tensor([[0, 4, 5, 6, 2], [0, 7, 8, 2, 1]])
        mask = tokens != 1
        a, b = (model(tokens, mask, output_attentions=True) for model in (base, gated))
        torch.testing.assert_close(a["logits"], b["logits"], rtol=0, atol=0)
        for x, y in zip(a["attentions"], b["attentions"], strict=True):
            torch.testing.assert_close(x, y, rtol=0, atol=0)
        a["logits"].square().sum().backward()
        b["logits"].square().sum().backward()
        for name, parameter in base.named_parameters():
            torch.testing.assert_close(
                parameter.grad,
                dict(gated.named_parameters())[name].grad,
                rtol=1e-12,
                atol=1e-12,
            )
        for block in gated.blocks:
            self.assertEqual(block.attention.head_gate.count_nonzero().item(), 0)
            self.assertGreater(block.attention.head_gate.grad.count_nonzero().item(), 0)

    def test_nonzero_head_gates_match_explicit_softmax_and_per_head_projection(self):
        torch.manual_seed(19)
        model = ESMCForMaskedLM(
            ESMCConfig.tiny(attention_backend="math", attention_head_gating=True)
        ).double()
        layer = model.blocks[0].attention
        with torch.no_grad():
            layer.head_gate.normal_(std=0.15)
        hidden = torch.randn(2, 7, 128, dtype=torch.float64, requires_grad=True)
        mask = torch.tensor([[1, 1, 1, 1, 1, 1, 1], [1, 1, 1, 0, 0, 0, 0]], dtype=torch.bool)
        actual, attention = layer(hidden, mask, output_attentions=True)
        x = layer.norm(hidden)
        q, k, v = F.linear(x, layer.qkv.weight).chunk(3, -1)
        q = layer.q_norm(q).reshape(2, 7, 2, 64).transpose(1, 2)
        k = layer.k_norm(k).reshape(2, 7, 2, 64).transpose(1, 2)
        q, k = layer.rotary(q, k)
        probabilities = (
            ((q @ k.transpose(-1, -2)) / 8)
            .masked_fill(~mask[:, None, None, :], torch.finfo(q.dtype).min)
            .float()
            .softmax(-1)
            .double()
        )
        v = v.reshape(2, 7, 2, 64).transpose(1, 2)
        heads = []
        for head in range(2):
            gate = 2 / (1 + torch.exp(-(x * layer.head_gate[head]).sum(-1)))
            heads.append((probabilities[:, head] @ v[:, head]) * gate[..., None])
        expected = F.linear(torch.cat(heads, dim=-1), layer.proj.weight)
        torch.testing.assert_close(actual, expected, rtol=1e-12, atol=1e-12)
        torch.testing.assert_close(attention, probabilities, rtol=0, atol=0)
        grad_actual = torch.autograd.grad(
            actual.square().sum(), (hidden, layer.head_gate), retain_graph=True
        )
        grad_expected = torch.autograd.grad(expected.square().sum(), (hidden, layer.head_gate))
        for a, b in zip(grad_actual, grad_expected, strict=True):
            torch.testing.assert_close(a, b, rtol=1e-11, atol=1e-11)
        sdpa, weights = layer(hidden, mask)
        self.assertIsNone(weights)
        torch.testing.assert_close(sdpa, actual, rtol=1e-6, atol=1e-8)

    def test_budget_and_optimizer_assign_new_matrices_once(self):
        config = ESMCConfig.esmc_171m(attention_head_gating=True)
        self.assertEqual(expected_parameter_count(config), 170_892_352)
        self.assertLessEqual(expected_parameter_count(config), 171_000_000)
        small = ESMCConfig.tiny(attention_head_gating=True)
        model = ESMCForMaskedLM(small)
        self.assertEqual(count_parameters(model), expected_parameter_count(small))
        optimizer = build_optimizer(
            model,
            {"optimizer": "muon", "learning_rate": 0.000326599, "weight_decay": 0.0183712},
        )
        state = optimizer.state_dict()["optimizers"]
        self.assertEqual([s["name"] for s in state], ["muon", "adamw"])
        muon, adamw = optimizer.named_optimizers
        self.assertIs(type(muon[1]), torch.optim.Muon)
        muon_parameters = [p for group in muon[1].param_groups for p in group["params"]]
        self.assertEqual(len(muon_parameters), 5 * small.n_layers)
        all_parameters = muon_parameters + [
            p for group in adamw[1].param_groups for p in group["params"]
        ]
        self.assertEqual(len(set(map(id, all_parameters))), len(list(model.parameters())))
        for block in model.blocks:
            self.assertIn(id(block.attention.head_gate), set(map(id, muon_parameters)))

    def test_frozen_checkpoint_loader_restores_gate_flag_and_trained_weights(self):
        config = ESMCConfig.tiny(attention_backend="math", attention_head_gating=True)
        model = ESMCForMaskedLM(config)
        with torch.no_grad():
            for block in model.blocks:
                block.attention.head_gate.normal_(std=0.1)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "checkpoint.pt"
            torch.save({"model_config": config.to_dict(), "model": model.state_dict()}, path)
            loaded, packet = load_checkpoint(path, torch.device("cpu"))
        self.assertTrue(loaded.config.attention_head_gating)
        for name, tensor in model.state_dict().items():
            torch.testing.assert_close(tensor, loaded.state_dict()[name], rtol=0, atol=0)
        self.assertEqual(packet["model_config"], config.to_dict())


if __name__ == "__main__":
    unittest.main()
