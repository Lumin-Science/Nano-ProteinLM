"""Check layerwise FFN construction, legacy equivalence and frozen evaluation loading."""

import tempfile
import unittest
from pathlib import Path

import torch

from nano_protein.evaluate import load_checkpoint
from nano_protein.model import (
    ESMCConfig,
    ESMCForMaskedLM,
    count_parameters,
    expected_parameter_count,
)


class FFNProfileTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1)
        torch.manual_seed(25)

    def test_uniform_profile_preserves_scalar_weights_rng_and_outputs(self):
        scalar = ESMCForMaskedLM(ESMCConfig.tiny(ffn_hidden_dim=192, attention_backend="math"))
        rng = torch.get_rng_state()
        torch.manual_seed(25)
        profile = ESMCForMaskedLM(
            ESMCConfig.tiny(ffn_hidden_dims=[192, 192], attention_backend="math")
        )
        self.assertTrue(torch.equal(rng, torch.get_rng_state()))
        for name, value in scalar.state_dict().items():
            torch.testing.assert_close(value, profile.state_dict()[name], rtol=0, atol=0)
        tokens = torch.tensor([[0, 4, 5, 2], [0, 7, 2, 1]])
        a, b = scalar(tokens, tokens != 1), profile(tokens, tokens != 1)
        torch.testing.assert_close(a["logits"], b["logits"], rtol=0, atol=0)
        legacy = scalar.config.to_dict()
        del legacy["ffn_hidden_dims"]
        self.assertEqual(ESMCConfig(**legacy), scalar.config)

    def test_profile_budget_shapes_frozen_loader_and_attention_features(self):
        widths = [3072] + [1280] * 6 + [1536] * 17
        config = ESMCConfig.esmc_171m(ffn_hidden_dims=widths)
        self.assertEqual(config.ffn_hidden_dims, tuple(widths))
        with torch.device("meta"):
            model = ESMCForMaskedLM(config)
        self.assertEqual(count_parameters(model), 142_359_616)
        self.assertEqual(expected_parameter_count(config), count_parameters(model))
        for block, width in zip(model.blocks, widths, strict=True):
            self.assertEqual(block.ffn.gate_up.weight.shape, (2 * width, 768))
            self.assertEqual(block.ffn.down.weight.shape, (768, width))
        tiny = ESMCForMaskedLM(
            ESMCConfig.tiny(ffn_hidden_dims=[256, 128], attention_backend="math")
        )
        self.assertEqual(count_parameters(tiny), expected_parameter_count(tiny.config))
        tokens = torch.tensor([[0, 4, 5, 6, 2], [0, 7, 8, 2, 1]])
        expected = tiny(tokens, tokens != 1, output_attentions=True)
        expected["logits"].square().mean().backward()
        for block in tiny.blocks:
            for weight in (block.ffn.gate_up.weight, block.ffn.down.weight):
                self.assertIsNotNone(weight.grad)
                self.assertTrue(torch.isfinite(weight.grad).all())
                self.assertGreater(weight.grad.count_nonzero().item(), 0)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "checkpoint.pt"
            torch.save(
                {"model_config": tiny.config.to_dict(), "model": tiny.state_dict()}, path
            )
            loaded, _ = load_checkpoint(path, torch.device("cpu"))
        actual = loaded(tokens, tokens != 1, output_attentions=True)
        self.assertEqual(loaded.config.ffn_hidden_dims, (256, 128))
        torch.testing.assert_close(actual["logits"], expected["logits"], rtol=0, atol=0)
        self.assertEqual(len(actual["attentions"]), 2)
        for a, b in zip(actual["attentions"], expected["attentions"], strict=True):
            self.assertEqual(a.shape, (2, 2, 5, 5))
            torch.testing.assert_close(a, b, rtol=0, atol=0)

    def test_rejects_ambiguous_or_malformed_layer_widths(self):
        for widths in (
            192,
            "192,192",
            [],
            [192],
            [192] * 3,
            [0, 192],
            [192, -1],
            [True, 192],
            [192, 1.5],
            [192, None],
        ):
            with self.subTest(widths=widths), self.assertRaises(ValueError):
                ESMCConfig.tiny(ffn_hidden_dims=widths)
        with self.assertRaises(ValueError):
            ESMCConfig.tiny(ffn_hidden_dim=192, ffn_hidden_dims=[192, 192])
        widths = [256, 128]
        config = ESMCConfig.tiny(ffn_hidden_dims=widths)
        widths[0] = 1
        self.assertEqual(config.ffn_hidden_dims, (256, 128))


if __name__ == "__main__":
    unittest.main()
