"""Training-only FFN angular-shift diagnostic on both accepted R22 seeds."""
import hashlib,json
from pathlib import Path
import torch
import torch.nn.functional as F
from nano_protein.data import MixtureBatcher
from nano_protein.evaluate import load_checkpoint
from nano_protein.tokenizer import ProteinTokenizer,mask_tokens

torch.set_num_threads(1);torch.set_float32_matmul_precision('high')
assert torch.cuda.get_device_name(0)=='NVIDIA L40S'
notes=Path('.dev/program2')
launches=[r.split('\t') for r in (notes/'launches.tsv').read_text().splitlines()]
runs=[row for row in launches if row[0]=='r22_ffn1536'];assert len(runs)==2
contract=json.loads((Path('outputs/program2')/runs[0][1]/'run_contract.json').read_text())
tokenizer=ProteinTokenizer.esmc()
batcher=MixtureBatcher(Path(contract['data_manifest']).parent,'train',{'uniref90':.36,'mgnify':.11,'omg_img':.54},seed=20260906,rank=0,world_size=1)
batches=[];digests=[]
for index in range(4):
    ids,attention=batcher.batch(16,context_length=512,tokenizer=tokenizer)
    ids,attention=ids.cuda(),attention.cuda()
    corrupted,labels=mask_tokens(ids,attention,tokenizer,generator=torch.Generator(device='cuda').manual_seed(250000+index))
    eligible=torch.isin(ids[attention],torch.tensor(tokenizer.canonical_ids,device='cuda'))
    batches.append((corrupted,attention,eligible))
    digests.append(hashlib.sha256(ids.cpu().numpy().tobytes()+attention.cpu().numpy().tobytes()+labels.cpu().numpy().tobytes()).hexdigest())
checks=[]
for _,run_id,seed,node in runs:
    run=Path('outputs/program2')/run_id
    model,packet=load_checkpoint(run/'checkpoint-final.pt',torch.device('cuda'))
    assert model.config.n_layers==24 and model.config.ffn_hidden_dim==1536
    sums=torch.zeros((24,3),device='cuda',dtype=torch.float64);counts=0;active=None
    handles=[]
    for index,block in enumerate(model.blocks):
        def capture(module,inputs,output,index=index,scale=block.residual_scale):
            z=inputs[0].float()[active];delta=output.float()[active]/scale;h=z+delta
            cosine=(F.normalize(z,dim=-1)*F.normalize(h,dim=-1)).sum(-1).clamp(-1,1)
            sums[index,0]+=cosine.acos().double().sum()
            sums[index,1]+=delta.norm(dim=-1).double().sum()
            sums[index,2]+=z.norm(dim=-1).double().sum()
        handles.append(block.ffn.register_forward_hook(capture))
    for corrupted,attention,eligible in batches:
        active=eligible;counts+=int(eligible.sum())
        with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):model(corrupted,attention)
    for handle in handles:handle.remove()
    values=(sums/counts).cpu().tolist();angles=[row[0] for row in values]
    check={'seed':int(seed),'run_id':run_id,'checkpoint_sha256':json.loads((run/'ROUND_SUMMARY.json').read_text())['checkpoint']['sha256'],
           'canonical_tokens':counts,'angular_shift_radians':angles,'raw_update_norm':[v[1] for v in values],'input_residual_norm':[v[2] for v in values],
           'first_half_mean_angular_shift':sum(angles[:12])/12,'last_half_mean_angular_shift':sum(angles[12:])/12}
    checks.append(check);print(json.dumps(check),flush=True)
    del model,packet
    torch.cuda.empty_cache()
receipt={'status':'measured','candidate_hypothesis_predeclared':'First12 FFNs2048,last12 FFNs1024 preserves total width24*1536; check whether normalized motion is front-loaded before launch.',
 'data':'Exactly4 batches x16 sequences from train split only, context512, diagnostic sampling seed20260906 and mask seeds250000..250003; identical inputs for both accepted checkpoints. No held-out data.',
 'batch_sha256':digests,'source_counts':dict(batcher.source_counts),'checks':checks,
 'metric':'Mean per-canonical-token spherical angle between post-attention residual z and z+FFN(z)/sqrt(24/36); excludes BOS/EOS/padding/noncanonical positions. This is a forward geometry proxy, not causal layer sensitivity or the full GW/topological method.'}
(notes/'FFN_DEPTH_PROFILE_20260906.json').write_text(json.dumps(receipt,indent=2)+'\n')
