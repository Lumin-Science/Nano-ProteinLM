"""Construct independent or continuous training streams for context stages."""

from pathlib import Path

from .data import MixtureBatcher
from .schedule import Stage


def build_stage_batchers(
    data_root: Path,
    stages: tuple[Stage, ...],
    *,
    seed: int,
    rank: int,
    world_size: int,
    share_stream: bool = False,
) -> dict[str, MixtureBatcher]:
    if not stages or len({stage.name for stage in stages}) != len(stages):
        raise ValueError("training stages must be nonempty and have distinct names")
    if share_stream and any(stage.mixture != stages[0].mixture for stage in stages):
        raise ValueError("a continuous stage stream requires identical source mixtures")
    batchers = {}
    shared = None
    for stage in stages:
        if not share_stream or shared is None:
            current = MixtureBatcher(
                data_root, "train", stage.mixture, seed=seed, rank=rank, world_size=world_size
            )
            if share_stream:
                shared = current
        else:
            current = shared
        batchers[stage.name] = current
    return batchers
