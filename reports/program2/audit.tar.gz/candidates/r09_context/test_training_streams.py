import unittest
from pathlib import Path
from unittest.mock import patch

from nano_protein.schedule import Stage, stage_for_time, warmup_constant_multiplier
from nano_protein.training_streams import build_stage_batchers


class CounterBatcher:
    def __init__(self, root, split, mixture, *, seed, rank, world_size):
        self.cursor = 0
        self.arguments = (root, split, mixture, seed, rank, world_size)

    def batch(self, batch_size):
        rows = list(range(self.cursor, self.cursor + batch_size))
        self.cursor += batch_size
        return rows


class TrainingStreamTests(unittest.TestCase):
    def setUp(self):
        mixture = {"uniref90": 0.36, "mgnify": 0.11, "omg_img": 0.54}
        self.stages = (
            Stage("stage1", 128, 64, 1, mixture),
            Stage("stage2", 512, 64, 1, dict(mixture)),
        )

    def build(self, stages=None, share_stream=False):
        return build_stage_batchers(
            Path("unused"),
            self.stages if stages is None else stages,
            seed=42,
            rank=2,
            world_size=4,
            share_stream=share_stream,
        )

    @patch("nano_protein.training_streams.MixtureBatcher", CounterBatcher)
    def test_shared_stage_transition_does_not_replay_data(self):
        streams = self.build(share_stream=True)
        self.assertEqual(streams["stage1"].batch(2), [0, 1])
        self.assertEqual(streams["stage1"].batch(2), [2, 3])
        self.assertEqual(streams["stage2"].batch(2), [4, 5])
        self.assertEqual(
            streams["stage2"].arguments[1:], ("train", self.stages[0].mixture, 42, 2, 4)
        )

    @patch("nano_protein.training_streams.MixtureBatcher", CounterBatcher)
    def test_default_independent_stage_behavior_is_retained(self):
        streams = self.build()
        self.assertEqual(streams["stage1"].batch(2), [0, 1])
        self.assertEqual(streams["stage1"].batch(2), [2, 3])
        self.assertEqual(streams["stage2"].batch(2), [0, 1])
        self.assertEqual(streams["stage1"].batch(2), [4, 5])

    def test_rejects_ambiguous_names_and_changed_shared_mixture(self):
        with self.assertRaises(ValueError):
            self.build(stages=())
        with self.assertRaises(ValueError):
            self.build(stages=(self.stages[0], self.stages[0]))
        changed = Stage("stage2", 512, 64, 1, {"uniref90": 1.0})
        with self.assertRaises(ValueError):
            self.build(stages=(self.stages[0], changed), share_stream=True)

    def test_context_transition_uses_wall_time_and_does_not_reset_lr_warmup(self):
        for seconds, expected_name in [
            (0, "stage1"),
            (899.9, "stage1"),
            (900, "stage2"),
            (3599, "stage2"),
        ]:
            selected, _ = stage_for_time(
                seconds, walltime_seconds=3600, stage1_fraction=0.25, stages=self.stages
            )
            self.assertEqual(selected.name, expected_name)
        self.assertEqual(warmup_constant_multiplier(optimizer_step=554, warmup_steps=554), 1.0)
        self.assertEqual(warmup_constant_multiplier(optimizer_step=3000, warmup_steps=554), 1.0)


if __name__ == "__main__":
    unittest.main()
