"""Check AdaMuon algebra, native momentum, state resume and optimizer partition."""

import copy
import unittest
from unittest.mock import patch

import torch
from torch.optim._muon import _zeropower_via_newtonschulz

from nano_protein.adaptive_muon import AdaMuon
from nano_protein.model import ESMCConfig, ESMCForMaskedLM
from nano_protein.train import build_optimizer


class AdaMuonTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1)
        torch.manual_seed(15)

    def test_explicit_post_orthogonal_variance_and_rms_reference(self):
        for shape in ((8, 8), (12, 4), (4, 12)):
            for nesterov in (False, True):
                p = torch.nn.Parameter(torch.randn(shape))
                expected = p.detach().clone()
                optimizer = AdaMuon(
                    [p],
                    lr=0.001,
                    weight_decay=0.02,
                    momentum=0.95,
                    nesterov=nesterov,
                    adjust_lr_fn="match_rms_adamw",
                )
                momentum = torch.zeros_like(p)
                variance = torch.zeros_like(p)
                for step in range(1, 5):
                    grad = torch.randn_like(p) * (10**-step)
                    p.grad = grad.clone()
                    lr = 0.001 * step / 4
                    optimizer.param_groups[0]["lr"] = lr
                    momentum = 0.95 * momentum + 0.05 * grad
                    direction = 0.05 * grad + 0.95 * momentum if nesterov else momentum
                    orthogonal = _zeropower_via_newtonschulz(
                        direction.sign(), (3.4445, -4.775, 2.0315), 5, 1e-7
                    ).float()
                    variance = 0.95 * variance + 0.05 * orthogonal.square()
                    preconditioned = orthogonal / (variance.sqrt() + 1e-8)
                    update = preconditioned * (
                        0.2 * p.numel() ** 0.5 / (preconditioned.norm() + 1e-8)
                    )
                    expected = expected * (1 - lr * 0.02) - lr * update
                    optimizer.step()
                    torch.testing.assert_close(p, expected, rtol=1e-6, atol=1e-7)
                    state = optimizer.state[p]
                    torch.testing.assert_close(
                        state["second_moment"], variance, rtol=1e-6, atol=1e-8
                    )
                    self.assertEqual(state["adaptive_step"], step)
                    self.assertAlmostEqual(update.square().mean().sqrt().item(), 0.2, places=6)
                    torch.testing.assert_close(p.grad, grad, rtol=0, atol=0)

    def test_native_momentum_missing_gradients_and_zero_updates(self):
        for nesterov in (False, True):
            p = torch.nn.Parameter(torch.randn(8, 4))
            q = torch.nn.Parameter(p.detach().clone())
            native = torch.optim.Muon(
                [q], lr=0.001, nesterov=nesterov, adjust_lr_fn="match_rms_adamw"
            )
            adaptive = AdaMuon([p], lr=0.001, nesterov=nesterov, adjust_lr_fn="match_rms_adamw")
            for _ in range(4):
                p.grad = torch.randn_like(p)
                q.grad = p.grad.clone()
                adaptive.step()
                native.step()
                torch.testing.assert_close(
                    adaptive.state[p]["momentum_buffer"],
                    native.state[q]["momentum_buffer"],
                    rtol=0,
                    atol=0,
                )
            before = p.detach().clone()
            old_step = adaptive.state[p]["adaptive_step"]
            p.grad = None
            adaptive.step()
            torch.testing.assert_close(p, before, rtol=0, atol=0)
            self.assertEqual(adaptive.state[p]["adaptive_step"], old_step)
        p = torch.nn.Parameter(torch.ones(8, 4))
        optimizer = AdaMuon([p], lr=0.01, weight_decay=0.1, adjust_lr_fn="match_rms_adamw")
        p.grad = torch.zeros_like(p)
        optimizer.step()
        torch.testing.assert_close(p, torch.full_like(p, 0.999), rtol=0, atol=0)
        self.assertEqual(optimizer.state[p]["second_moment"].count_nonzero().item(), 0)

    def test_checkpoint_resume_exact_and_signed_native_ns_input(self):
        p = torch.nn.Parameter(torch.randn(6, 4))
        optimizer = AdaMuon([p], lr=0.001, adjust_lr_fn="match_rms_adamw")
        p.grad = torch.randn_like(p)
        with patch(
            "nano_protein.adaptive_muon._zeropower_via_newtonschulz",
            wraps=_zeropower_via_newtonschulz,
        ) as ortho:
            optimizer.step()
            supplied = ortho.call_args.args[0]
            self.assertTrue(torch.all((supplied == -1) | (supplied == 0) | (supplied == 1)))
        q = torch.nn.Parameter(p.detach().clone())
        restored = AdaMuon([q], lr=0.1, adjust_lr_fn="match_rms_adamw")
        restored.load_state_dict(copy.deepcopy(optimizer.state_dict()))
        for _ in range(3):
            p.grad = torch.randn_like(p)
            q.grad = p.grad.clone()
            optimizer.step()
            restored.step()
            torch.testing.assert_close(p, q, rtol=0, atol=0)
            for key in ("momentum_buffer", "second_moment"):
                torch.testing.assert_close(
                    optimizer.state[p][key], restored.state[q][key], rtol=0, atol=0
                )
            self.assertEqual(
                optimizer.state[p]["adaptive_step"], restored.state[q]["adaptive_step"]
            )

    def test_selection_and_unchanged_parameter_groups(self):
        model = ESMCForMaskedLM(ESMCConfig.tiny())
        config = {"optimizer": "muon", "learning_rate": 0.000326599, "weight_decay": 0.0183712}
        base = build_optimizer(model, config)
        candidate = build_optimizer(model, dict(config, muon_adaptive=True))
        self.assertIs(type(base.named_optimizers[0][1]), torch.optim.Muon)
        self.assertIs(type(candidate.named_optimizers[0][1]), AdaMuon)
        self.assertIs(type(candidate.named_optimizers[1][1]), torch.optim.AdamW)
        for a, b in zip(base.param_groups, candidate.param_groups, strict=True):
            self.assertEqual(list(map(id, a["params"])), list(map(id, b["params"])))
            for key, value in a.items():
                if key != "params":
                    self.assertEqual(value, b[key])
        with self.assertRaises(ValueError):
            AdaMuon([torch.nn.Parameter(torch.zeros(3, 4))], adjust_lr_fn="original")


if __name__ == "__main__":
    unittest.main()
