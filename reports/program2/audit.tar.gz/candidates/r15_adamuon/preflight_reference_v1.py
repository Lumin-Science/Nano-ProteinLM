"""L40S qualification against authors' code and actual optimizer matrix shapes."""
import hashlib
import importlib.util
import json
import statistics
import time
from pathlib import Path
from unittest.mock import patch
import torch
from nano_protein.adaptive_muon import AdaMuon
from nano_protein.model import ESMCConfig,ESMCForMaskedLM,count_parameters
from nano_protein.train import muon_adamw_parameter_groups

torch.set_num_threads(1)
torch.manual_seed(20260906)
assert torch.cuda.get_device_name(0)=='NVIDIA L40S'
p=Path('.dev/program2/candidates/r15_adamuon')
metadata=json.loads((p/'REFERENCE.json').read_text())
assert hashlib.sha256((p/'reference_adamuon.py').read_bytes()).hexdigest()==metadata['reference_sha256']
spec=importlib.util.spec_from_file_location('authors_adamuon',p/'reference_adamuon.py')
reference=importlib.util.module_from_spec(spec);spec.loader.exec_module(reference)
class Handle:
    def wait(self):
        pass
def gather(output,update,async_op=True):
    output[0].copy_(update)
    return Handle()
comparisons=[]
for shape in ((2304,768),(768,768),(4096,768),(768,2048)):
    parameter=torch.nn.Parameter(torch.zeros(shape,device='cuda'))
    other=torch.nn.Parameter(parameter.detach().clone())
    actual=AdaMuon([parameter],lr=.000326599,weight_decay=.0183712,adjust_lr_fn='match_rms_adamw')
    authors=reference.AdaMuon([other],lr=.000326599,weight_decay=.0183712,rank=0,world_size=1)
    errors=[]
    for _ in range(3):
        parameter.grad=torch.randn_like(parameter)*.001
        other.grad=parameter.grad.clone()
        actual.step()
        with patch.object(reference.dist,'all_gather_into_tensor',side_effect=gather):
            authors.step()
        error=((parameter-other).norm()/other.norm()).item()
        assert error<.08,(shape,error)
        assert torch.isfinite(parameter).all()
        errors.append(error)
    comparisons.append({'shape':shape,'relative_parameter_update_differences':errors})
    del actual,authors,parameter,other
model=ESMCForMaskedLM(ESMCConfig.esmc_171m()).cuda()
assert count_parameters(model)==170671168
groups,_=muon_adamw_parameter_groups(model,weight_decay=.0183712)
parameters=groups[0]['params']
assert len(parameters)==96
copies=[torch.nn.Parameter(x.detach().clone()) for x in parameters]
for a,b in zip(parameters,copies,strict=True):
    a.grad=torch.randn_like(a)*.001;b.grad=a.grad.clone()
adaptive=AdaMuon(parameters,lr=.000326599,weight_decay=.0183712,adjust_lr_fn='match_rms_adamw')
native=torch.optim.Muon(copies,lr=.000326599,weight_decay=.0183712,adjust_lr_fn='match_rms_adamw')
adaptive.step();native.step()
for a,b in zip(parameters,copies,strict=True):
    torch.testing.assert_close(adaptive.state[a]['momentum_buffer'],native.state[b]['momentum_buffer'],rtol=0,atol=0)
    v=adaptive.state[a]['second_moment'];assert v.dtype==torch.float32 and v.shape==a.shape and torch.isfinite(v).all() and (v>=0).all()
timings={'native_ms':[],'adamuon_ms':[]}
for r in range(3):
    for name,optimizer in ([('native_ms',native),('adamuon_ms',adaptive)] if r%2==0 else [('adamuon_ms',adaptive),('native_ms',native)]):
        for _ in range(5):
            optimizer.step()
        torch.cuda.synchronize();start=time.perf_counter()
        for _ in range(10):
            optimizer.step()
        torch.cuda.synchronize();timings[name].append((time.perf_counter()-start)*1000/10)
assert all(torch.isfinite(x).all() for x in parameters)
second_moment_bytes=sum(adaptive.state[x]['second_moment'].numel()*4 for x in parameters)
receipt={'status':'passed','gpu':torch.cuda.get_device_name(0),'torch':torch.__version__,'parameters':170671168,'matrix_count':96,
         'reference_comparisons':comparisons,'comparison':'Authors v3 unmodified single-rank algorithm, local gather stub; reference bf16 NS/variance/final update versus candidate native fused NS and fp32 variance/final update.',
         'momentum_buffers':'bitwise identical to native for equal supplied gradients','second_moment_dtype':'float32','second_moment_bytes':second_moment_bytes,
         'timing_samples':timings,'native_median_ms':statistics.median(timings['native_ms']),'adamuon_median_ms':statistics.median(timings['adamuon_ms']),
         'data':'synthetic gradients only; no training or held-out inputs'}
(p/'OPTIMIZER_PREFLIGHT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
