"""AdaMuon v3's sign/variance/RMS update with the pinned native Muon framework.

Algorithm: https://arxiv.org/abs/2507.11005v3
Retain native NS5 and momentum, and accumulate second moments in fp32.
"""

import math

import torch
from torch.optim._muon import _zeropower_via_newtonschulz


class AdaMuon(torch.optim.Muon):
    """Sign-stabilized orthogonal updates with elementwise second moments."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for group in self.param_groups:
            if group["adjust_lr_fn"] != "match_rms_adamw":
                raise ValueError("AdaMuon requires match_rms_adamw learning-rate convention")
            group["adaptive_variant"] = "adamuon_v3_sign"
            group["adaptive_eps"] = 1e-8
            group["adaptive_rms"] = 0.2

    @torch.no_grad()
    def step(self, closure=None):
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()
        for group in self.param_groups:
            parameters, gradients, buffers = [], [], []
            self._init_group(group, parameters, gradients, buffers)
            for parameter, gradient, buffer in zip(parameters, gradients, buffers, strict=True):
                momentum = group["momentum"]
                buffer.lerp_(gradient, 1 - momentum)
                update = gradient.lerp(buffer, momentum) if group["nesterov"] else buffer
                update = _zeropower_via_newtonschulz(
                    update.sign(), group["ns_coefficients"], group["ns_steps"], group["eps"]
                ).float()
                state = self.state[parameter]
                if "second_moment" not in state:
                    state["second_moment"] = torch.zeros_like(parameter, dtype=torch.float32)
                    state["adaptive_step"] = 0
                state["adaptive_step"] += 1
                variance = state["second_moment"]
                variance.mul_(momentum).addcmul_(update, update, value=1 - momentum)
                update = update / (variance.sqrt() + group["adaptive_eps"])
                # RMS alignment absorbs EMA bias correction, as in AdaMuon v3.
                scale = group["adaptive_rms"] * math.sqrt(parameter.numel())
                update.mul_(scale / (update.norm() + group["adaptive_eps"]))
                parameter.mul_(1 - group["lr"] * group["weight_decay"])
                parameter.add_(update, alpha=-group["lr"])
        return loss
