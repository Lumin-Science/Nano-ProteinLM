"""Test spectral semantics, unchanged native optimizer mechanics, and restartability."""

import copy
import unittest
from unittest.mock import patch

import torch
from torch.optim._muon import _zeropower_via_newtonschulz

from nano_protein.model import build_model
from nano_protein.polar_muon import POLAR_EXPRESS_COEFFICIENTS, PolarExpressMuon, polar_express
from nano_protein.train import build_optimizer


class PolarMuonTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1)
        torch.manual_seed(104)

    def test_matrix_polynomial_matches_independent_singular_value_reference(self):
        for shape in ((16, 16), (48, 16), (16, 48)):
            with self.subTest(shape=shape):
                matrix = torch.randn(*shape)
                original = matrix.clone()
                quantized = matrix.bfloat16()
                quantized = quantized / (quantized.norm() * 1.01 + 1e-7)
                u, singular, vh = torch.linalg.svd(quantized.double(), full_matrices=False)
                for a, b, c in POLAR_EXPRESS_COEFFICIENTS:
                    singular = a * singular + b * singular**3 + c * singular**5
                expected = (u * singular) @ vh
                actual = polar_express(matrix).double()
                relative_error = (actual - expected).norm() / expected.norm()
                self.assertLess(relative_error.item(), 0.06)
                torch.testing.assert_close(matrix, original, rtol=0, atol=0)
                self.assertEqual(actual.shape, matrix.shape)
        self.assertEqual(polar_express(torch.zeros(16, 8)).count_nonzero(), 0)

    def test_all_nonorthogonalization_mechanics_match_native_exactly(self):
        # Substitute native orthogonalization to isolate momentum, Nesterov,
        # parameter grouping, skipped gradients, LR scaling and weight decay.
        def native_orthogonalize(update, _coefficients, eps):
            return _zeropower_via_newtonschulz(update, (3.4445, -4.7750, 2.0315), 5, eps)

        for nesterov in (False, True):
            with self.subTest(nesterov=nesterov):
                ps = [torch.nn.Parameter(torch.randn(*s)) for s in ((8, 8), (24, 8), (8, 16))]
                qs = [torch.nn.Parameter(p.detach().clone()) for p in ps]
                options = dict(
                    lr=0.001,
                    weight_decay=0.02,
                    momentum=0.95,
                    nesterov=nesterov,
                    adjust_lr_fn="match_rms_adamw",
                )
                candidate = PolarExpressMuon(ps, **options)
                native = torch.optim.Muon(qs, **options)
                for step in range(3):
                    candidate.param_groups[0]["lr"] = native.param_groups[0]["lr"] = 0.001 * (
                        step + 1
                    )
                    for i, (p, q) in enumerate(zip(ps, qs, strict=True)):
                        p.grad = None if i == 1 and step == 1 else torch.randn_like(p)
                        q.grad = None if p.grad is None else p.grad.clone()
                    with patch("nano_protein.polar_muon.polar_express", native_orthogonalize):
                        candidate.step()
                    native.step()
                    for p, q in zip(ps, qs, strict=True):
                        torch.testing.assert_close(p, q, rtol=0, atol=0)
                        torch.testing.assert_close(
                            candidate.state[p]["momentum_buffer"],
                            native.state[q]["momentum_buffer"],
                            rtol=0,
                            atol=0,
                        )

    def test_checkpoint_roundtrip_preserves_real_polar_updates(self):
        p = torch.nn.Parameter(torch.randn(24, 8))
        optimizer = PolarExpressMuon([p], lr=0.001, adjust_lr_fn="match_rms_adamw")
        p.grad = torch.randn_like(p)
        optimizer.step()
        q = torch.nn.Parameter(p.detach().clone())
        resumed = PolarExpressMuon([q], lr=0.001, adjust_lr_fn="match_rms_adamw")
        resumed.load_state_dict(copy.deepcopy(optimizer.state_dict()))
        p.grad = torch.randn_like(p)
        q.grad = p.grad.clone()
        optimizer.step()
        resumed.step()
        torch.testing.assert_close(p, q, rtol=0, atol=0)
        self.assertEqual(resumed.param_groups[0]["orthogonalization"], "polar_express5")
        self.assertEqual(
            tuple(resumed.param_groups[0]["polar_express_coefficients"]),
            POLAR_EXPRESS_COEFFICIENTS,
        )
        resumed.zero_grad(set_to_none=True)
        previous = q.detach().clone()
        resumed.step()
        torch.testing.assert_close(q, previous, rtol=0, atol=0)

    def test_optimizer_selection_and_fallback_partition_are_preserved(self):
        model = build_model("tiny", attention_backend="math")
        config = dict(optimizer="muon", learning_rate=0.001, weight_decay=0.02)
        baseline = build_optimizer(model, config)
        candidate = build_optimizer(model, dict(config, muon_polar_express=True))
        self.assertIs(type(baseline.named_optimizers[0][1]), torch.optim.Muon)
        self.assertIsInstance(candidate.named_optimizers[0][1], PolarExpressMuon)
        self.assertIs(type(candidate.named_optimizers[1][1]), torch.optim.AdamW)
        for a, b in zip(baseline.param_groups, candidate.param_groups, strict=True):
            self.assertEqual([id(p) for p in a["params"]], [id(p) for p in b["params"]])
            self.assertEqual(a["lr"], b["lr"])
            self.assertEqual(a["weight_decay"], b["weight_decay"])
        with self.assertRaises(ValueError):
            PolarExpressMuon([torch.nn.Parameter(torch.randn(8, 8))], ns_steps=3)
