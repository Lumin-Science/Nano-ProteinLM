"""Check training replacement corruption without changing MLM targets or RNG."""

import unittest

import torch

from nano_protein.tokenizer import ProteinTokenizer, mask_tokens
from nano_protein.train import bert_corrupt_selected


class BertCorruptionTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1)
        self.tokenizer = ProteinTokenizer.esmc()

    def test_protected_tokens_target_identity_and_independent_replacement_reference(self):
        tokens, attention = self.tokenizer.encode_batch(
            ["ACDEFGHIKLMNPQRSTVWYXBZOU.-" * 3, "A", "X", ""], max_length=100
        )
        selected_rng = torch.Generator().manual_seed(19)
        masked, labels = mask_tokens(tokens, attention, self.tokenizer, generator=selected_rng)
        saved_labels = labels.clone()
        saved_masked = masked.clone()
        rng = torch.Generator().manual_seed(42)
        output, actions = bert_corrupt_selected(
            tokens, masked, labels, self.tokenizer, generator=rng
        )
        reference_rng = torch.Generator().manual_seed(42)
        choices = torch.randint(10, tokens.shape, generator=reference_rng)
        indices = torch.randint(20, tokens.shape, generator=reference_rng)
        expected = masked.clone()
        for row, col in labels.ne(-100).nonzero().tolist():
            choice = int(choices[row, col])
            if choice == 8:
                expected[row, col] = self.tokenizer.canonical_ids[int(indices[row, col])]
            elif choice == 9:
                expected[row, col] = tokens[row, col]
        torch.testing.assert_close(output, expected, rtol=0, atol=0)
        torch.testing.assert_close(labels, saved_labels, rtol=0, atol=0)
        torch.testing.assert_close(masked, saved_masked, rtol=0, atol=0)
        torch.testing.assert_close(actions.ne(0), labels.ne(-100), rtol=0, atol=0)
        torch.testing.assert_close(output[actions.eq(0)], tokens[actions.eq(0)], rtol=0, atol=0)
        self.assertTrue(torch.equal(rng.get_state(), reference_rng.get_state()))
        self.assertEqual(int(actions[1].ne(0).sum()), 1)
        self.assertEqual(int(actions[2:].count_nonzero()), 0)

    def test_original_target_rng_stream_unchanged_across_batches(self):
        tokens, attention = self.tokenizer.encode_batch(["ACDEFGHIK" * 3] * 8, max_length=40)
        torch.manual_seed(43)
        baseline = [mask_tokens(tokens, attention, self.tokenizer) for _ in range(5)]
        end = torch.get_rng_state()
        torch.manual_seed(43)
        replacements = torch.Generator().manual_seed(1_900_046)
        for expected_tokens, expected_labels in baseline:
            masked, labels = mask_tokens(tokens, attention, self.tokenizer)
            bert_corrupt_selected(
                tokens, masked, labels, self.tokenizer, generator=replacements
            )
            torch.testing.assert_close(masked, expected_tokens, rtol=0, atol=0)
            torch.testing.assert_close(labels, expected_labels, rtol=0, atol=0)
        self.assertTrue(torch.equal(end, torch.get_rng_state()))

    def test_categorical_rates_and_uniform_canonical_replacements(self):
        count = 200_000
        tokens = torch.full((200, count // 200), self.tokenizer.canonical_ids[0])
        masked = torch.full_like(tokens, self.tokenizer.mask_id)
        output, actions = bert_corrupt_selected(
            tokens,
            masked,
            tokens.clone(),
            self.tokenizer,
            generator=torch.Generator().manual_seed(190003),
        )
        for action, probability in ((1, 0.8), (2, 0.1), (3, 0.1)):
            actual = int(actions.eq(action).sum())
            self.assertLess(
                abs(actual - count * probability),
                6 * (count * probability * (1 - probability)) ** 0.5,
            )
        random_tokens = output[actions.eq(2)]
        self.assertTrue(
            torch.isin(random_tokens, torch.tensor(self.tokenizer.canonical_ids)).all()
        )
        n = random_tokens.numel()
        for token_id in self.tokenizer.canonical_ids:
            actual = int(random_tokens.eq(token_id).sum())
            self.assertLess(abs(actual - n / 20), 6 * (n * 0.05 * 0.95) ** 0.5)
        self.assertGreater(random_tokens.eq(tokens[0, 0]).sum(), 0)
        self.assertTrue(output[actions.eq(1)].eq(self.tokenizer.mask_id).all())
        self.assertTrue(output[actions.eq(3)].eq(tokens[0, 0]).all())

    def test_requires_separate_generator_and_matching_shapes(self):
        x = torch.zeros((2, 3), dtype=torch.long)
        with self.assertRaises(ValueError):
            bert_corrupt_selected(x, x, x, self.tokenizer, generator=None)
        with self.assertRaises(ValueError):
            bert_corrupt_selected(x, x[:1], x, self.tokenizer, generator=torch.Generator())


if __name__ == "__main__":
    unittest.main()
