"""Batch independent Muon matrices without changing their update geometry.

Uses the native, uv-locked Muon state layout and hyperparameters. Only the
Newton-Schulz kernel dispatch changes: equal-shaped matrices share batched
GEMMs, with a separate Frobenius normalization for each original matrix.
"""

from collections import defaultdict

import torch
from torch.optim._muon import _adjust_lr


def batched_zeropower(
    updates: torch.Tensor,
    coefficients: tuple[float, float, float],
    steps: int,
    eps: float,
) -> torch.Tensor:
    """Apply native Muon's polynomial independently to a stack of matrices."""
    if updates.ndim != 3:
        raise ValueError("expected a three-dimensional stack of matrices")
    if not 0 <= steps < 100:
        raise ValueError("Newton-Schulz steps must be in [0, 100)")
    a, b, c = coefficients
    value = updates.bfloat16()
    transposed = value.shape[-2] > value.shape[-1]
    if transposed:
        value = value.mT
    value = value / value.norm(dim=(-2, -1), keepdim=True).clamp(min=eps)
    for _ in range(steps):
        gram = torch.bmm(value, value.mT)
        polynomial = torch.baddbmm(gram, gram, gram, beta=b, alpha=c)
        value = torch.baddbmm(value, polynomial, value, beta=a)
    return value.mT if transposed else value


class BatchedMuon(torch.optim.Muon):
    """Native Muon checkpoint format with matrix-shape buckets per group."""

    @torch.no_grad()
    def step(self, closure=None):
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()
        for group in self.param_groups:
            parameters, gradients, buffers = [], [], []
            self._init_group(group, parameters, gradients, buffers)
            buckets = defaultdict(list)
            for parameter, gradient, buffer in zip(parameters, gradients, buffers, strict=True):
                buckets[(parameter.shape, parameter.device, parameter.dtype)].append(
                    (parameter, gradient, buffer)
                )
            for entries in buckets.values():
                updates = []
                for _, gradient, buffer in entries:
                    buffer.lerp_(gradient, 1 - group["momentum"])
                    updates.append(
                        gradient.lerp(buffer, group["momentum"])
                        if group["nesterov"]
                        else buffer
                    )
                orthogonal = batched_zeropower(
                    torch.stack(updates),
                    group["ns_coefficients"],
                    group["ns_steps"],
                    group["eps"],
                )
                adjusted_lr = _adjust_lr(
                    group["lr"], group["adjust_lr_fn"], entries[0][0].shape
                )
                for (parameter, _, _), update in zip(entries, orthogonal, strict=True):
                    parameter.mul_(1 - group["lr"] * group["weight_decay"])
                    parameter.add_(update, alpha=-adjusted_lr)
        return loss
