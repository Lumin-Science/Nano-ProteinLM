"""Check matrix independence, native state compatibility, and full update semantics."""

import copy
import unittest

import torch
from torch.optim._muon import _zeropower_via_newtonschulz

from nano_protein.batched_muon import BatchedMuon, batched_zeropower


def check_each_matrix_has_its_own_normalization_and_polynomial(shape):
    torch.manual_seed(101)
    values = torch.randn(4, *shape)
    values[0].zero_()
    values[1].mul_(1e-4)
    values[2].mul_(1e4)
    original = values.clone()
    coefficients = (3.4445, -4.7750, 2.0315)
    expected = torch.stack(
        [_zeropower_via_newtonschulz(x, coefficients, 5, 1e-7) for x in values]
    )
    actual = batched_zeropower(values, coefficients, 5, 1e-7)
    torch.testing.assert_close(values, original, rtol=0, atol=0)
    torch.testing.assert_close(actual, expected, rtol=0, atol=0)


def check_optimizer_matches_native_and_resumes(nesterov, adjust_lr_fn):
    torch.manual_seed(102)
    parameters = [torch.nn.Parameter(torch.randn(*s)) for s in [(8, 8), (24, 8), (8, 8)]]
    reference = [torch.nn.Parameter(p.detach().clone()) for p in parameters]
    kwargs = dict(lr=0.001, weight_decay=0.02, nesterov=nesterov, adjust_lr_fn=adjust_lr_fn)
    optimizer = BatchedMuon(parameters, **kwargs)
    native = torch.optim.Muon(reference, **kwargs)
    for step in range(3):
        for i, (p, q) in enumerate(zip(parameters, reference, strict=True)):
            p.grad = None if i == 2 and step == 1 else torch.randn_like(p)
            q.grad = None if p.grad is None else p.grad.clone()
        optimizer.param_groups[0]["lr"] = native.param_groups[0]["lr"] = 0.001 * (step + 1)
        optimizer.step()
        native.step()
        for p, q in zip(parameters, reference, strict=True):
            torch.testing.assert_close(p, q, rtol=0, atol=0)
            torch.testing.assert_close(
                optimizer.state[p]["momentum_buffer"],
                native.state[q]["momentum_buffer"],
                rtol=0,
                atol=0,
            )
        if step == 1:
            # A native checkpoint can load into the batched implementation.
            optimizer = BatchedMuon(parameters, **kwargs)
            optimizer.load_state_dict(copy.deepcopy(native.state_dict()))
    assert len(optimizer.state_dict()["state"]) == 3


def check_group_rates_and_closure_are_preserved():
    parameters = [torch.nn.Parameter(torch.ones(8, 8)) for _ in range(2)]
    optimizer = BatchedMuon(
        [{"params": [parameters[0]], "lr": 0.0}, {"params": [parameters[1]], "lr": 0.01}]
    )

    def closure():
        optimizer.zero_grad()
        loss = sum(p.square().sum() for p in parameters)
        loss.backward()
        return loss

    assert optimizer.step(closure).item() == 128
    torch.testing.assert_close(parameters[0], torch.ones_like(parameters[0]))
    assert not torch.equal(parameters[1], torch.ones_like(parameters[1]))


class BatchedMuonTests(unittest.TestCase):
    def test_matrix_independence(self):
        for shape in ((16, 16), (48, 16), (16, 48)):
            with self.subTest(shape=shape):
                check_each_matrix_has_its_own_normalization_and_polynomial(shape)

    def test_native_updates_and_resume(self):
        for nesterov in (False, True):
            for adjustment in (None, "original", "match_rms_adamw"):
                with self.subTest(nesterov=nesterov, adjustment=adjustment):
                    check_optimizer_matches_native_and_resumes(nesterov, adjustment)

    def test_groups_and_closure(self):
        check_group_rates_and_closure_are_preserved()
