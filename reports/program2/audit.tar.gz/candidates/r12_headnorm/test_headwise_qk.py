"""Verify normalization scope, gradients, initialization and frozen checkpoint loading."""

import tempfile
import unittest
from pathlib import Path

import torch

from nano_protein.evaluate import load_checkpoint
from nano_protein.model import (
    ESMCConfig,
    ESMCForMaskedLM,
    ESMCHeadwiseLayerNorm,
    count_parameters,
    expected_parameter_count,
)


class HeadwiseQKTests(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(102)
        torch.set_num_threads(1)

    def test_output_and_gradients_match_independent_head_layernorms(self):
        for shape in ((7, 192), (2, 7, 192)):
            with self.subTest(shape=shape):
                module = ESMCHeadwiseLayerNorm(192, 64).double()
                module.weight.data.copy_(torch.linspace(0.5, 1.5, 192))
                value = torch.randn(*shape, dtype=torch.float64, requires_grad=True)
                reference_input = value.detach().clone().requires_grad_()
                heads = [torch.nn.LayerNorm(64, bias=False).double() for _ in range(3)]
                for head, weights in zip(heads, module.weight.chunk(3), strict=True):
                    head.weight.data.copy_(weights)
                expected = torch.cat(
                    [
                        head(x)
                        for head, x in zip(heads, reference_input.chunk(3, -1), strict=True)
                    ],
                    -1,
                )
                actual = module(value)
                upstream = torch.randn_like(actual)
                (actual * upstream).sum().backward()
                (expected * upstream).sum().backward()
                torch.testing.assert_close(actual, expected, rtol=1e-12, atol=1e-12)
                torch.testing.assert_close(value.grad, reference_input.grad)
                torch.testing.assert_close(
                    module.weight.grad, torch.cat([h.weight.grad for h in heads])
                )

    def test_one_head_cannot_change_another_heads_statistics(self):
        module = ESMCHeadwiseLayerNorm(128, 64).double()
        value = torch.randn(7, 128, dtype=torch.float64)
        altered = value.clone()
        altered[:, :64] = altered[:, :64] * 100 + 1000
        torch.testing.assert_close(
            module(value)[:, 64:], module(altered)[:, 64:], rtol=0, atol=0
        )
        self.assertFalse(
            torch.allclose(module(value), torch.nn.functional.layer_norm(value, (128,)))
        )

    def test_initial_parameters_and_random_state_are_unchanged(self):
        torch.manual_seed(103)
        baseline = ESMCForMaskedLM(ESMCConfig.tiny())
        baseline_rng = torch.get_rng_state()
        torch.manual_seed(103)
        candidate = ESMCForMaskedLM(ESMCConfig.tiny(qk_norm_per_head=True))
        self.assertTrue(torch.equal(baseline_rng, torch.get_rng_state()))
        self.assertEqual(baseline.state_dict().keys(), candidate.state_dict().keys())
        for key, value in baseline.state_dict().items():
            torch.testing.assert_close(value, candidate.state_dict()[key], rtol=0, atol=0)
        config = ESMCConfig.esmc_171m(qk_norm_per_head=True)
        with torch.device("meta"):
            large = ESMCForMaskedLM(config)
        self.assertEqual(count_parameters(large), 170671168)
        self.assertEqual(expected_parameter_count(config), 170671168)
        self.assertEqual(sum(isinstance(m, ESMCHeadwiseLayerNorm) for m in large.modules()), 48)

    def test_frozen_checkpoint_loader_and_attention_features(self):
        config = ESMCConfig.tiny(qk_norm_per_head=True, attention_backend="math")
        model = ESMCForMaskedLM(config).eval()
        tokens = torch.tensor([[0, 4, 5, 6, 2, 1], [0, 7, 8, 9, 10, 2]])
        attention = tokens != 1
        before = model(tokens, attention, output_attentions=True)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "checkpoint.pt"
            torch.save({"model_config": config.to_dict(), "model": model.state_dict()}, path)
            loaded, _ = load_checkpoint(path, torch.device("cpu"))
            after = loaded(tokens, attention, output_attentions=True)
        self.assertTrue(loaded.config.qk_norm_per_head)
        torch.testing.assert_close(before["logits"], after["logits"], rtol=0, atol=0)
        self.assertEqual(len(after["attentions"]), config.n_layers)
        self.assertEqual(after["attentions"][0].shape, (2, config.n_heads, 6, 6))
        for weights in after["attentions"]:
            self.assertTrue(torch.isfinite(weights).all())
            torch.testing.assert_close(weights.sum(-1), torch.ones_like(weights.sum(-1)))
