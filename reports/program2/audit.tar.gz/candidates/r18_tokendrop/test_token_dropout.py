"""Qualify mask embedding dropout, gradients, and frozen checkpoint loading."""

import tempfile
import unittest
from pathlib import Path

import torch

from nano_protein.evaluate import load_checkpoint
from nano_protein.model import ESMCConfig, ESMCForMaskedLM, expected_parameter_count


class TokenDropoutTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1)
        torch.manual_seed(18)

    def test_embedding_transform_matches_independent_row_reference_and_gradients(self):
        model = ESMCForMaskedLM(
            ESMCConfig.tiny(token_dropout=True, attention_backend="math")
        ).double()
        tokens = torch.tensor([[0, 32, 4, 5, 32, 2], [0, 6, 32, 2, 1, 1]])
        mask = tokens.ne(1)
        captured = []
        handle = model.blocks[0].register_forward_pre_hook(
            lambda module, inputs: captured.append(inputs[0])
        )
        model(tokens, mask)
        handle.remove()
        actual = captured[0]
        expected = torch.zeros_like(actual)
        for row in range(len(tokens)):
            valid = mask[row]
            unmasked = valid & tokens[row].ne(32)
            factor = 0.85 * int(valid.sum()) / int(unmasked.sum())
            expected[row, unmasked] = model.embedding(tokens[row, unmasked]) * factor
        torch.testing.assert_close(actual, expected, rtol=1e-7, atol=1e-9)
        a = torch.autograd.grad(actual.square().sum(), model.embedding.weight)[0]
        b = torch.autograd.grad(expected.square().sum(), model.embedding.weight)[0]
        torch.testing.assert_close(a, b, rtol=2e-7, atol=1e-9)
        self.assertEqual(a[32].count_nonzero(), 0)
        self.assertEqual(a[1].count_nonzero(), 0)
        self.assertGreater(a[4].abs().sum(), 0)

    def test_degenerate_masks_unmasked_inference_and_random_state(self):
        model = ESMCForMaskedLM(ESMCConfig.tiny(token_dropout=True, attention_backend="math"))
        tokens = torch.tensor([[32, 32, 32], [1, 1, 1], [0, 4, 2]])
        mask = tokens.ne(1)
        scale = model._token_dropout_scale(tokens, mask)
        self.assertTrue(torch.isfinite(scale).all())
        self.assertEqual(scale[1], 0)
        self.assertAlmostEqual(float(scale[2]), 0.85, places=6)
        rng = torch.get_rng_state()
        captured = []
        handle = model.blocks[0].register_forward_pre_hook(
            lambda module, inputs: captured.append(inputs[0])
        )
        output = model(tokens, mask)
        self.assertTrue(torch.isfinite(output["logits"]).all())
        self.assertEqual(captured[-1][:2].count_nonzero(), 0)
        model.eval()
        model(tokens)
        handle.remove()
        torch.testing.assert_close(captured[0], captured[1], rtol=0, atol=0)
        self.assertTrue(torch.equal(rng, torch.get_rng_state()))

    def test_initialization_parameter_budget_and_frozen_loader(self):
        base = ESMCForMaskedLM(ESMCConfig.tiny(attention_backend="math"))
        rng = torch.get_rng_state()
        torch.manual_seed(18)
        candidate = ESMCForMaskedLM(
            ESMCConfig.tiny(token_dropout=True, attention_backend="math")
        )
        self.assertTrue(torch.equal(rng, torch.get_rng_state()))
        self.assertFalse(base.config.token_dropout)
        self.assertEqual(
            expected_parameter_count(ESMCConfig.esmc_171m(token_dropout=True)), 170_671_168
        )
        for name, value in base.state_dict().items():
            torch.testing.assert_close(value, candidate.state_dict()[name], rtol=0, atol=0)
        tokens = torch.tensor([[0, 32, 4, 2, 1], [0, 5, 32, 6, 2]])
        mask = tokens.ne(1)
        expected = candidate(tokens, mask, output_attentions=True)
        expected["logits"].square().sum().backward()
        self.assertEqual(candidate.embedding.weight.grad[32].count_nonzero(), 0)
        self.assertTrue(
            all(
                p.grad is not None and torch.isfinite(p.grad).all()
                for p in candidate.parameters()
            )
        )
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "checkpoint.pt"
            torch.save(
                {"model_config": candidate.config.to_dict(), "model": candidate.state_dict()},
                path,
            )
            loaded, _ = load_checkpoint(path, torch.device("cpu"))
        self.assertTrue(loaded.config.token_dropout)
        actual = loaded(tokens, mask, output_attentions=True)
        torch.testing.assert_close(actual["logits"], expected["logits"], rtol=0, atol=0)
        for a, b in zip(actual["attentions"], expected["attentions"], strict=True):
            torch.testing.assert_close(a, b, rtol=0, atol=0)


if __name__ == "__main__":
    unittest.main()
