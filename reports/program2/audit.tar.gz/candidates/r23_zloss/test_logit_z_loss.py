"""Check masked z-loss analytically and under real DDP with unequal/empty ranks."""

import math
import tempfile
import unittest
from pathlib import Path

import torch
import torch.distributed as dist
import torch.multiprocessing as mp
from torch.nn.parallel import DistributedDataParallel as DDP

from nano_protein.train import masked_logit_z_loss, training_losses


def _inputs():
    inputs = torch.arange(36, dtype=torch.float64).reshape(4, 3, 3) / 36
    labels = torch.tensor([[0, -100, -100], [-100, -100, -100], [1, 2, 3], [0, 1, -100]])
    return inputs, labels


def _model():
    model = torch.nn.Linear(3, 4, bias=False).double()
    with torch.no_grad():
        model.weight.copy_(torch.arange(12, dtype=torch.float64).reshape(4, 3) / 12)
    return model


def _reference(logits, labels, coefficient):
    numerator = logits.sum() * 0
    denominator = 0.0
    for row in range(labels.shape[0]):
        chosen = labels[row] != -100
        count = int(chosen.sum())
        if not count:
            continue
        selected = logits[row, chosen]
        log_z = selected.exp().sum(-1).log()
        nll = log_z - selected.gather(1, labels[row, chosen, None]).squeeze(1)
        weight = count**0.5
        numerator = numerator + weight * (nll + coefficient * log_z.square()).mean()
        denominator += weight
    return numerator / max(denominator, 1)


def _worker(rank, rendezvous, empty_rank):
    torch.set_num_threads(1)
    dist.init_process_group("gloo", init_method=rendezvous, rank=rank, world_size=2)
    try:
        inputs, labels = _inputs()
        if empty_rank:
            labels[:2] = -100
        reference = _model()
        expected = _reference(reference(inputs), labels, 1e-4)
        expected.backward()
        model = DDP(_model())
        sl = slice(rank * 2, rank * 2 + 2)
        logits = model(inputs[sl])
        mlm, _, mlm_value = training_losses(logits, labels[sl], reduction="sqrt_mask_count")
        z, z_value = masked_logit_z_loss(logits, labels[sl])
        (mlm + 1e-4 * z).backward()
        torch.testing.assert_close(model.module.weight.grad, reference.weight.grad)
        torch.testing.assert_close(mlm_value + 1e-4 * z_value, expected.detach())
    finally:
        dist.destroy_process_group()


class LogitZLossTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1)
        torch.manual_seed(23)

    def test_analytic_gradient_and_masked_weighting(self):
        inputs, labels = _inputs()
        logits = _model()(inputs).detach().requires_grad_()
        loss, value = masked_logit_z_loss(logits, labels)
        expected_gradient = torch.zeros_like(logits)
        denominator = sum(int(row.ne(-100).sum()) ** 0.5 for row in labels)
        expected_value = 0.0
        for row in range(labels.shape[0]):
            positions = labels[row].ne(-100).nonzero().flatten()
            n = len(positions)
            for col in positions:
                exponentials = logits[row, col].detach().exp()
                log_z = exponentials.sum().log()
                weight = n**0.5 / (n * denominator)
                expected_value += weight * log_z.square()
                expected_gradient[row, col] = (
                    weight * 2 * log_z * exponentials / exponentials.sum()
                )
        torch.testing.assert_close(loss, expected_value)
        torch.testing.assert_close(value, expected_value)
        torch.testing.assert_close(torch.autograd.grad(loss, logits)[0], expected_gradient)

    def test_common_logit_shift_changes_z_penalty_but_not_mlm(self):
        inputs, labels = _inputs()
        logits = _model()(inputs)
        a, diagnostic_a, _ = training_losses(logits, labels, reduction="sqrt_mask_count")
        b, diagnostic_b, _ = training_losses(logits + 3, labels, reduction="sqrt_mask_count")
        torch.testing.assert_close(a, b)
        torch.testing.assert_close(diagnostic_a, diagnostic_b)
        z, _ = masked_logit_z_loss(logits, labels)
        shifted, _ = masked_logit_z_loss(logits + 3, labels)
        self.assertGreater(shifted.item(), z.item())

    def test_large_bf16_logits_empty_targets_and_rng(self):
        logits = torch.full((2, 3, 4), 1000.0, dtype=torch.bfloat16, requires_grad=True)
        labels = torch.full((2, 3), -100)
        state = torch.get_rng_state()
        empty, value = masked_logit_z_loss(logits, labels)
        empty.backward()
        self.assertEqual(empty.item(), 0)
        self.assertEqual(value.item(), 0)
        self.assertEqual(logits.grad.count_nonzero(), 0)
        labels[0, 0] = 0
        logits.grad = None
        loss, _ = masked_logit_z_loss(logits, labels)
        self.assertEqual(loss.dtype, torch.float32)
        self.assertAlmostEqual(loss.item() / (1000 + math.log(4)) ** 2, 1, places=6)
        loss.backward()
        self.assertTrue(torch.isfinite(logits.grad).all())
        self.assertTrue(torch.equal(state, torch.get_rng_state()))

    def test_ddp_combined_objective_with_unequal_and_empty_ranks(self):
        for empty_rank in (False, True):
            with (
                self.subTest(empty_rank=empty_rank),
                tempfile.TemporaryDirectory() as directory,
            ):
                mp.spawn(
                    _worker,
                    args=((Path(directory) / "rendezvous").as_uri(), empty_rank),
                    nprocs=2,
                    join=True,
                )


if __name__ == "__main__":
    unittest.main()
