"""Validate value-residual outputs, cross-layer gradients and frozen loader compatibility."""

import copy
import tempfile
import unittest
from pathlib import Path

import torch
import torch.nn.functional as F

from nano_protein.evaluate import load_checkpoint
from nano_protein.model import (
    ESMCConfig,
    ESMCForMaskedLM,
    count_parameters,
    expected_parameter_count,
)


def dense_reference(model, tokens, mask, *, detach_reference=False):
    """Explicit attention equation, without cached QKV or the model's block forward."""
    hidden = model.embedding(tokens)
    first_value = None
    features = []
    for block in model.blocks:
        attention = block.attention
        batch, length, width = hidden.shape
        query, key, value = attention.qkv(attention.norm(hidden)).chunk(3, -1)
        if first_value is None:
            first_value = value.detach() if detach_reference else value
        else:
            value = 0.5 * value + 0.5 * first_value
        query = attention.q_norm(query).view(batch, length, attention.n_heads, -1)
        key = attention.k_norm(key).view(batch, length, attention.n_heads, -1)
        query, key = attention.rotary(query.transpose(1, 2), key.transpose(1, 2))
        value = value.view(batch, length, attention.n_heads, -1).transpose(1, 2)
        scores = query @ key.transpose(-1, -2) / attention.head_dim**0.5
        scores = scores.masked_fill(~mask[:, None, None, :], torch.finfo(scores.dtype).min)
        weights = scores.softmax(-1)
        context = (weights @ value).transpose(1, 2).reshape(batch, length, width)
        hidden = hidden + attention.proj(context) / block.residual_scale
        hidden = hidden + block.ffn(hidden) / block.residual_scale
        features.append(weights)
    hidden = model.final_norm(hidden)
    logits = model.head_out(model.head_norm(F.gelu(model.head_dense(hidden))))
    return logits, features


class ValueResidualTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1)
        torch.manual_seed(26)
        self.tokens = torch.tensor([[0, 4, 5, 6, 2], [0, 7, 8, 2, 1]])
        self.mask = self.tokens != 1

    def model(self, **options):
        return ESMCForMaskedLM(
            ESMCConfig.tiny(n_layers=3, ffn_hidden_dim=192, attention_backend="math", **options)
        )

    def test_manual_attention_and_full_cross_layer_gradient(self):
        model = self.model(value_residual=True)
        reference = copy.deepcopy(model)
        detached = copy.deepcopy(model)
        actual = model(self.tokens, self.mask, output_attentions=True)
        logits, attentions = dense_reference(reference, self.tokens, self.mask)
        torch.testing.assert_close(actual["logits"], logits, rtol=2e-5, atol=2e-6)
        for a, b in zip(actual["attentions"], attentions, strict=True):
            torch.testing.assert_close(a, b, rtol=2e-5, atol=2e-6)
        actual["logits"][self.mask].square().mean().backward()
        logits[self.mask].square().mean().backward()
        for a, b in zip(model.parameters(), reference.parameters(), strict=True):
            self.assertIsNotNone(a.grad)
            torch.testing.assert_close(a.grad, b.grad, rtol=5e-4, atol=3e-6)
        detached_logits, _ = dense_reference(
            detached, self.tokens, self.mask, detach_reference=True
        )
        detached_logits[self.mask].square().mean().backward()
        width = model.config.d_model
        a = model.blocks[0].attention.qkv.weight.grad[2 * width :]
        b = detached.blocks[0].attention.qkv.weight.grad[2 * width :]
        self.assertGreater((a - b).norm().item(), 1e-4)

    def test_each_qkv_evaluated_once_and_no_forward_state_leak(self):
        model = self.model(value_residual=True)
        counts = [0, 0, 0]
        handles = []
        for index, block in enumerate(model.blocks):

            def count(module, inputs, output, index=index):
                counts[index] += 1

            handles.append(block.attention.qkv.register_forward_hook(count))
        first = model(self.tokens, self.mask)["logits"]
        self.assertEqual(counts, [1, 1, 1])
        model(self.tokens.flip(0), self.mask.flip(0))
        third = model(self.tokens, self.mask)["logits"]
        self.assertEqual(counts, [3, 3, 3])
        torch.testing.assert_close(first, third, rtol=0, atol=0)
        for handle in handles:
            handle.remove()

    def test_checkpointed_gradients_and_frozen_loader(self):
        model = self.model(value_residual=True)
        checked = self.model(value_residual=True, gradient_checkpointing=True)
        checked.load_state_dict(model.state_dict())
        a = model(self.tokens, self.mask)["logits"]
        b = checked(self.tokens, self.mask)["logits"]
        torch.testing.assert_close(a, b, rtol=0, atol=0)
        a.square().mean().backward()
        b.square().mean().backward()
        for x, y in zip(model.parameters(), checked.parameters(), strict=True):
            torch.testing.assert_close(x.grad, y.grad, rtol=0, atol=0)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "checkpoint.pt"
            torch.save(
                {"model_config": model.config.to_dict(), "model": model.state_dict()}, path
            )
            loaded, _ = load_checkpoint(path, torch.device("cpu"))
        self.assertTrue(loaded.config.value_residual)
        expected = model(self.tokens, self.mask, output_attentions=True)
        actual = loaded(self.tokens, self.mask, output_attentions=True)
        torch.testing.assert_close(actual["logits"], expected["logits"], rtol=0, atol=0)
        for x, y in zip(actual["attentions"], expected["attentions"], strict=True):
            self.assertEqual(x.shape, (2, 2, 5, 5))
            torch.testing.assert_close(x, y, rtol=0, atol=0)

    def test_unchanged_parameter_budget_initialization_and_first_layer(self):
        base = self.model()
        rng = torch.get_rng_state()
        torch.manual_seed(26)
        variant = self.model(value_residual=True)
        self.assertTrue(torch.equal(rng, torch.get_rng_state()))
        for key, value in base.state_dict().items():
            torch.testing.assert_close(value, variant.state_dict()[key], rtol=0, atol=0)
        legacy = base.config.to_dict()
        del legacy["value_residual"]
        self.assertEqual(ESMCConfig(**legacy), base.config)
        with torch.device("meta"):
            full = ESMCForMaskedLM(
                ESMCConfig.esmc_171m(ffn_hidden_dim=1536, value_residual=True)
            )
        self.assertEqual(count_parameters(full), 142_359_616)
        self.assertEqual(expected_parameter_count(full.config), count_parameters(full))
        config = dict(n_layers=1, ffn_hidden_dim=192, attention_backend="math")
        baseline = ESMCForMaskedLM(ESMCConfig.tiny(**config))
        variant = ESMCForMaskedLM(ESMCConfig.tiny(value_residual=True, **config))
        variant.load_state_dict(baseline.state_dict())
        a = baseline(self.tokens, self.mask)["logits"]
        b = variant(self.tokens, self.mask)["logits"]
        torch.testing.assert_close(a, b, rtol=0, atol=0)


if __name__ == "__main__":
    unittest.main()
