from pathlib import Path
p=Path('nano_protein/model.py');s=p.read_text()
def change(old,new,count=1):
 global s
 assert s.count(old)==count,(s.count(old),old)
 s=s.replace(old,new)
change('    ffn_hidden_dim: int | None = None\n','    ffn_hidden_dim: int | None = None\n    value_residual: bool = False\n')
# Thread an immutable first-layer value and an optional cached projection through attention.
start=s.index('class ESMCAttention');end=s.index('class ESMCFeedForward')
a=s[start:end]
a=a.replace('        maximum_length: int,\n    ) -> torch.Tensor:', '        maximum_length: int,\n        initial_value: torch.Tensor | None = None,\n        projected_qkv: torch.Tensor | None = None,\n    ) -> torch.Tensor:')
a=a.replace('        output_attentions: bool = False,\n', '        output_attentions: bool = False,\n        initial_value: torch.Tensor | None = None,\n        projected_qkv: torch.Tensor | None = None,\n')
assert a.count('        query, key, value = self.qkv(self.norm(hidden)).chunk(3, dim=-1)')==2
a=a.replace('        query, key, value = self.qkv(self.norm(hidden)).chunk(3, dim=-1)', '''        qkv = self.qkv(self.norm(hidden)) if projected_qkv is None else projected_qkv
        query, key, value = qkv.chunk(3, dim=-1)
        if initial_value is not None:
            value = 0.5 * (value + initial_value)''')
s=s[:start]+a+s[end:]
start=s.index('class ESMCBlock');end=s.index('class ESMCForMaskedLM');a=s[start:end]
a=a.replace('        maximum_length: int,\n    ) -> torch.Tensor:', '        maximum_length: int,\n        initial_value: torch.Tensor | None = None,\n        projected_qkv: torch.Tensor | None = None,\n    ) -> torch.Tensor:')
a=a.replace('            maximum_length=maximum_length,\n','            maximum_length=maximum_length,\n            initial_value=initial_value,\n            projected_qkv=projected_qkv,\n')
a=a.replace('        output_attentions: bool = False,\n','        output_attentions: bool = False,\n        initial_value: torch.Tensor | None = None,\n        projected_qkv: torch.Tensor | None = None,\n')
a=a.replace('            hidden, attention_mask, output_attentions=output_attentions\n','            hidden,\n            attention_mask,\n            output_attentions=output_attentions,\n            initial_value=initial_value,\n            projected_qkv=projected_qkv,\n')
s=s[:start]+a+s[end:]
change('    def _forward_packed(\n','''    def _value_residual_inputs(
        self,
        hidden: torch.Tensor,
        layer_index: int,
        initial_value: torch.Tensor | None,
    ) -> tuple[torch.Tensor | None, torch.Tensor | None]:
        if not self.config.value_residual:
            return None, None
        if layer_index == 0:
            attention = self.blocks[0].attention
            # Reuse this projection in layer 1; retain V1's autograd path for all layers.
            qkv = attention.qkv(attention.norm(hidden))
            return qkv, qkv.chunk(3, dim=-1)[2]
        return None, initial_value

    def _forward_packed(
''')
change('        initial_hidden = hidden\n','        initial_hidden = hidden\n        initial_value = None\n',count=2)
change('            hidden = self._route_residual(hidden, initial_hidden, layer_index)\n','''            hidden = self._route_residual(hidden, initial_hidden, layer_index)
            projected_qkv, initial_value = self._value_residual_inputs(
                hidden, layer_index, initial_value
            )
            residual_value = initial_value if layer_index > 0 else None
''',count=2)
change('''                    lambda value, module=block: module.forward_packed(
                        value,
                        cumulative,
                        token_positions,
                        maximum_length=length,
                    ),
                    hidden,
''','''                    lambda value, values, projection, module=block: module.forward_packed(
                        value,
                        cumulative,
                        token_positions,
                        maximum_length=length,
                        initial_value=values,
                        projected_qkv=projection,
                    ),
                    hidden,
                    residual_value,
                    projected_qkv,
''')
change('''                    token_positions,
                    maximum_length=length,
                )
''','''                    token_positions,
                    maximum_length=length,
                    initial_value=residual_value,
                    projected_qkv=projected_qkv,
                )
''')
change('''                    lambda value, module=block: module(value, attention_mask)[0],
                    hidden,
''','''                    lambda value, values, projection, module=block: module(
                        value,
                        attention_mask,
                        initial_value=values,
                        projected_qkv=projection,
                    )[0],
                    hidden,
                    residual_value,
                    projected_qkv,
''')
change('''                    hidden, attention_mask, output_attentions=output_attentions
''','''                    hidden,
                    attention_mask,
                    output_attentions=output_attentions,
                    initial_value=residual_value,
                    projected_qkv=projected_qkv,
''')
p.write_text(s)
p=Path('nano_protein/train.py');s=p.read_text();old='        "ffn_hidden_dim": config.get("ffn_hidden_dim"),\n';assert s.count(old)==1;p.write_text(s.replace(old,old+'        "value_residual": bool(config.get("value_residual", False)),\n'))
for seed in (42,43):
 base=Path(f'configs/program2/r22_ffn1536_seed{seed}.yaml').read_text()
 base=base.replace('# R22: retain 24 layers/width768/12heads, narrow every SwiGLU FFN to1536.','# R26: mix first-layer and current attention values equally in layers2-24.')
 Path(f'configs/program2/r26_valueres_seed{seed}.yaml').write_text(base+'\n# Identity-ResFormer: V_l = 0.5 * (V_1 + V_l); first layer unchanged.\nvalue_residual: true\n')
