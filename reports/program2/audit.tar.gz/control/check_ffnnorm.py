"""Qualify intermediate FFN LayerNorm on synthetic inputs, including real L40S cost."""
import json
import statistics
import time
from pathlib import Path
import torch
from nano_protein.model import ESMCConfig, ESMCForMaskedLM, count_parameters
from nano_protein.tokenizer import ProteinTokenizer, mask_tokens
from nano_protein.train import training_losses, build_optimizer

torch.set_num_threads(1)
torch.set_float32_matmul_precision('high')
assert torch.cuda.get_device_name(0) == 'NVIDIA L40S'
torch.manual_seed(20260906)
base = ESMCForMaskedLM(ESMCConfig.esmc_171m())
initial_rng = torch.get_rng_state()
torch.manual_seed(20260906)
candidate = ESMCForMaskedLM(ESMCConfig.esmc_171m(ffn_activation_norm=True))
assert torch.equal(initial_rng, torch.get_rng_state())
assert count_parameters(candidate) == 170769472
for name,value in base.state_dict().items():
    torch.testing.assert_close(value,candidate.state_dict()[name],rtol=0,atol=0)
base,candidate=base.cuda(),candidate.cuda()
tokenizer=ProteinTokenizer.esmc()
sequences=[('LAGVESIDPKQNFYMHWCART'*26)[:18+(i*83)%490] for i in range(64)]
tokens,attention=tokenizer.encode_batch(sequences,max_length=512)
tokens,attention=tokens.cuda(),attention.cuda()
corrupted,labels=mask_tokens(tokens,attention,tokenizer)
with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16):
    a=base(corrupted,attention)['logits']
    b=candidate(corrupted,attention)['logits']
initial_error=(a[attention].float()-b[attention].float()).abs().max().item()
assert 0 < initial_error < float("inf"),initial_error
del a,b
config={'optimizer':'muon','learning_rate':.000326599,'weight_decay':.0183712}
optimizers=[build_optimizer(m,config) for m in (base,candidate)]
assert len(optimizers[1].named_optimizers[0][1].param_groups[0]['params'])==96

def step(model,optimizer):
    optimizer.zero_grad(set_to_none=True)
    with torch.autocast('cuda',dtype=torch.bfloat16):
        output=model(corrupted,attention)
        loss,_,_=training_losses(output['logits'],labels,reduction='sqrt_mask_count')
    loss.backward()
    torch.nn.utils.clip_grad_norm_(model.parameters(),1.0)
    optimizer.step()
    return loss.detach()

def gradient_profile(model):
    model.zero_grad(set_to_none=True)
    with torch.autocast('cuda',dtype=torch.bfloat16):
        output=model(corrupted,attention)
        loss,_,_=training_losses(output['logits'],labels,reduction='sqrt_mask_count')
    loss.backward()
    values={
        'qkv':[b.attention.qkv.weight.grad.float().norm().item() for b in model.blocks],
        'ffn_gate_up':[b.ffn.gate_up.weight.grad.float().norm().item() for b in model.blocks],
        'ffn_down':[b.ffn.down.weight.grad.float().norm().item() for b in model.blocks],
    }
    return {'loss':loss.item(),'gradient_norms':values,
        'first4_last4_ratios':{name:statistics.mean(v[:4])/statistics.mean(v[-4:]) for name,v in values.items()}}
profiles={'at_initialization':{name:gradient_profile(m) for name,m in (('baseline',base),('candidate',candidate))}}
print(json.dumps({'initial_gradient_ratios':{k:v['first4_last4_ratios'] for k,v in profiles['at_initialization'].items()}}),flush=True)

timings={'native_ms':[],'ffnnorm_ms':[]}
for round_index in range(2):
    for i in ([0,1] if round_index==0 else [1,0]):
        model,optimizer=(base,candidate)[i],optimizers[i]
        for _ in range(3):
            loss=step(model,optimizer)
        torch.cuda.synchronize()
        start=time.perf_counter()
        for _ in range(6):
            loss=step(model,optimizer)
        torch.cuda.synchronize()
        timings[('native_ms','ffnnorm_ms')[i]].append((time.perf_counter()-start)*1000/6)
        assert torch.isfinite(loss)
gates=[block.ffn.gate_up.weight for block in candidate.blocks]
assert len(gates)==24
assert all(w.grad is not None and torch.isfinite(w.grad).all() and w.grad.count_nonzero()>0 for w in gates)
assert all(torch.isfinite(w).all() and w.count_nonzero()>0 for w in gates)
assert all(torch.isfinite(p).all() for p in candidate.parameters())
gate_weight_norms=[w.norm().item() for w in gates]
norm_parameters=[p for name,p in candidate.named_parameters() if '.activation_norm.' in name]
assert len(norm_parameters)==48 and sum(p.numel() for p in norm_parameters)==98304
assert all(p.grad is not None and torch.isfinite(p.grad).all() and p.grad.count_nonzero()>0 for p in norm_parameters)
norm_weights=[b.ffn.activation_norm.weight.detach().mean().item() for b in candidate.blocks]
norm_biases=[b.ffn.activation_norm.bias.detach().norm().item() for b in candidate.blocks]
assert all(b.ffn.activation_norm.weight.ne(1).any() and b.ffn.activation_norm.bias.ne(0).any() for b in candidate.blocks)
profiles['after18_synthetic_updates']={name:gradient_profile(m) for name,m in (('baseline',base),('candidate',candidate))}
peak_memory=torch.cuda.max_memory_allocated()/1024**2
del base,candidate,optimizers,gates,model,optimizer,loss
# Ensure packed/dense paths and contact attention features agree with intermediate FFN LayerNorm.
torch.manual_seed(20260906)
reference=ESMCForMaskedLM(ESMCConfig.tiny(ffn_activation_norm=True,attention_backend='math')).cuda()
packed=ESMCForMaskedLM(ESMCConfig.tiny(ffn_activation_norm=True,attention_backend='flash')).cuda()
packed.load_state_dict(reference.state_dict())
tokens,attention=tokenizer.encode_batch(['ACDEFGHIK','LAGVESIDPKQNFYMHWCA'*3,'GGGGG','ACDEFGHIKLMNPQRSTVWY'*4],max_length=64)
tokens,attention=tokens.cuda(),attention.cuda()
corrupted,labels=mask_tokens(tokens,attention,tokenizer)
outputs=[]
for model in (reference,packed):
    with torch.autocast('cuda',dtype=torch.bfloat16):
        output=model(corrupted,attention)
        loss,_,_=training_losses(output['logits'],labels,reduction='sqrt_mask_count')
    loss.backward()
    outputs.append(output['logits'][attention].detach().float())
max_logit_error=(outputs[0]-outputs[1]).abs().max().item()
assert max_logit_error<.03,max_logit_error
squared_error=squared_reference=0.
for a,b in zip(reference.parameters(),packed.parameters(),strict=True):
    assert a.grad is not None and b.grad is not None
    squared_error+=(a.grad-b.grad).float().square().sum().item()
    squared_reference+=a.grad.float().square().sum().item()
relative_gradient_error=(squared_error/squared_reference)**.5
assert relative_gradient_error<.05,relative_gradient_error
with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16):
    features=packed(corrupted,attention,output_attentions=True)
assert len(features['attentions'])==2
assert all(x.shape==(4,2,64,64) and torch.isfinite(x).all() for x in features['attentions'])
receipt={'status':'passed','gpu':torch.cuda.get_device_name(0),'torch':torch.__version__,
    'parameters':170769472,'added_parameters':98304,'new_norm_vectors_with_finite_nonzero_gradients':48,'new_norm_mean_weights':norm_weights,'new_norm_bias_norms':norm_biases,'gradient_profiles':profiles,'full_size_original_tensors_and_rng':'bitwise identical to R10',
    'full_size_initial_logit_max_error':initial_error,'ffn_gate_up_matrices_with_finite_nonzero_gradients':24,
    'trained_ffn_gate_up_norms':gate_weight_norms,'muon_matrices':96,
    'dense_vs_packed_max_logit_error':max_logit_error,
    'dense_vs_packed_relative_gradient_error':relative_gradient_error,
    'attention_features':'finite with original layer/head/token layout',
    'timing_samples':timings,'native_median_step_ms':statistics.median(timings['native_ms']),
    'ffnnorm_median_step_ms':statistics.median(timings['ffnnorm_ms']),
    'timing_protocol':'batch64 varying lengths <=512, full forward/backward/clip/optimizer, two alternating rounds each 3 warm+6 measured, equal synthetic tokens',
    'data':'synthetic protein sequences only; no training or held-out inputs',
    'peak_memory_mb_two_models':peak_memory}
Path('.dev/program2/candidates/r20_ffnnorm/MODEL_PREFLIGHT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
