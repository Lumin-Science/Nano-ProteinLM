"""Export a read-only Program 2 progress snapshot without changing active training."""
import csv
import gzip
import hashlib
import io
import json
import math
import re
import subprocess
import tarfile
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from statistics import fmean, stdev

root = Path.cwd()
notes = root / '.dev/program2'
out = root / 'reports/program2'
rows = list(csv.DictReader((notes/'results.tsv').open(), delimiter='\t'))
groups = defaultdict(list)
for row in rows:
    groups[row['method_id']].append(row)
labels = [
 ('Original AdamW baseline','Baseline'), ('Hybrid Muon','Algorithm'),
 ('Transformer RMSNorm','Model'), ('Global token-mean loss','Loss'),
 ('Balance masked batches across ranks','Data / systems'), ('Depth-scaled initialization','Model'),
 ('Independent Q/K/V orthogonalization','Algorithm'), ('Rounded mask counts','Data'),
 ('Learned residual/input routes','Model'), ('128-to-512 context curriculum','Data'),
 ('Square-root target-count weighting','Loss'), ('20% masking','Data'),
 ('Headwise Q/K normalization','Model'), ('Polar Express orthogonalization','Algorithm'),
 ('Query-dependent attention gates','Model'), ('AdaMuon','Algorithm'),
 ('GEGLU FFNs','Model'), ('Double Muon update amplitude','Algorithm'),
 ('ESM-2 mask-embedding rescaling','Model / data'), ('80/10/10 corruption','Data'),
 ('Compute final FFN/head at targets only','Systems'), ('Global batch 128','Data / optimization'),
 ('FFN width 1536','Model / compute'), ('Masked logit z-loss','Loss'),
 ('FFN width 1024','Model / compute'), ('Profile-guided FFN allocation','Model / data'),
 ('First-layer value residuals','Model'), ('Cautious Muon weight decay','Algorithm'),
 ('EMA of weights','Algorithm'), ('Shared input/output embeddings','Model'),
]
assert len(groups) == len(labels) == 30
summaries = []
incumbent = None
records = {}
for (method, runs), (label, axis) in zip(groups.items(), labels, strict=True):
    assert len(runs) == 2 and {int(r['seed']) for r in runs} == {42,43}
    runs.sort(key=lambda r: int(r['seed']))
    values = [float(r['validation_loss']) for r in runs]
    mean, sd = fmean(values), stdev(values)
    delta = 0.0 if incumbent is None else incumbent['mean'] - mean
    status = 'baseline' if incumbent is None else ('keep' if delta > sd else 'discard')
    for r in runs:
        for field, expected in [('validation_loss_mean',mean),('validation_loss_std',sd),('delta',delta)]:
            assert math.isclose(float(r[field]), expected, abs_tol=1e-12), (method,field)
        assert r['status'] == status and int(r['n_runs']) == 2
        assert float(r['training_seconds']) >= 3600
        run = root/'outputs/program2'/r['run_id']
        state = dict(line.split('=',1) for line in (run/'ROUND_STATE').read_text().splitlines())
        assert state['state'] == 'complete'
        receipt = json.loads((run/'PROGRAM2_VERIFICATION.json').read_text())
        assert receipt['status'] == 'verified'
    folder = notes/'candidates'/method
    metadata = json.loads((folder/'METHOD.json').read_text()) if (folder/'METHOD.json').exists() else {}
    decision = json.loads((folder/'DECISION.json').read_text()) if (folder/'DECISION.json').exists() else {}
    commit = decision.get('accepted_commit',decision.get('keep_commit',''))
    summary = dict(method_id=method, title=label, axis=axis,
        incumbent_before=incumbent['method_id'] if incumbent else '',
        seed42=values[0], seed43=values[1], mean=mean, sample_sd=sd, delta=delta,
        relative_gain_pct=100*delta/incumbent['mean'] if incumbent else 0,
        decision=status, accepted_commit=commit,
        mean_train_loss=fmean(float(r['train_loss']) for r in runs),
        mean_p_at_l=fmean(float(r['p_at_l']) for r in runs),
        mean_model_tokens_M=fmean(float(r['model_tokens_M']) for r in runs),
        params_M=float(runs[0]['params_M']), mean_steps=fmean(float(r['actual_steps']) for r in runs),
        mean_training_seconds=fmean(float(r['training_seconds']) for r in runs),
        mean_evaluation_seconds=fmean(float(r['evaluation_seconds']) for r in runs))
    summaries.append(summary)
    records[method] = {'summary':summary,'runs':runs,'proposal':metadata,'decision_receipt':decision}
    if status in ('keep','baseline'):
        incumbent = summary
assert incumbent['method_id'] == 'r29_tied'
base = summaries[0]
r22 = next(s for s in summaries if s['method_id']=='r22_ffn1536')
r29 = incumbent
accepted = [s for s in summaries if s['decision'] in ('keep','baseline')]
now = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
active = []
for method, run_id, seed, node in [line.split('\t') for line in (notes/'launches.tsv').read_text().splitlines()]:
    if method in groups:
        continue
    run = root/'outputs/program2'/run_id
    state = dict(line.split('=',1) for line in (run/'ROUND_STATE').read_text().splitlines())
    raw = (run/'metrics.jsonl').read_text()
    lines = raw.splitlines()
    if not raw.endswith('\n'):
        lines = lines[:-1]
    metrics = [json.loads(line) for line in lines]
    metrics = [r for r in metrics if r.get('event')=='train']
    last = metrics[-1]
    assert state['state']=='running' and all(math.isfinite(last[k]) for k in ('loss','objective_loss','gradient_norm'))
    active.append({'method':method,'run_id':run_id,'seed':int(seed),'node':node,'state':state['state'],
        'last_logged_step':last['optimizer_step'],'last_training_loss':last['loss'],
        'learning_rate':last['learning_rate'],'weight_averaging':last.get('weight_averaging'),
        'validation_loss':None})
for folder in sorted((notes/'candidates').iterdir()):
    if not folder.is_dir() or folder.name in records:
        continue
    records[folder.name] = {key:json.loads((folder/name).read_text()) for key,name in
        [('proposal','METHOD.json'),('decision_receipt','DECISION.json')]
        if (folder/name).exists()}
(out/'runs.tsv').write_bytes((notes/'results.tsv').read_bytes())
with (out/'methods.tsv').open('w', newline='') as handle:
    writer = csv.DictWriter(handle,fieldnames=list(summaries[0]),delimiter='\t',lineterminator='\n')
    writer.writeheader();writer.writerows(summaries)
(out/'experiments.json').write_text(json.dumps({'as_of_utc':now,'methods':records},indent=2)+'\n')
(out/'running.json').write_text(json.dumps({'as_of_utc':now,'runs':active,'next_check_utc':'2026-09-06T23:09:18Z'},indent=2)+'\n')
(out/'JOURNAL.md').write_bytes((notes/'RESEARCH.md').read_bytes())

# Preserve local evidence and candidate snapshots, including retained third-party notices.
files = {}
for p in sorted((notes/'candidates').rglob('*')):
    if p.is_file() and '__pycache__' not in p.parts:
        files[str(p.relative_to(notes))] = p.read_bytes()
for p in sorted(notes.iterdir()):
    if p.is_file() and (p.suffix in ('.py','.sh','.json','.tsv') or p.name=='RESEARCH.md'):
        files['control/'+p.name] = p.read_bytes()
for r in rows:
    run = root/'outputs/program2'/r['run_id']
    for name in ('ROUND_SUMMARY.json','TRAINING_COMPLETE.json','run_contract.json',
                 'PROGRAM2_VERIFICATION.json','ENVIRONMENT.json','eval-validation/VALIDATION_MLM.json'):
        files[f'runs/{r["run_id"]}/{name}'] = (run/name).read_bytes()
files['protocol/program2.md'] = (root/'program2.md').read_bytes()
secret = re.compile(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|sk-[A-Za-z0-9]{30,}')
for name, data in files.items():
    assert len(data)<5_000_000 and not secret.search(data), name
    assert not name.endswith(('.pt','.bin','.npy','.npz')),name
manifest = {name:hashlib.sha256(data).hexdigest() for name,data in files.items()}
with (out/'audit.tar.gz').open('wb') as target:
    with gzip.GzipFile(fileobj=target,mode='wb',mtime=0,filename='') as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as archive:
            for name,data in sorted(files.items()):
                info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
                archive.addfile(info,io.BytesIO(data))
(out/'audit-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')

pct = 100*(base['mean']-r29['mean'])/base['mean']
md = [f'# Program 2: validation-loss autoresearch progress\n\nSnapshot: **{now}**. ',
    f'**{len(groups)} completed methods / {len(rows)} full-hour runs / 5 accepted changes.** ',
    'The completed runs represent 240 GPU-hours of scheduled training, excluding preflight and evaluation.\n\n',
    f'Current accepted recipe: **R29 shared input/output embeddings**, mean validation loss ',
    f'**{r29["mean"]:.8f} ± {r29["sample_sd"]:.8f}** (sample SD across seeds 42 and 43). ',
    f'This is **{base["mean"]-r29["mean"]:.8f} lower ({pct:.2f}%)** than the original AdamW baseline. ',
    f'Accepted code: [`{r29["accepted_commit"][:7]}`](https://github.com/Lumin-Science/LuminBench-Nano-ESMC/commit/{r29["accepted_commit"]}).\n\n',
    'Program 2 selects on frozen held-out MLM loss. Contact P@L and training loss are diagnostics; ',
    'the repository’s separate P@L campaign has its own results and selection rules.\n\n',
    '## R29 improvement\n\n',
    'R29 ties the input embedding to the final vocabulary projection. Both roles contribute gradients ',
    'to one AdamW-owned parameter; the rest of R22 is retained. It removes 49,152 parameters, ',
    'giving **142,310,464** trainable parameters.\n\n',
    '| Seed | R22 validation loss | R29 validation loss | Reduction |\n|---|---:|---:|---:|\n']
for seed,key in [(42,'seed42'),(43,'seed43')]:
    md.append(f'| {seed} | {r22[key]:.8f} | {r29[key]:.8f} | {r22[key]-r29[key]:.8f} |\n')
md.append(f'| **Mean** | **{r22["mean"]:.8f}** | **{r29["mean"]:.8f}** | **{r29["delta"]:.8f} ({r29["relative_gain_pct"]:.2f}%)** |\n\n')
md.append(f'The gain **{r29["delta"]:.8f}** exceeds R29’s sample SD **{r29["sample_sd"]:.8f}**, so it passes the exact acceptance rule. ')
md.append('All 32 tests, full-size L40S qualification, checkpoint sharing and optimizer-state checks, four-rank data replay, and frozen evaluations passed.\n\n')
md.append('| Seed | Final-100 train loss | Full contact P@L | Steps | Tokens (M) |\n|---|---:|---:|---:|---:|\n')
for r in groups['r29_tied']:
    md.append(f'| {r["seed"]} | {float(r["train_loss"]):.6f} | {float(r["p_at_l"]):.6f} | {r["actual_steps"]} | {float(r["model_tokens_M"]):.3f} |\n')
md.append('\n## Accepted sequence\n\nEach accepted change is applied to the previous accepted recipe.\n\n')
md.append('| Method | Change | Mean loss | Sample SD | Gain vs. incumbent | Commit |\n|---|---|---:|---:|---:|---|\n')
for s in accepted:
    commit=f'[`{s["accepted_commit"][:7]}`](https://github.com/Lumin-Science/LuminBench-Nano-ESMC/commit/{s["accepted_commit"]})' if s['accepted_commit'] else 'baseline'
    md.append(f'| {s["method_id"]} | {s["title"]} | {s["mean"]:.6f} | {s["sample_sd"]:.6f} | {s["delta"]:+.6f} | {commit} |\n')
md.append('\n## All completed rounds\n\nPositive gain means lower loss than the incumbent **at that round**. A lower mean alone does not qualify: gain must exceed that candidate’s sample SD.\n\n')
md.append('| Method | Change | Axis | Seed 42 | Seed 43 | Mean ± SD | Gain | Decision |\n|---|---|---|---:|---:|---:|---:|---|\n')
for s in summaries:
    md.append(f'| {s["method_id"]} | {s["title"]} | {s["axis"]} | {s["seed42"]:.6f} | {s["seed43"]:.6f} | {s["mean"]:.6f} ± {s["sample_sd"]:.6f} | {s["delta"]:+.6f} | **{s["decision"]}** |\n')
md.append('''
## What the results support

- **Algorithm:** hybrid Muon was accepted. Alternative orthogonalization, adaptivity, and cautious decay failed their paired tests. R28 EMA lowered both seed losses but its 0.006098 mean gain did not exceed its 0.008648 SD; it was discarded.
- **Data and execution:** balancing the same masked batch across ranks was accepted. Changes to mask count, mask rate, corruption, context curriculum, and smaller batches did not qualify.
- **Loss:** globally normalized square-root target-count weighting was accepted. Global token averaging narrowly missed the threshold; added logit z-loss did not help.
- **Model:** FFN width 1536 and shared vocabulary embeddings were accepted. Further narrowing to 1024 processed more tokens but worsened loss; layerwise width allocation and value residuals also failed.

These are results under the fixed one-hour protocol and 32-sequence validation sample, not claims about longer training or general protein-task accuracy. SD measures variation across two training seeds; it is not a confidence interval or a formal significance test.

## Work in progress and preflight-only branches

**R30: EMA on accepted R29.** Both seeds run from scratch, with EMA decay 0.999 starting after update 554. Shared weights are averaged once, all averaging cost counts inside the hour, and only the predeclared EMA is evaluated. R30 must beat the new R29 mean of 2.580568107776344 by more than its own sample SD. Its result is **pending**.

''')
for r in active:
    md.append(f'- Seed {r["seed"]}, {r["node"]}: {r["state"]}, last logged step **{r["last_logged_step"]}** at this snapshot.\n')
md.append('''
The next automated check is scheduled for **2026-09-06 23:09:18 UTC / 7:09:18 p.m. Toronto**. See [running.json](running.json) for the timestamped snapshot; this document is not live telemetry.

Two branches were stopped after preflight and have no model-quality result: batched Muon saved only about 0.7 ms in an optimizer-only benchmark, and FFN activation normalization added about 18.47% to synthetic step cost without supporting its intended gradient-balance mechanism. They are excluded from the completed-round count.

## Fixed protocol and accepted recipe

- Seeds 42 and 43 run simultaneously on kn081 and kn056, four L40S GPUs per seed, from scratch, at most 171M trainable parameters, for a synchronized 3,600-second training budget.
- Every learning-rate group warms linearly for exactly 554 optimizer steps and then remains at its fixed peak. The corpus, mixture, tokenizer, dependency lock, hardware class, and evaluators are frozen.
- Selection uses `sequence_mean_nll` over 8 batches × 4 sequences, context 512, evaluation seed 20260821: 32 sequences and 994 masked targets. Acceptance is `incumbent_mean - candidate_mean > candidate_sample_SD` with `ddof=1`.
- Current model: 24 layers, width 768, 12 heads, SwiGLU FFN width 1536, whole-projection Q/K LayerNorm, RoPE base 10,000, and tied vocabulary embeddings.
- Native Muon handles 96 transformer matrices; AdamW handles embeddings, prediction head, and scalar parameters. Global batch 256, context 512, 15% masking, balanced ranks, and square-root target-count weighting remain accepted.

Full contract: [program2.md](../../program2.md). Accepted seed configs: [seed 42](../../configs/program2/r29_tied_seed42.yaml), [seed 43](../../configs/program2/r29_tied_seed43.yaml). The runner requires `CONFIG` to select these explicitly; its default belongs to the separate P@L campaign.

## Evidence and research provenance

- [runs.tsv](runs.tsv): all 60 completed run rows, including loss, P@L, time, tokens, memory, and decisions. `NA` commit entries mean the candidate was uncommitted during execution; accepted commits are mapped in the method summaries and decision receipts.
- [methods.tsv](methods.tsv): per-method statistics and diagnostics, independently recomputed from run rows when exporting this report.
- [experiments.json](experiments.json): proposals, source/config hashes, references, and final decisions. Historical proposal statuses are preserved; the result summary and decision receipt determine the outcome.
- [JOURNAL.md](JOURNAL.md): full chronological research reasoning, implementation qualifications, and outcomes, including rejected ideas.
- [audit.tar.gz](audit.tar.gz), with [SHA-256 manifest](audit-manifest.json): archived candidate code/configs/patches, preflight evidence and retained licenses, local orchestration/verification helpers, and all completed run summaries and receipts. Some early candidates are represented by configs and accepted Git history rather than a full source snapshot. Active R30 is explicitly unaccepted. The archive contains no model checkpoints or corpus data; host-specific paths in receipts identify original provenance.

Literature informed hypotheses rather than establishing outcomes here. Examples include [Muon](https://arxiv.org/abs/2502.16982), [Hydraulis](https://arxiv.org/abs/2412.07894), [weight tying](https://aclanthology.org/E17-2025/) and the [ESM-2 implementation](https://github.com/facebookresearch/esm/blob/main/esm/model/esm2.py), [value residual learning](https://aclanthology.org/2025.acl-long.1375/), and [constant-rate weight averaging](https://arxiv.org/abs/2602.03702). The journal records each adaptation and its limitations.
''')
(out/'README.md').write_text(''.join(md))
print(json.dumps({'as_of':now,'completed_methods':len(groups),'completed_runs':len(rows),'accepted_changes':len(accepted)-1,
 'r29_gain':r29['delta'],'r29_gain_pct':r29['relative_gain_pct'],'gain_vs_original_pct':pct,
 'archive_files':len(files),'archive_bytes':(out/'audit.tar.gz').stat().st_size,'active':active},indent=2))
