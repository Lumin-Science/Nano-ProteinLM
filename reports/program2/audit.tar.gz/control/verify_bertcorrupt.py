"""Verify R19 selected-target replacement corruption, deterministic training data, and saved optimizer."""
import argparse
import hashlib
import json
import math
from pathlib import Path

import torch
import yaml

from nano_protein.batch_balance import balanced_partitions
from nano_protein.data import MixtureBatcher
from nano_protein.tokenizer import ProteinTokenizer

parser = argparse.ArgumentParser()
parser.add_argument('--require-complete', action='store_true')
args = parser.parse_args()
torch.set_num_threads(1)
method = 'r19_bertcorrupt'
notes = Path('.dev/program2')
candidate = notes/'candidates'/method
metadata = json.loads((candidate/'METHOD.json').read_text())
for key in ('source_hashes', 'config_hashes'):
    for path, digest in metadata[key].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest, path
launches = [line.split('\t') for line in (notes/'launches.tsv').read_text().splitlines()]
launches = [row for row in launches if row[0] == method]
assert len(launches) == 2
checks = []
for _, run_id, seed, node in launches:
    run = Path('outputs/program2')/run_id
    state = dict(line.split('=', 1) for line in (run/'ROUND_STATE').read_text().splitlines())
    assert state['state'] in ('running', 'complete')
    if args.require_complete:
        assert state['state'] == 'complete'
    contract = json.loads((run/'run_contract.json').read_text())
    config = yaml.safe_load(Path(contract['config_path']).read_text())
    incumbent = yaml.safe_load(Path(f'configs/program2/r10_sqrtloss_seed{seed}.yaml').read_text())
    assert config == dict(incumbent, training_corruption='bert_80_10_10')
    assert config['seed'] == int(seed)
    assert contract['config_sha256'] == metadata['config_hashes'][f'configs/program2/{method}_seed{seed}.yaml']
    assert contract['git_commit'] == metadata['source_base_commit']
    assert contract['world_size'] == 4 and contract['visible_gpu'] == 'NVIDIA L40S'
    raw = (run/'metrics.jsonl').read_text()
    lines = raw.splitlines()
    if not raw.endswith('\n'):
        lines = lines[:-1]
    records = [json.loads(line) for line in lines]
    records = {r['optimizer_step']: r for r in records if r.get('event') == 'train'}
    assert max(records) >= 100
    stage = config['stages'][0]
    assert len(config['stages']) == 1 and stage['context_length'] == 512
    assert stage['micro_batch_size'] == 64 and stage['gradient_accumulation'] == 1
    references = [MixtureBatcher(Path(contract['data_manifest']).parent, 'train', stage['mixture'],
                                seed=int(seed), rank=rank, world_size=4) for rank in range(4)]
    tokenizer = ProteinTokenizer.esmc()
    total_tokens = 0
    selected_total = eligible_total = 0
    expected_masks = mask_variance = 0.0
    replacement_totals = {'mask':0,'random':0,'original':0,'random_equal_original':0}
    residue_counts = [0]*20
    for step in range(1, max(records)+1):
        before, lengths = [], []
        for rank, batcher in enumerate(references):
            tokens, attention = batcher.batch(64, context_length=512, tokenizer=tokenizer)
            if rank == 0 and step in records:
                eligible_counts = (attention & torch.isin(tokens, torch.tensor(tokenizer.canonical_ids))).sum(1).tolist()
            n = attention.sum(1).tolist()
            before.append(sum(n))
            lengths.extend(n)
        total_tokens += sum(before)
        if step not in records:
            continue
        r = records[step]
        assert r['stage'] == 'stage1'
        masks = r['corruption_counts_rank0']
        assert r['training_corruption'] == 'bert_80_10_10'
        assert masks['generator_seed'] == 1_900_003+int(seed)
        assert masks['eligible'] == eligible_counts
        assert len(masks['selected']) == 64
        for selected, n in zip(masks['selected'], eligible_counts, strict=True):
            assert (1 <= selected <= n) if n else selected == 0
            selected_total += selected
            eligible_total += n
            if n:
                expected_masks += .15*n + .85**n
                mask_variance += n*.15*.85 + .85**n - 2*.15*n*.85**n - .85**(2*n)
        for field in replacement_totals:
            assert len(masks[field]) == 64
            assert all(isinstance(v,int) and v >= 0 for v in masks[field])
            replacement_totals[field] += sum(masks[field])
        for index,selected in enumerate(masks['selected']):
            assert selected == sum(masks[field][index] for field in ('mask','random','original'))
            assert masks['random_equal_original'][index] <= masks['random'][index]
        values=masks['random_residue_counts']
        assert len(values)==20 and all(isinstance(v,int) and v >= 0 for v in values)
        assert sum(values)==sum(masks['random'])
        residue_counts=[a+b for a,b in zip(residue_counts,values,strict=True)]
        assert r['training_loss_reduction'] == 'sqrt_mask_count'
        for field in ('loss', 'objective_loss', 'gradient_norm'):
            assert math.isfinite(r[field]), (run_id, step, field)
        assert r['loss'] >= 0 and r['objective_loss'] >= 0
        assert math.isclose(r['learning_rate'], config['learning_rate']*min(step/554, 1))
        assert r['step_model_tokens'] == sum(before) and r['model_tokens'] == total_tokens
        assert r['filled_residues'] == total_tokens-step*512
        assert r['sequences_seen'] == step*256
        assert r['source_counts_rank0'] == dict(references[0].source_counts)
        after = [sum(lengths[i] for i in ids) for ids in balanced_partitions(lengths, 4)]
        assert r['batch_balance']['rank_tokens_before'] == before
        assert r['batch_balance']['rank_tokens_after'] == after
        assert sum(after) == sum(before) and max(after) <= max(before)
    z_score = (selected_total-expected_masks)/math.sqrt(mask_variance)
    assert abs(z_score) < 8, (run_id, z_score)
    replacement_z_scores={}
    for field,probability in (('mask',.8),('random',.1),('original',.1)):
        z=(replacement_totals[field]-selected_total*probability)/(selected_total*probability*(1-probability))**.5
        assert abs(z)<8,(run_id,field,z)
        replacement_z_scores[field]=z
    n_random=replacement_totals['random']
    assert n_random>0
    for i,count in enumerate(residue_counts):
        assert abs(count-n_random/20)<8*(n_random*.05*.95)**.5,(run_id,i,count)
    same_z=(replacement_totals['random_equal_original']-.05*n_random)/(n_random*.05*.95)**.5
    assert abs(same_z)<8,(run_id,'random_equal_original',same_z)
    check = {'seed':int(seed), 'node':node, 'run_id':run_id,
             'last_step':max(records), 'last_loss':records[max(records)]['loss'],
             'last_objective_loss':records[max(records)]['objective_loss'],
             'verified_records':len(records), 'replayed_steps':max(records),
             'logged_mask_targets':selected_total, 'logged_eligible_residues':eligible_total,
             'observed_mask_fraction':selected_total/eligible_total, 'mask_count_z_score':z_score,
             'replacement_totals':replacement_totals,'replacement_z_scores':replacement_z_scores,
             'random_residue_counts':residue_counts,'random_same_z_score':same_z}
    if args.require_complete:
        saved = torch.load(run/'checkpoint-final.pt', map_location='cpu', weights_only=False, mmap=True)
        assert saved['train_config'] == config and saved['parameter_count'] == 170671168
        assert saved['model_config']['n_layers'] == 24 and saved['model_config']['d_model'] == 768
        optimizers = saved['optimizer']['optimizers']
        assert [o['name'] for o in optimizers] == ['muon', 'adamw']
        states = optimizers[0]['state_dict']['state']
        assert len(states) == 96
        shapes = {}
        for entry in states.values():
            buffer = entry['momentum_buffer']
            assert torch.isfinite(buffer).all()
            key = str(tuple(buffer.shape))
            shapes[key] = shapes.get(key, 0)+1
        assert shapes == {'(2304, 768)':24, '(768, 768)':24, '(4096, 768)':24, '(768, 2048)':24}
        assert saved['model_config'].get('token_dropout',False) is False
        for entry in states.values():
            assert set(entry)=={'momentum_buffer'}
        for group in optimizers[0]['state_dict']['param_groups']:
            assert group['ns_steps']==5 and group['momentum']==.95 and group['nesterov'] is True
            assert group['lr_scale']==1.
        check['checkpoint_optimizer_step'] = saved['optimizer_step']
        check['muon_state_shapes'] = shapes
        del saved
    checks.append(check)
    print(json.dumps(check), flush=True)
receipt = {'status':'verified', 'checks':checks,
           'data':'Every sampled training batch replayed across four ranks; original 15% selected-target law, 80/10/10 replacement branch rates, uniform canonical random residues and accepted balancing verified from logged counts.'}
name = 'COMPLETE_REPLAY_VERIFICATION.json' if args.require_complete else 'STARTUP_VERIFICATION.json'
(candidate/name).write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps({'status':'verified', 'receipt':str(candidate/name)}), flush=True)
