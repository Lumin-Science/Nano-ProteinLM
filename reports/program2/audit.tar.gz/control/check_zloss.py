"""Full-size L40S qualification for the masked logit z-loss on accepted R22."""
import copy,json,statistics,time
from pathlib import Path
import torch,yaml
from nano_protein.model import ESMCConfig,ESMCForMaskedLM,count_parameters
from nano_protein.tokenizer import ProteinTokenizer,mask_tokens
from nano_protein.train import build_optimizer,training_losses,masked_logit_z_loss

torch.set_num_threads(1);torch.set_float32_matmul_precision('high')
assert torch.cuda.get_device_name(0)=='NVIDIA L40S'
root=Path('.dev/program2/candidates/r23_zloss')
base_config=yaml.safe_load(Path('configs/program2/r22_ffn1536_seed42.yaml').read_text())
config=yaml.safe_load(Path('configs/program2/r23_zloss_seed42.yaml').read_text())
expected=copy.deepcopy(base_config);expected['logit_z_loss_coefficient']=1e-4;assert config==expected
models=[];states=[]
for _ in range(2):
    torch.manual_seed(23)
    models.append(ESMCForMaskedLM(ESMCConfig.esmc_171m(ffn_hidden_dim=1536)).cuda())
    states.append(torch.get_rng_state())
assert torch.equal(*states)
assert all(count_parameters(m)==142359616 for m in models)
for k,v in models[0].state_dict().items():torch.testing.assert_close(v,models[1].state_dict()[k],rtol=0,atol=0)
optimizers=[build_optimizer(m,c) for m,c in zip(models,(base_config,config),strict=True)]
assert all(len(o.named_optimizers[0][1].param_groups[0]['params'])==96 for o in optimizers)
tokenizer=ProteinTokenizer.esmc()
sequences=[('LAGVESIDPKQNFYMHWCART'*26)[:18+(i*83)%490] for i in range(64)]
tokens,attention=tokenizer.encode_batch(sequences,max_length=512)
tokens,attention=tokens.cuda(),attention.cuda();torch.cuda.manual_seed(23)
corrupted,labels=mask_tokens(tokens,attention,tokenizer)
with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16):
    logits=models[0](corrupted,attention)['logits']
    other=models[1](corrupted,attention)['logits']
torch.testing.assert_close(logits,other,rtol=0,atol=0)
# Independent stabilized normalizer/analytic derivative on actual model logits.
x=logits.detach().float().requires_grad_();z,z_value=masked_logit_z_loss(x,labels)
counts=labels.ne(-100).sum(1).float();weights=counts.sqrt();denominator=weights.sum()
maximum=x.detach().amax(-1,keepdim=True);exps=(x.detach()-maximum).exp();log_z=maximum.squeeze(-1)+exps.sum(-1).log()
per_token_weight=(weights/counts.clamp_min(1)/denominator)[:,None]*labels.ne(-100)
reference=(per_token_weight*log_z.square()).sum()
torch.testing.assert_close(z,reference,rtol=1e-6,atol=1e-6)
grad=torch.autograd.grad(z,x)[0]
reference_grad=per_token_weight[:,:,None]*2*log_z[:,:,None]*exps/exps.sum(-1,keepdim=True)
torch.testing.assert_close(grad,reference_grad,rtol=3e-6,atol=1e-7)
assert grad[labels.eq(-100)].count_nonzero()==0
assert torch.isfinite(grad).all() and grad.count_nonzero()>0
initial_z=float(z_value);initial_mean_log_z=float((per_token_weight*log_z).sum())
bias_direction=float(grad.sum());assert bias_direction>0
assert abs(bias_direction-2*initial_mean_log_z)<1e-5
# The helper cannot consume the CUDA RNG used for future MLM masks.
state=torch.cuda.get_rng_state();masked_logit_z_loss(x,labels);assert torch.equal(state,torch.cuda.get_rng_state())
del logits,other,x,z,z_value,grad,reference_grad,reference,exps,maximum,log_z

def step(index):
    model,opt=models[index],optimizers[index];opt.zero_grad(set_to_none=True)
    with torch.autocast('cuda',dtype=torch.bfloat16):
        output=model(corrupted,attention)
        loss,diagnostic,objective=training_losses(output['logits'],labels,reduction='sqrt_mask_count')
        if index==1:
            z,_=masked_logit_z_loss(output['logits'],labels);loss=loss+1e-4*z
    loss.backward();norm=torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step()
    return loss.detach(),diagnostic,objective,norm.detach()

timings={'baseline_ms':[],'zloss_ms':[]}
for round_index in range(2):
    for index in ([0,1] if round_index==0 else [1,0]):
        for _ in range(3):loss,diagnostic,objective,norm=step(index)
        torch.cuda.synchronize();start=time.perf_counter()
        for _ in range(6):loss,diagnostic,objective,norm=step(index)
        torch.cuda.synchronize()
        timings[('baseline_ms','zloss_ms')[index]].append((time.perf_counter()-start)*1000/6)
        assert all(torch.isfinite(v) for v in (loss,diagnostic,objective,norm))
assert all(torch.isfinite(p).all() and p.grad is not None and torch.isfinite(p.grad).all() for p in models[1].parameters())
final_z=[]
for model in models:
    with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16):
        logits=model(corrupted,attention)['logits'];_,value=masked_logit_z_loss(logits,labels)
    final_z.append(float(value))
a=statistics.median(timings['baseline_ms']);b=statistics.median(timings['zloss_ms'])
receipt={'status':'passed','gpu':torch.cuda.get_device_name(0),'parameters':142359616,'muon_matrices':96,
 'coefficient':1e-4,'loss_definition':'Global sqrt-mask-count weighted sequence mean of logsumexp(all64logits)^2 at existing masked targets; zero elsewhere; original MLM diagnostics separate',
 'fullsize_initial_weights_rng_logits':'Bitwise equal between candidate and accepted R22 model',
 'initial_z_loss':initial_z,'initial_added_objective':initial_z*1e-4,'initial_mean_log_normalizer':initial_mean_log_z,
 'initial_z_gradient_sum':bias_direction,'analytic_fullsize_logit_gradient':'Matches independent max-shifted exp/log reference; no gradient at ignored positions',
 'rng':'CUDA masking RNG unchanged by helper','all_parameters_and_gradients_finite':True,
 'final_synthetic_z_loss_baseline_candidate':final_z,'synthetic_loss_note':'Repeated synthetic fitting is only a mechanism/correctness diagnostic, not evidence of validation quality',
 'timing_samples':timings,'baseline_median_step_ms':a,'candidate_median_step_ms':b,'step_cost_ratio':b/a,
 'timing_protocol':'Same64 synthetic masked sequences length<=512; two alternating rounds each3warm+6measured full forward/backward/clip/Muon+AdamW steps, no distributed communication; paired hour confirms overhead',
 'data':'Synthetic proteins only; no training or held-out inputs','peak_memory_mb_two_models':torch.cuda.max_memory_allocated()/1024**2}
(root/'LOSS_PREFLIGHT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
