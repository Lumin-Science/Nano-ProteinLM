"""Separate polynomial precision from adaptive algorithm differences."""
import importlib.util,json
from pathlib import Path
from unittest.mock import patch
import torch
from torch.optim._muon import _zeropower_via_newtonschulz
from nano_protein.adaptive_muon import AdaMuon

torch.set_num_threads(1);torch.manual_seed(20260906)
p=Path('.dev/program2/candidates/r15_adamuon')
spec=importlib.util.spec_from_file_location('authors_adamuon',p/'reference_adamuon.py')
reference=importlib.util.module_from_spec(spec);spec.loader.exec_module(reference)
class Handle:
    def wait(self): pass
def gather(output,update,async_op=True):
    output[0].copy_(update);return Handle()
def aligned_ns(g,steps):
    return _zeropower_via_newtonschulz(g,(3.4445,-4.775,2.0315),steps,1e-7).float()
rows=[]
for shape in ((2304,768),(768,768),(4096,768),(768,2048)):
    g=torch.randn(shape,device='cuda')*.001
    a=aligned_ns(g.sign(),5);b=reference.zeropower_via_newtonschulz5(g.sign(),5).float()
    flips=a.sign()!=b.sign()
    row={'shape':shape,'orthogonalizer_relative_difference':float((a-b).norm()/b.norm()),
         'sign_flip_fraction':float(flips.float().mean()),'rms_of_flipped_entries':float(a[flips].square().mean().sqrt()),
         'raw_orthogonalizer_rms':float(a.square().mean().sqrt()),'aligned_update_errors':[]}
    actual_p=torch.nn.Parameter(torch.zeros_like(g));ref_p=torch.nn.Parameter(torch.zeros_like(g))
    actual=AdaMuon([actual_p],lr=.000326599,weight_decay=.0183712,adjust_lr_fn='match_rms_adamw')
    authors=reference.AdaMuon([ref_p],lr=.000326599,weight_decay=.0183712,rank=0,world_size=1)
    for _ in range(3):
        actual_p.grad=torch.randn_like(g)*.001;ref_p.grad=actual_p.grad.clone()
        actual.step()
        with patch.object(reference,'zeropower_via_newtonschulz5',side_effect=aligned_ns),patch.object(reference.dist,'all_gather_into_tensor',side_effect=gather):
            authors.step()
        row['aligned_update_errors'].append(float((actual_p-ref_p).detach().norm()/ref_p.detach().norm()))
        va=actual.state[actual_p]['second_moment'].flatten();vb=authors.state[ref_p]['v_buffer']
        row.setdefault('aligned_variance_relative_errors',[]).append(float((va-vb).norm()/vb.norm()))
    rows.append(row)
(p/'NUMERICAL_DIAGNOSIS.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows),flush=True)
