"""Compare to published Polar Express and benchmark all 96 full-size matrices."""
import gc
import hashlib
import importlib.util
import json
import statistics
import time
from pathlib import Path

import torch
from torch.optim._muon import _zeropower_via_newtonschulz
from nano_protein.model import build_model, count_parameters
from nano_protein.polar_muon import POLAR_EXPRESS_COEFFICIENTS, PolarExpressMuon, polar_express
from nano_protein.train import muon_adamw_parameter_groups

torch.set_num_threads(1)
torch.manual_seed(20260905)
p = Path('.dev/program2/candidates/r13_polarexpress')
reference_receipt = json.loads((p/'REFERENCE.json').read_text())
assert hashlib.sha256((p/'reference_polar_express.py').read_bytes()).hexdigest() == reference_receipt['source_sha256']
spec=importlib.util.spec_from_file_location('published_polar',p/'reference_polar_express.py')
reference=importlib.util.module_from_spec(spec);spec.loader.exec_module(reference)
published = reference.PolarExpress._torchdynamo_orig_callable
assert tuple(tuple(map(float,c)) for c in reference.coeffs_list[:5]) == POLAR_EXPRESS_COEFFICIENTS
assert torch.cuda.get_device_name(0) == 'NVIDIA L40S'
comparisons=[]
for shape in ((2304,768),(768,768),(4096,768),(768,2048)):
    matrix=torch.randn(*shape,device='cuda')*.001
    before=matrix.clone()
    actual=polar_express(matrix).float()
    expected=published(matrix,5).float()
    error=((actual-expected).norm()/expected.norm()).item()
    assert error < .08, (shape,error)
    assert torch.isfinite(actual).all()
    torch.testing.assert_close(matrix,before,rtol=0,atol=0)
    comparisons.append({'shape':shape,'relative_difference_from_published_bf16':error})
polar_accuracy=[]
for shape in ((64,64),(192,64),(64,192)):
    matrix=torch.randn(*shape,device='cuda')
    u,_,vh=torch.linalg.svd(matrix.float(),full_matrices=False)
    target=u@vh
    pe_error=((polar_express(matrix).float()-target).norm()/target.norm()).item()
    native_error=((_zeropower_via_newtonschulz(matrix,(3.4445,-4.7750,2.0315),5,1e-7).float()-target).norm()/target.norm()).item()
    assert pe_error < native_error,(shape,pe_error,native_error)
    polar_accuracy.append({'shape':shape,'polar_express_relative_polar_error':pe_error,'native_relative_polar_error':native_error})
for matrix in (torch.zeros(64,128,device='cuda'),torch.ones(64,128,device='cuda'),torch.diag(torch.logspace(-6,0,64,device='cuda'))):
    assert torch.isfinite(polar_express(matrix)).all()
model=build_model('esmc-171m').cuda()
assert count_parameters(model)==170671168
groups,_=muon_adamw_parameter_groups(model,weight_decay=.0183712)
parameters=groups[0]['params']
assert len(parameters)==96
native_parameters=[torch.nn.Parameter(x.detach().clone()) for x in parameters]
for a,b in zip(parameters,native_parameters,strict=True):
    a.grad=torch.randn_like(a)*.001
    b.grad=a.grad.clone()
options=dict(lr=.000326599,weight_decay=.0183712,momentum=.95,nesterov=True,ns_steps=5,adjust_lr_fn='match_rms_adamw')
candidate=PolarExpressMuon(parameters,**options)
native=torch.optim.Muon(native_parameters,**options)
candidate.step();native.step()
for a,b in zip(parameters,native_parameters,strict=True):
    torch.testing.assert_close(candidate.state[a]['momentum_buffer'],native.state[b]['momentum_buffer'],rtol=0,atol=0)
gc.collect()
def measure(optimizer):
    for _ in range(5): optimizer.step()
    torch.cuda.synchronize()
    start=time.perf_counter()
    for _ in range(20): optimizer.step()
    torch.cuda.synchronize()
    return (time.perf_counter()-start)*1000/20
samples={'native_ms':[],'polar_express_ms':[]}
for repeat in range(3):
    order=[('native_ms',native),('polar_express_ms',candidate)]
    if repeat%2: order.reverse()
    for label,optimizer in order: samples[label].append(measure(optimizer))
assert all(torch.isfinite(x).all() for x in parameters)
receipt={'status':'passed','gpu':torch.cuda.get_device_name(0),'torch':torch.__version__,
         'parameters':170671168,'matrix_count':96,'reference_comparisons':comparisons,
         'synthetic_svd_comparisons':polar_accuracy,'momentum_buffers':'bitwise identical to native after equal supplied gradients',
         'zero_rank_one_ill_conditioned':'finite','timing_samples':samples,
         'native_median_ms':statistics.median(samples['native_ms']),
         'polar_express_median_ms':statistics.median(samples['polar_express_ms']),
         'data':'synthetic gradients only; no training or held-out inputs; SVD only in diagnostics'}
(p/'OPTIMIZER_PREFLIGHT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
