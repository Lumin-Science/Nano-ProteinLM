import gc
import json
import statistics
import time
from pathlib import Path

import torch
from nano_protein.batched_muon import BatchedMuon
from nano_protein.model import build_model, count_parameters
from nano_protein.train import muon_adamw_parameter_groups

torch.set_num_threads(1)
torch.manual_seed(20260905)
assert torch.cuda.get_device_name(0) == 'NVIDIA L40S'
model = build_model('esmc-171m').cuda()
assert count_parameters(model) == 170671168
groups, _ = muon_adamw_parameter_groups(model, weight_decay=0.0183712)
parameters = groups[0]['params']
shapes = {}
for p in parameters:
    shapes[str(tuple(p.shape))] = shapes.get(str(tuple(p.shape)), 0) + 1
assert len(parameters) == 96 and len(shapes) == 4
native_params = [torch.nn.Parameter(p.detach().clone()) for p in parameters]
for p, q in zip(parameters, native_params, strict=True):
    p.grad = torch.randn_like(p) * 0.001
    q.grad = p.grad.clone()
kwargs = dict(lr=0.000326599, weight_decay=0.0183712, momentum=0.95,
              nesterov=True, ns_steps=5, adjust_lr_fn='match_rms_adamw')
batched = BatchedMuon(parameters, **kwargs)
native = torch.optim.Muon(native_params, **kwargs)
original = [p.detach().clone() for p in parameters]
batched.step()
native.step()
max_relative_error = 0.0
min_cosine = 1.0
for p, q, start in zip(parameters, native_params, original, strict=True):
    a, b = (p-start).float().flatten(), (q-start).float().flatten()
    max_relative_error = max(max_relative_error, ((a-b).norm()/b.norm()).item())
    min_cosine = min(min_cosine, torch.nn.functional.cosine_similarity(a,b,dim=0).item())
    torch.testing.assert_close(batched.state[p]['momentum_buffer'], native.state[q]['momentum_buffer'],rtol=0,atol=0)
assert max_relative_error < 0.04, max_relative_error
assert min_cosine > 0.999, min_cosine
del original
gc.collect()

def measure(optimizer):
    for _ in range(5): optimizer.step()
    torch.cuda.synchronize()
    start = time.perf_counter()
    for _ in range(20): optimizer.step()
    torch.cuda.synchronize()
    return (time.perf_counter()-start)*1000/20

samples = {'native_ms': [], 'batched_ms': []}
for repeat in range(3):
    order = [('native_ms',native),('batched_ms',batched)]
    if repeat % 2: order.reverse()
    for label, optimizer in order:
        samples[label].append(measure(optimizer))
receipt = {'status':'passed','node':'kn081','gpu':torch.cuda.get_device_name(0),
           'torch':torch.__version__, 'parameters':170671168, 'matrix_shapes':shapes,
           'max_relative_update_error':max_relative_error,'minimum_update_cosine':min_cosine,
           'momentum_buffers':'bitwise identical', 'timing_samples':samples,
           'native_median_ms':statistics.median(samples['native_ms']),
           'batched_median_ms':statistics.median(samples['batched_ms']),
           'scope':'Synthetic gradients on all 96 full-size hidden matrices; optimizer-only wall time including stack/copy; no training or evaluation data.'}
receipt['optimizer_speedup'] = receipt['native_median_ms']/receipt['batched_median_ms']
Path('.dev/program2/candidates/r10_batchedmuon/BENCHMARK.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
