"""Verify that the config change doubles Muon updates and preserves shrinkage."""
import copy
import json
import math
import statistics
from pathlib import Path
import torch
import yaml
from nano_protein.model import ESMCConfig,ESMCForMaskedLM,expected_parameter_count
from nano_protein.schedule import warmup_constant_multiplier
from nano_protein.train import build_optimizer

torch.set_num_threads(1);torch.manual_seed(17)
root=Path('.dev/program2/candidates/r17_muonscale')
config=yaml.safe_load(Path('configs/program2/r10_sqrtloss_seed42.yaml').read_text())
candidate=yaml.safe_load(Path('configs/program2/r17_muonscale_seed42.yaml').read_text())
assert candidate==dict(config,muon_lr_scale=2.,muon_weight_decay_scale=.5)
model=ESMCForMaskedLM(ESMCConfig.tiny());other=copy.deepcopy(model)
a=build_optimizer(model,config);b=build_optimizer(other,candidate)
assert type(a.named_optimizers[0][1])==type(b.named_optimizers[0][1])==torch.optim.Muon
assert expected_parameter_count(ESMCConfig.esmc_171m())==170671168
schedules=[]
for step in (1,2,553,554,555,10000):
    multiplier=warmup_constant_multiplier(optimizer_step=step,warmup_steps=554)
    for optimizer in (a,b):
        for group in optimizer.param_groups:
            group['lr']=config['learning_rate']*multiplier*group.get('lr_scale',1.)
    for ga,gb in zip(a.param_groups,b.param_groups,strict=True):
        assert math.isclose(ga['lr']*ga['weight_decay'],gb['lr']*gb['weight_decay'])
        if ga['name']=='muon_hidden':
            assert gb['lr']==2*ga['lr'] and gb['weight_decay']==.5*ga['weight_decay']
        else:
            assert ga['lr']==gb['lr'] and ga['weight_decay']==gb['weight_decay']
    schedules.append({'step':step,'baseline_lrs':[g['lr'] for g in a.param_groups],'candidate_lrs':[g['lr'] for g in b.param_groups]})
# Equal supplied gradients isolate update magnitude from learned-trajectory changes.
ratios=[]
for shape in ((8,8),(12,4),(4,12)):
    p=torch.nn.Parameter(torch.zeros(shape));q=torch.nn.Parameter(torch.zeros(shape))
    native=torch.optim.Muon([p],lr=config['learning_rate'],weight_decay=config['weight_decay'],adjust_lr_fn='match_rms_adamw')
    scaled=torch.optim.Muon([q],lr=2*config['learning_rate'],weight_decay=.5*config['weight_decay'],adjust_lr_fn='match_rms_adamw')
    for _ in range(3):
        p.grad=torch.randn_like(p);q.grad=p.grad.clone()
        with torch.no_grad():
            p.zero_();q.zero_()
        native.step();scaled.step()
        torch.testing.assert_close(q,2*p,rtol=0,atol=0)
        torch.testing.assert_close(native.state[p]['momentum_buffer'],scaled.state[q]['momentum_buffer'],rtol=0,atol=0)
        ratios.append(float(q.detach().norm()/p.detach().norm()))
trajectory=[]
for seed,node in ((42,'kn081'),(43,'kn056')):
    rows=[json.loads(s) for s in Path(f'outputs/program2/r10_sqrtloss-seed{seed}-{node}-20260905T192728Z/metrics.jsonl').read_text().splitlines()]
    rows=[r for r in rows if r.get('event')=='train']
    bins=[]
    for start in (1000,3000,5000,7000,9000):
        selected=[r for r in rows if start<=r['optimizer_step']<start+1000]
        bins.append({'start_step':start,**{k:statistics.mean(r[k] for r in selected) for k in ('loss','objective_loss','gradient_norm')}})
    trajectory.append({'seed':seed,'bins':bins})
receipt={'status':'passed','parameters':170671168,'config_only':True,'muon_update_ratios':ratios,
         'weight_shrinkage':'All groups retain identical LR*WD throughout the 554-step warmup and constant phase',
         'schedules':schedules,'incumbent_training_trajectory':trajectory,
         'data':'Existing incumbent training metrics and synthetic supplied gradients; no held-out data used for qualification'}
(root/'CONFIG_PREFLIGHT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':'passed','muon_peak_lr':2*config['learning_rate'],'adamw_peak_lr':config['learning_rate'],'muon_weight_decay':.5*config['weight_decay'],'update_ratios':ratios}),flush=True)
