#!/usr/bin/env bash
set -euo pipefail
cd /scratch/muchenli/nano-protein-autoresearch-171m/.dev/worktrees/autoresearch-171m-val-loss
method="${1:?method ID required}"
[[ "$method" =~ ^[a-zA-Z0-9_-]+$ ]]
stamp="$(date -u +%Y%m%dT%H%M%SZ)"
for spec in '42 kn081' '43 kn056'; do
  read -r seed node <<< "$spec"
  run_id="${method}-seed${seed}-${node}-${stamp}"
  [[ -f "configs/program2/${method}_seed${seed}.yaml" ]]
  printf '%s\t%s\t%s\t%s\n' "$method" "$run_id" "$seed" "$node" >> .dev/program2/launches.tsv
  tmux new-window -d -t program2-171m -n "${method}-${seed}" \
    "ssh -o BatchMode=yes -o ServerAliveInterval=30 $node 'bash $PWD/.dev/program2/run-node.sh $method $seed $node $run_id' > $PWD/.dev/program2/${run_id}.launcher.log 2>&1"
done
