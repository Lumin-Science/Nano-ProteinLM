#!/usr/bin/env bash
set -euo pipefail
cd /scratch/muchenli/nano-protein-autoresearch-171m/.dev/worktrees/autoresearch-171m-val-loss
method="$1"
seed="$2"
node="$3"
run_id="$4"
[[ "$(hostname -s)" == "$node" ]]
source .dev/program2/env.sh
exec 9>"/tmp/program2-171m-${USER}-gpus.lock"
flock -n 9 || { echo 'Program 2 GPU reservation is already held'; exit 2; }
[[ "$(nvidia-smi --query-gpu=name --format=csv,noheader | wc -l)" -eq 4 ]]
[[ "$(nvidia-smi --query-gpu=name --format=csv,noheader | sort -u)" == 'NVIDIA L40S' ]]
[[ -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)" ]] || { echo 'GPUs are busy'; exit 2; }
export CONFIG="$PWD/configs/program2/${method}_seed${seed}.yaml"
export OUTPUT_ROOT="$PWD/outputs/program2/$run_id"
[[ -f "$CONFIG" && ! -e "$OUTPUT_ROOT" ]]
"$UV_BIN" sync --frozen
"$UV_BIN" run --frozen ruff check .
"$UV_BIN" run --frozen ruff format --check .
bash runs/autoresearch_4xl40s_1h.sh
