"""Replay the continuous curriculum data stream without consuming held-out data."""
from pathlib import Path
import argparse, hashlib, json, math
import torch, yaml
from nano_protein.batch_balance import balanced_partitions
from nano_protein.data import MixtureBatcher
from nano_protein.tokenizer import ProteinTokenizer

parser=argparse.ArgumentParser()
parser.add_argument('--method',default='r09_context')
parser.add_argument('--require-stage2',action='store_true')
parser.add_argument('--require-complete',action='store_true')
args=parser.parse_args()
torch.set_num_threads(1)
notes=Path('.dev/program2'); candidate=notes/'candidates'/args.method
metadata=json.loads((candidate/'METHOD.json').read_text())
for key in ['source_hashes','config_hashes']:
 for name,digest in metadata[key].items():
  assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
launches=[line.split('\t') for line in (notes/'launches.tsv').read_text().splitlines()]
launches=[row for row in launches if row[0]==args.method]
assert len(launches)==2
checks=[]
for _,run_id,seed,node in launches:
 run=Path('outputs/program2')/run_id
 state=dict(line.split('=',1) for line in (run/'ROUND_STATE').read_text().splitlines())
 assert state['state'] in ['running','complete'],state
 if args.require_complete: assert state['state']=='complete'
 contract=json.loads((run/'run_contract.json').read_text())
 config=yaml.safe_load(Path(contract['config_path']).read_text())
 assert config['seed']==int(seed) and config['share_stage_data_stream'] is True
 assert config['walltime_seconds']==3600 and config['warmup_steps']==554
 assert config['stage1_fraction']==.25
 assert contract['config_sha256']==metadata['config_hashes'][f'configs/program2/{args.method}_seed{seed}.yaml']
 assert contract['git_commit']==metadata['source_base_commit']
 assert contract['world_size']==4 and contract['visible_gpu']=='NVIDIA L40S'
 assert all(s['micro_batch_size']==64 and s['gradient_accumulation']==1 for s in config['stages'])
 assert all(s['mixture']==config['stages'][0]['mixture'] for s in config['stages'])
 raw=(run/'metrics.jsonl').read_text(); lines=raw.splitlines()
 if not raw.endswith('\n'): lines=lines[:-1]
 records=[json.loads(line) for line in lines]
 records={r['optimizer_step']:r for r in records if r.get('event')=='train'}
 assert max(records)>=100
 boundary=None; stage_checkpoint=run/'checkpoint-stage1.pt'
 if stage_checkpoint.exists():
  saved=torch.load(stage_checkpoint,map_location='cpu',weights_only=False,mmap=True)
  assert saved['train_config']==config and saved['stage']=='stage1'
  boundary=int(saved['optimizer_step'])
  assert 900<=saved['training_seconds']<930
  del saved
 long_records=[r for r in records.values() if r['stage']=='stage2']
 if args.require_stage2 or args.require_complete: assert boundary and long_records
 if long_records: assert boundary is not None
 references=[MixtureBatcher(Path(contract['data_manifest']).parent,'train',config['stages'][0]['mixture'],seed=int(seed),rank=rank,world_size=4) for rank in range(4)]
 tokenizer=ProteinTokenizer.esmc(); total_tokens=0; total_residues=0
 for step in range(1,max(records)+1):
  long=boundary is not None and step>boundary
  context=512 if long else 128
  before=[]; lengths=[]
  for batcher in references:
   _,attention=batcher.batch(64,context_length=context,tokenizer=tokenizer)
   n=attention.sum(dim=1).tolist()
   before.append(sum(n)); lengths.extend(n)
  step_tokens=sum(before); total_tokens+=step_tokens; total_residues+=step_tokens-512
  if step not in records: continue
  r=records[step]
  assert r['stage']==('stage2' if long else 'stage1') and r['context_length']==context
  assert math.isfinite(r['loss']) and math.isfinite(r['gradient_norm'])
  assert math.isclose(r['learning_rate'],config['learning_rate']*min(step/554,1))
  if long: assert r['training_seconds']>=900
  else: assert r['training_seconds']<=905
  assert r['step_model_tokens']==step_tokens and r['model_tokens']==total_tokens
  assert r['filled_residues']==total_residues and r['sequences_seen']==step*256
  assert r['source_counts_rank0']==dict(references[0].source_counts)
  partitions=balanced_partitions(lengths,4)
  after=[sum(lengths[i] for i in indices) for indices in partitions]
  assert r['batch_balance']['rank_tokens_before']==before
  assert r['batch_balance']['rank_tokens_after']==after
  assert sum(after)==step_tokens and max(after)<=max(before)
 checks.append({'seed':int(seed),'node':node,'run_id':run_id,'last_step':max(records),'last_loss':records[max(records)]['loss'],'last_context':records[max(records)]['context_length'],'replayed_steps':max(records),'verified_records':len(records),'last_short_step':boundary,'first_logged_long_step':long_records[0]['optimizer_step'] if long_records else None})
 print(json.dumps(checks[-1]),flush=True)
receipt={'status':'verified','state':'complete' if args.require_complete else 'healthy','checks':checks,'data':'Exact replay of one persistent training sampler per rank; identical corpus and mixture across both contexts.'}
name='COMPLETE_REPLAY_VERIFICATION.json' if args.require_complete else ('TRANSITION_VERIFICATION.json' if args.require_stage2 else 'STARTUP_VERIFICATION.json')
(candidate/name).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'receipt':str(candidate/name),'status':'verified'}),flush=True)
