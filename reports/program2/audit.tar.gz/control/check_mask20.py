"""Check training-only mask density and unchanged default corruption behavior."""
import json, math
from pathlib import Path
import torch
from nano_protein.data import MixtureBatcher
from nano_protein.tokenizer import ProteinTokenizer, mask_tokens

torch.set_num_threads(1)
tokenizer = ProteinTokenizer.esmc()
mixture = {'uniref90':0.36, 'mgnify':0.11, 'omg_img':0.54}
data = Path('.exps/program2/data/training-samples-5376000')
batcher = MixtureBatcher(data, 'train', mixture, seed=20260905, rank=0, world_size=4)
canonical = torch.tensor(tokenizer.canonical_ids)
generator = torch.Generator().manual_seed(20260905)
counts = []
selected_counts = []
for _ in range(32):
    tokens, attention = batcher.batch(64, context_length=512, tokenizer=tokenizer)
    eligible = attention & torch.isin(tokens, canonical)
    n = eligible.sum(1)
    initial_rng = generator.get_state()
    default_tokens, default_labels = mask_tokens(tokens, attention, tokenizer, generator=generator)
    default_end = generator.get_state()
    generator.set_state(initial_rng)
    explicit_tokens, explicit_labels = mask_tokens(tokens, attention, tokenizer, probability=.15, generator=generator)
    assert torch.equal(default_tokens, explicit_tokens) and torch.equal(default_labels, explicit_labels)
    assert torch.equal(default_end, generator.get_state())
    corrupted, labels = mask_tokens(tokens, attention, tokenizer, probability=.20, generator=generator)
    chosen = labels != -100
    assert not (chosen & ~eligible).any()
    assert torch.equal(labels[chosen], tokens[chosen])
    assert torch.equal(corrupted[~chosen], tokens[~chosen])
    assert (corrupted[chosen] == tokenizer.mask_id).all()
    assert (chosen.sum(1)[n>0] >= 1).all()
    counts.extend(n.tolist())
    selected_counts.extend(chosen.sum(1).tolist())
expected = sum(.2*n+.8**n for n in counts if n>0)
variance = sum(n*.2*.8+.8**n-2*.2*n*.8**n-.8**(2*n) for n in counts if n>0)
z = (sum(selected_counts)-expected)/math.sqrt(variance)
assert abs(z) < 8
receipt = {'status':'passed','source':'training split only','sampling_seed':20260905,
           'sequences':len(counts), 'eligible':sum(counts),'selected':sum(selected_counts),
           'observed_fraction':sum(selected_counts)/sum(counts),
           'forced_bernoulli_expected_count':expected,'count_z_score':z,
           'default_015':'Bitwise identical tokens, labels, and RNG state to omitted probability on every batch.',
           'corruption':'Only attended canonical residues selected; original labels and mask-all replacement; forced one for eligible rows.'}
Path('.dev/program2/candidates/r11_mask20/MASK_PREFLIGHT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
