#!/usr/bin/env bash
export UV_BIN=/scratch/muchenli/nano-protein-autoresearch-171m/.exps/tools/uv
export UV_CACHE_DIR="$PWD/.uv-cache/program2"
export ARTIFACT_ROOT="$PWD/.exps/program2"
export CONTACT_ROOT=/scratch/muchenli/nano-protein-autoresearch-assets-20260826/esmc-paper-contact-v1
export EXTERNAL_SRC=/scratch/muchenli/nano-protein-autoresearch-assets-20260826/src
export CONTACT_SCORING_CACHE_ROOT=/scratch/muchenli/nano-protein-autoresearch-assets-20260826/esmc-paper-contact-scoring-cache-v1
export CUDA_VISIBLE_DEVICES=0,1,2,3
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export PATH="$(dirname "$UV_BIN"):$PATH"
unset DATA_ROOT DATA_CACHE_ROOT UV_PROJECT_ENVIRONMENT VIRTUAL_ENV
