from pathlib import Path
import json,time
import torch
from nano_protein.data import MixtureBatcher
from nano_protein.tokenizer import ProteinTokenizer,mask_tokens
from nano_protein.training_masks import mask_tokens_rounded_count

torch.set_num_threads(4)
batcher=MixtureBatcher(Path('.exps/program2/data/training-samples-5376000'),'train',{'uniref90':.36,'mgnify':.11,'omg_img':.54},seed=20260905)
tokenizer=ProteinTokenizer.esmc(); canonical=torch.tensor(tokenizer.canonical_ids)
base_rng=torch.Generator().manual_seed(20260905); candidate_rng=torch.Generator().manual_seed(20260905)
all_n=[]; all_base=[]; all_candidate=[]; elapsed=[]
for _ in range(32):
 tokens,attention=batcher.batch(64,context_length=512,tokenizer=tokenizer)
 n=(attention & torch.isin(tokens,canonical)).sum(dim=1)
 _,base=mask_tokens(tokens,attention,tokenizer,generator=base_rng)
 start=time.perf_counter()
 _,candidate=mask_tokens_rounded_count(tokens,attention,tokenizer,generator=candidate_rng)
 elapsed.append(1000*(time.perf_counter()-start))
 all_n.extend(n.tolist()); all_base.extend((base!=-100).sum(dim=1).tolist()); all_candidate.extend((candidate!=-100).sum(dim=1).tolist())
n=torch.tensor(all_n,dtype=torch.float64); mu=.15*n+.85**n; mu[n==0]=0
base_var=.15*.85*n+(.15*n)**2+.85**n-mu**2; base_var[n==0]=0
fraction=mu-mu.floor(); candidate_var=fraction*(1-fraction)
a=torch.tensor(all_base); b=torch.tensor(all_candidate)
result={'split':'train','analysis_seed':20260905,'sequences':len(all_n),'mean_canonical_residues':n.mean().item(),'expected_targets_per_sequence':mu.mean().item(),'analytic_conditional_count_variance_incumbent':base_var.mean().item(),'analytic_conditional_count_variance_candidate':candidate_var.mean().item(),'sampled_targets_per_sequence_incumbent':a.float().mean().item(),'sampled_targets_per_sequence_candidate':b.float().mean().item(),'sampled_squared_count_deviation_incumbent':((a-mu)**2).mean().item(),'sampled_squared_count_deviation_candidate':((b-mu)**2).mean().item(),'cpu_masking_ms_per_64_mean':sum(elapsed)/len(elapsed),'caution':'Count variance reduction is exact mathematically; full model gradient variance reduction is a hypothesis. Joint mask distribution differs. FP32 count expectations introduce negligible numerical error.'}
p=Path('.dev/program2/candidates/r07_maskcount')
(p/'TRAIN_ONLY_ANALYSIS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
