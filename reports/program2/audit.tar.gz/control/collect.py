"""Verify completed Program 2 repeats and atomically record the selection rule."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
from statistics import fmean, stdev

import torch
import yaml

from nano_protein.data import file_sha256

ROOT = Path.cwd().resolve()
NOTES = ROOT / ".dev/program2"


def read(path):
    return json.loads(path.read_text())


def verify(run, seed):
    state = dict(line.split("=", 1) for line in (run / "ROUND_STATE").read_text().splitlines())
    assert state["state"] == "complete", run
    summary = read(run / "ROUND_SUMMARY.json")
    complete = read(run / "TRAINING_COMPLETE.json")
    contract = read(run / "run_contract.json")
    environment = read(run / "ENVIRONMENT.json")
    config_path = Path(contract["config_path"])
    config = yaml.safe_load(config_path.read_text())
    assert config["seed"] == seed
    assert config["warmup_steps"] == 554 and config["walltime_seconds"] == 3600
    assert contract["config_sha256"] == file_sha256(config_path)
    assert contract["uv_lock_sha256"] == file_sha256(ROOT / "uv.lock")
    manifest_path = Path(contract["data_manifest"])
    assert contract["data_manifest_sha256"] == file_sha256(manifest_path)
    assert contract["corpus_verification_sha256"] == file_sha256(
        manifest_path.parent / "CORPUS_VERIFICATION.json"
    )
    assert contract["homology_exclusion"] is True
    assert contract["world_size"] == environment["visible_gpus"] == 4
    assert contract["visible_gpu"] == environment["gpu"] == "NVIDIA L40S"
    assert contract["torch"] == environment["torch"] == "2.13.0+cu126"
    assert environment["status"] == "qualified" and environment["forward_backward"]
    assert complete["stop_reason"] == "walltime"
    assert complete["walltime_budget_seconds"] == 3600
    assert complete["training_seconds"] >= 3600
    assert complete["parameter_count"] == config["expected_parameter_count"] <= 171000000
    checkpoint = run / "checkpoint-final.pt"
    digest = file_sha256(checkpoint)
    assert digest == complete["final_checkpoint"]["sha256"] == summary["checkpoint"]["sha256"]
    saved = torch.load(checkpoint, map_location="cpu", weights_only=False, mmap=True)
    assert saved["train_config"] == config
    assert saved["optimizer_step"] == complete["optimizer_steps"] == summary["actual_steps"]
    assert saved["parameter_count"] == complete["parameter_count"]
    peak_lr = float(config["learning_rate"])
    optimizers = saved["optimizer"]
    if "param_groups" not in optimizers:
        optimizers = {item["name"]: item["state_dict"] for item in optimizers["optimizers"]}
    else:
        optimizers = {"adamw": optimizers}
    for optimizer in optimizers.values():
        for group in optimizer["param_groups"]:
            assert math.isclose(group["lr"], peak_lr * group.get("lr_scale", 1.0))
    del saved
    validation = read(run / "eval-validation/VALIDATION_MLM.json")
    evaluation = read(run / "eval-validation/EVALUATION.json")
    assert evaluation["checkpoint_sha256"] == digest
    assert validation == evaluation["validation_mlm"]
    assert validation["sequences"] == 32 and validation["masked_residues"] == 994
    assert validation["source_counts"] == {"mgnify": 9, "omg_img": 13, "uniref90": 10}
    assert summary["validation_loss"] == validation["sequence_mean_nll"]
    contact = read(run / "eval-p-at-l/P_AT_L.json")
    assert contact["checkpoint_sha256"] == digest
    assert contact["evaluation_chains"] == 20775 and contact["selection_seed"] == 20260820
    assert summary["p_at_l"] == contact["p_at_l"]
    probe_path = run / "eval-p-at-l/CONTACT_PROBE.json"
    probe = read(probe_path)
    assert probe["checkpoint_sha256"] == digest and probe["pair_sampling_seed"] == 20260819
    assert probe["dataset_manifest_sha256"] == (
        "c135bc806b1a282ea3d38651d55e0cc799578047ca12855c518d77a9274e9ce3"
    )
    seen = set()
    for component in contact["components"]:
        path = Path(component["path"])
        assert file_sha256(path) == component["sha256"]
        shard = read(path)
        assert shard["checkpoint_sha256"] == digest
        assert shard["contact"]["probe_receipt_sha256"] == file_sha256(probe_path)
        for row in shard["contact"]["rows"]:
            assert row["chain_id"] not in seen
            seen.add(row["chain_id"])
    assert len(seen) == 20775
    records = [json.loads(line) for line in (run / "metrics.jsonl").read_text().splitlines()]
    records = [row for row in records if row.get("event") == "train"]
    assert all(
        math.isfinite(row["loss"]) and math.isfinite(row["gradient_norm"]) for row in records
    )
    expected_steps = [1] + list(range(10, complete["optimizer_steps"] + 1, 10))
    assert [row["optimizer_step"] for row in records] == expected_steps
    for row in records:
        expected_lr = peak_lr * min(row["optimizer_step"] / 554, 1)
        expected_lr *= config.get("muon_attention_lr_scale", config.get("muon_lr_scale", 1.0))
        assert math.isclose(row["learning_rate"], expected_lr)
    assert math.isclose(summary["train_loss"], fmean(row["loss"] for row in records[-100:]))
    for key in (
        "validation_loss",
        "p_at_l",
        "train_loss",
        "training_seconds",
        "evaluation_seconds",
    ):
        assert math.isfinite(summary[key])
    receipt = {
        "status": "verified",
        "run_id": run.name,
        "seed": seed,
        "checkpoint_sha256": digest,
        "contract": contract,
        "training_records": len(records),
        "contact_chains": len(seen),
    }
    (run / "PROGRAM2_VERIFICATION.json").write_text(json.dumps(receipt, indent=2) + "\n")
    return summary, contract, {k: v for k, v in config.items() if k != "seed"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--method", required=True)
    parser.add_argument("--incumbent")
    parser.add_argument("--description", required=True)
    args = parser.parse_args()
    results_path = NOTES / "results.tsv"
    with results_path.open() as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        fields, old_rows = reader.fieldnames, list(reader)
    launches = [line.split("\t") for line in (NOTES / "launches.tsv").read_text().splitlines()]
    launches = [row for row in launches if row[0] == args.method]
    assert len(launches) >= 2 and {int(row[2]) for row in launches} == {42, 43}
    observations = [
        (run_id, int(seed), verify(ROOT / "outputs/program2" / run_id, int(seed)))
        for _, run_id, seed, _ in launches
    ]
    assert all(obs[2][2] == observations[0][2][2] for obs in observations)
    assert len({obs[2][1]["git_commit"] for obs in observations}) == 1
    losses = [obs[2][0]["validation_loss"] for obs in observations]
    mean, sd = fmean(losses), stdev(losses)
    if args.method == "baseline":
        delta, decision = 0.0, "baseline"
    else:
        reference = [row for row in old_rows if row["method_id"] == args.incumbent]
        assert reference and {int(row["seed"]) for row in reference} == {42, 43}
        assert all(row["status"] in ("keep", "baseline") for row in reference)
        delta = float(reference[0]["validation_loss_mean"]) - mean
        decision = "keep" if delta > sd else "discard"
    new_rows = []
    for run_id, seed, (summary, contract, _) in observations:
        row = dict.fromkeys(fields, "NA")
        row.update(
            method_id=args.method,
            run_id=run_id,
            seed=seed,
            commit=contract["git_commit"] if not contract["git_dirty"] else "NA",
            n_runs=len(losses),
            validation_loss_mean=repr(mean),
            validation_loss_std=repr(sd),
            delta=repr(delta),
            status=decision,
            description=args.description,
        )
        for key in (
            "validation_loss",
            "p_at_l",
            "train_loss",
            "training_seconds",
            "actual_steps",
            "model_tokens_M",
            "evaluation_seconds",
        ):
            row[key] = summary[key]
        row["params_M"] = summary["num_params_M"]
        row["memory_GB"] = summary["peak_vram_mb"] / 1024
        new_rows.append(row)
    preserved = [row for row in old_rows if row["method_id"] != args.method]
    temporary = results_path.with_suffix(".tsv.partial")
    with temporary.open("w") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(preserved + new_rows)
    temporary.replace(results_path)
    print(
        json.dumps(
            {
                "method": args.method,
                "n": len(losses),
                "mean": mean,
                "sample_std": sd,
                "delta": delta,
                "decision": decision,
            }
        )
    )


if __name__ == "__main__":
    main()
