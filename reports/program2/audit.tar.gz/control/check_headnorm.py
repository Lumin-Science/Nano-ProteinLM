"""Qualify headwise normalization without consuming held-out examples."""
import json
from pathlib import Path
import torch
from nano_protein.model import ESMCConfig, ESMCForMaskedLM, ESMCHeadwiseLayerNorm, count_parameters
from nano_protein.tokenizer import ProteinTokenizer, mask_tokens
from nano_protein.train import training_losses

torch.set_num_threads(1)
assert torch.cuda.get_device_name(0) == 'NVIDIA L40S'
torch.manual_seed(20260905)
base = ESMCForMaskedLM(ESMCConfig.esmc_171m())
initial_rng = torch.get_rng_state()
torch.manual_seed(20260905)
candidate = ESMCForMaskedLM(ESMCConfig.esmc_171m(qk_norm_per_head=True))
assert torch.equal(initial_rng, torch.get_rng_state())
assert count_parameters(candidate) == 170671168
for name, value in base.state_dict().items():
    torch.testing.assert_close(value, candidate.state_dict()[name], rtol=0, atol=0)
del base
candidate = candidate.cuda()
tokenizer = ProteinTokenizer.esmc()
tokens, attention = tokenizer.encode_batch(['LAGVESIDPKQNFYMHWCART'*25, 'ACDEFGHIKLMNPQRSTVWY'*13], max_length=512)
tokens, attention = tokens.cuda(), attention.cuda()
corrupted, labels = mask_tokens(tokens, attention, tokenizer)
with torch.autocast('cuda', dtype=torch.bfloat16):
    output = candidate(corrupted, attention)
    loss, diagnostic, objective = training_losses(output['logits'], labels, reduction='sqrt_mask_count')
loss.backward()
norms = [m for m in candidate.modules() if isinstance(m, ESMCHeadwiseLayerNorm)]
assert len(norms) == 48
assert all(m.weight.grad is not None and torch.isfinite(m.weight.grad).all() and m.weight.grad.count_nonzero()>0 for m in norms)
assert torch.isfinite(loss)
full_loss = float(loss.detach())
del candidate, norms, output, loss
# Dense SDPA and whole-transformer packed FlashAttention must agree on real tokens.
torch.manual_seed(20260905)
reference = ESMCForMaskedLM(ESMCConfig.tiny(qk_norm_per_head=True, attention_backend='math')).cuda()
packed = ESMCForMaskedLM(ESMCConfig.tiny(qk_norm_per_head=True, attention_backend='flash')).cuda()
packed.load_state_dict(reference.state_dict())
tokens, attention = tokenizer.encode_batch(['ACDEFGHIK', 'LAGVESIDPKQNFYMHWCA'*3, 'GGGGG', 'ACDEFGHIKLMNPQRSTVWY'*4], max_length=64)
tokens, attention = tokens.cuda(), attention.cuda()
corrupted, labels = mask_tokens(tokens, attention, tokenizer)
outputs=[]
for model in (reference, packed):
    with torch.autocast('cuda', dtype=torch.bfloat16):
        out = model(corrupted, attention)
        loss, _, _ = training_losses(out['logits'], labels, reduction='sqrt_mask_count')
    loss.backward()
    outputs.append(out['logits'][attention].detach().float())
max_logit_error = (outputs[0]-outputs[1]).abs().max().item()
assert max_logit_error < .03, max_logit_error
squared_error = squared_reference = 0.0
for a,b in zip(reference.parameters(), packed.parameters(), strict=True):
    assert a.grad is not None and b.grad is not None
    squared_error += (a.grad-b.grad).float().square().sum().item()
    squared_reference += a.grad.float().square().sum().item()
relative_gradient_error = (squared_error/squared_reference)**.5
assert relative_gradient_error < .05, relative_gradient_error
with torch.no_grad(), torch.autocast('cuda', dtype=torch.bfloat16):
    features = packed(corrupted, attention, output_attentions=True)
assert len(features['attentions']) == 2
assert all(x.shape == (4,2,64,64) and torch.isfinite(x).all() for x in features['attentions'])
receipt={'status':'passed','gpu':torch.cuda.get_device_name(0),'torch':torch.__version__,
         'parameters':170671168,'full_size_initial_tensors_and_rng':'bitwise identical to default R10 architecture',
         'headwise_norms_with_finite_nonzero_gradients':48,'full_size_synthetic_objective':full_loss,
         'dense_vs_packed_max_logit_error':max_logit_error,
         'dense_vs_packed_relative_gradient_error':relative_gradient_error,
         'attention_features':'finite; unchanged layer/head/token layout',
         'data':'synthetic protein sequences only; no held-out input',
         'peak_memory_mb':torch.cuda.max_memory_allocated()/1024**2}
Path('.dev/program2/candidates/r12_headnorm/MODEL_PREFLIGHT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
