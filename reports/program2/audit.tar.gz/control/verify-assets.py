"""Read and hash the shared frozen assets once at campaign setup."""

import json
import os
from pathlib import Path

import yaml

import nano_protein
from nano_protein.data import file_sha256
from nano_protein.train import validate_data_manifest

root = Path.cwd().resolve()
assert Path(nano_protein.__file__).resolve().is_relative_to(root)
data = root / ".exps/program2/data/training-samples-5376000"
manifest = validate_data_manifest(data)
assert manifest["release_manifest_sha256"] == (
    "fe1ac0657085ab19fe6f56786006e9eb004ca66bc6c5b81dfd8e6bc3dcfda6ff"
)
verification = json.loads((data / "CORPUS_VERIFICATION.json").read_text())
hashes = {}
for source, groups in verification["sources"].items():
    for split in ("train", "validation"):
        for name, field in (("tokens.bin", "tokens_sha256"), ("index.npy", "index_sha256")):
            path = data / source / split / name
            digest = file_sha256(path)
            assert digest == groups[split][field], str(path)
            hashes[str(path.resolve())] = digest
original = yaml.safe_load((root / "configs/esmc-171m-original.yaml").read_text())
for seed in (42, 43):
    config = yaml.safe_load((root / f"configs/program2/baseline_seed{seed}.yaml").read_text())
    assert config == dict(original, seed=seed)
for folder in ("nano_protein", "scripts", "runs"):
    for path in sorted((root / folder).rglob("*")):
        if path.suffix in (".py", ".sh"):
            hashes[str(path.relative_to(root))] = file_sha256(path)
for name in ("uv.lock", "pyproject.toml", "configs/esmc-171m-original.yaml"):
    hashes[name] = file_sha256(root / name)
external = Path(os.environ["EXTERNAL_SRC"])
for path in sorted(external.rglob("*.py")):
    hashes[str(path)] = file_sha256(path)
receipt = {
    "status": "verified",
    "shared_inputs_access": "read-only; full token/index hashes verified",
    "training_source": str(Path(nano_protein.__file__).resolve()),
    "seeds": [42, 43],
    "hashes": hashes,
}
(root / ".dev/program2/FROZEN_ASSETS.json").write_text(json.dumps(receipt, indent=2) + "\n")
print("Verified corpus bytes, baseline configs, isolated imports, and source receipts.")
