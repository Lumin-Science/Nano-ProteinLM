"""Measure the update-frequency/throughput tradeoff for global batch128."""
import copy,json,statistics,time
from pathlib import Path
import torch,yaml
from nano_protein.model import ESMCConfig,ESMCForMaskedLM,count_parameters
from nano_protein.tokenizer import ProteinTokenizer,mask_tokens
from nano_protein.train import build_optimizer,training_losses
from nano_protein.schedule import warmup_constant_multiplier

torch.set_num_threads(1);torch.set_float32_matmul_precision('high')
assert torch.cuda.get_device_name(0)=='NVIDIA L40S'
root=Path('.dev/program2/candidates/r21_batch32')
config=yaml.safe_load(Path('configs/program2/r10_sqrtloss_seed42.yaml').read_text())
expected=copy.deepcopy(config);expected['stages'][0]['micro_batch_size']=32
candidate_config=yaml.safe_load(Path('configs/program2/r21_batch32_seed42.yaml').read_text())
assert candidate_config==expected
models=[]
for _ in range(2):
    torch.manual_seed(21)
    models.append(ESMCForMaskedLM(ESMCConfig.esmc_171m()).cuda())
assert count_parameters(models[0])==count_parameters(models[1])==170671168
for name,value in models[0].state_dict().items():
    torch.testing.assert_close(value,models[1].state_dict()[name],rtol=0,atol=0)
optimizers=[build_optimizer(m,c) for m,c in zip(models,(config,candidate_config),strict=True)]
assert all(len(o.named_optimizers[0][1].param_groups[0]['params'])==96 for o in optimizers)
for step in (1,553,554,555,20000):
    multiplier=warmup_constant_multiplier(optimizer_step=step,warmup_steps=554)
    for opt in optimizers:
        for group in opt.param_groups:
            group['lr']=config['learning_rate']*multiplier*group.get('lr_scale',1.)
    for first,second in zip(optimizers[0].param_groups,optimizers[1].param_groups,strict=True):
        for key in ('lr','weight_decay','lr_scale'):
            assert first.get(key)==second.get(key)
tokenizer=ProteinTokenizer.esmc()
sequences=[('LAGVESIDPKQNFYMHWCART'*26)[:18+(i*83)%490] for i in range(64)]
tokens,attention=tokenizer.encode_batch(sequences,max_length=512)
tokens,attention=tokens.cuda(),attention.cuda()
corrupted,labels=mask_tokens(tokens,attention,tokenizer)
counts={0:0,1:0}

def step(index):
    start=(counts[index]%2)*32 if index==1 else 0
    stop=start+32 if index==1 else 64
    counts[index]+=1
    model,opt=models[index],optimizers[index]
    opt.zero_grad(set_to_none=True)
    with torch.autocast('cuda',dtype=torch.bfloat16):
        output=model(corrupted[start:stop],attention[start:stop])
        loss,_,_=training_losses(output['logits'],labels[start:stop],reduction='sqrt_mask_count')
    loss.backward()
    norm=torch.nn.utils.clip_grad_norm_(model.parameters(),1.)
    opt.step()
    return loss.detach(),norm.detach()

timings={'batch64_ms':[],'batch32_ms':[]}
for round_index in range(2):
    for index in ([0,1] if round_index==0 else [1,0]):
        for _ in range(3):loss,norm=step(index)
        torch.cuda.synchronize();start=time.perf_counter()
        for _ in range(6):loss,norm=step(index)
        torch.cuda.synchronize()
        timings[('batch64_ms','batch32_ms')[index]].append((time.perf_counter()-start)*1000/6)
        assert torch.isfinite(loss) and torch.isfinite(norm)
assert all(torch.isfinite(p).all() and p.grad is not None and torch.isfinite(p.grad).all() for p in models[1].parameters())
a=statistics.median(timings['batch64_ms']);b=statistics.median(timings['batch32_ms'])
receipt={'status':'passed','gpu':torch.cuda.get_device_name(0),'parameters':170671168,
         'config_only':'micro_batch_size 64->32 per rank, accumulation1; all other config keys identical',
         'global_batch':128,'incumbent_global_batch':256,'timing_samples':timings,
         'baseline_median_step_ms':a,'candidate_median_step_ms':b,
         'candidate_updates_per_second_ratio':a/b,'candidate_tokens_per_second_ratio':.5*a/b,
         'timing_protocol':'Two alternating rounds; each3 warm+6 measured full forward/backward/clip/Muon+AdamW updates. Batch32 alternates equal halves of the same64-sequence masked synthetic batch; each measured block uses both halves3 times. No distributed communication; actual runs establish total throughput.',
         'schedule':'Both actual optimizer groups match at steps1,553,554,555,20000; exact554-step warmup then unchanged fixed peaks',
         'data':'synthetic protein sequences only; no held-out data',
         'muon_matrices':96,'peak_memory_mb_two_models':torch.cuda.max_memory_allocated()/1024**2}
(root/'BATCH_PREFLIGHT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
